__version__ = "1.0.0"
def kib(bytes_count):
    return bytes_count / 1024
