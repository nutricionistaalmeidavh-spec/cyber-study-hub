# Fase 15 — Lacunas de conteúdo

Ausência significa que o conhecimento não está explicado/praticado de maneira suficiente no pacote, mesmo quando aparece citado em um objetivo. Não significa que nenhum termo relacionado exista. Esta lista não exige exploração em toda aula nem substitui a disciplina por ferramentas.

## Lacunas globais

- Fundamentos operacionais, contratos de entrada/estado/saída e dependências explicadas.
- Exemplo resolvido com raciocínio intermediário; autoexplicação; exercício parcial; prática independente.
- Happy path e exemplos negativos concretos, não apenas a ordem “crie um negativo”.
- Código/configuração completos ou contexto explícito do fragmento; comentários de contratos e limites.
- Fixtures, versões, comandos, outputs, checkpoints e troubleshooting sintoma→causa→ação→reteste.
- Detecção por fonte/campo/identidade/tempo e avaliação de falso positivo.
- Correção causal, hardening compensatório, regressão legítima e risco residual.
- Quiz de aplicação e distratores plausíveis; flashcards com perguntas/respostas próprias do tema.
- Capstones integrados e referências por versão/mecanismo.

## Lacunas por bloco e unidade

### 1–46

Núcleos úteis de Web/AppSec foram envolvidos em repetição do próprio resumo e reforços nem sempre pertinentes. Priorizar contaminação de ORM em 001, CSRF em 009, SSRF em 015, código interpolado em 020/036 e casos sem app. Nenhuma aula deve ganhar prontidão só por ter mais seções.

- **AULA-001 — Fundamentos de Segurança da Informação:** Substituir reforço de ORM por cenário de ativo, ameaça, vulnerabilidade, impacto e controle; comparar CIA e risco residual.
- **AULA-002 — HTTP, Requests, Responses e Parâmetros:** Fornecer servidor local, request/response anotados, query/body/header e caso de erro de parsing.
- **AULA-003 — Autenticação e Autorização:** Demonstrar login válido seguido de autorização por ação/recurso; 401, 403 e objeto inexistente.
- **AULA-004 — Senhas, Hash, Salt e Bcrypt:** Criar exemplo completo de hash/verify; explicar custo, salt, limite de 72 bytes e Argon2id.
- **AULA-005 — Sessões, Cookies e JWT:** Traçar sessão real de login/logout/expiração e comparar cookie opaco com JWT.
- **AULA-006 — IDOR e Broken Access Control:** Cobrir objeto próprio, alheio e ausente, com autenticação e consulta completas.
- **AULA-007 — SQL Injection:** Montar banco sintético, comparar parametrização com concatenação e mostrar limites para identificadores SQL.
- **AULA-008 — Cross-Site Scripting — XSS:** Usar página local e marcador benigno para comparar texto, atributo e DOM; preservar happy path.
- **AULA-009 — CSRF:** Exigir presença e vínculo do token; testar ausência, divergência, sessão diferente e requisição legítima.
- **AULA-010 — Burp Suite: Proxy, Intercept e Repeater:** Disponibilizar app local, configuração de proxy/certificado e comparação de duas requisições anotadas.
- **AULA-011 — Segurança de APIs e Mass Assignment:** Criar DTO, validação em runtime e teste de campo privilegiado com registro anterior/posterior.
- **AULA-012 — BOLA / IDOR em APIs:** Criar dois usuários e dois objetos; comprovar isolamento e status de objeto ausente.
- **AULA-013 — Upload de Arquivos:** Adicionar inspeção de bytes, limites e armazenamento não executável; testar MIME falso e download seguro.
- **AULA-014 — CORS:** Subir duas origens locais, configurar preflight/credentials e comparar resposta recebida com leitura bloqueada.
- **AULA-015 — SSRF — Server-Side Request Forgery:** Explicar URL, scheme, porta, DNS e cada redirect; usar destinos locais controlados e reteste de egress.
- **AULA-016 — Business Logic Vulnerabilities:** Construir compra/cupom sintético, condições válidas e sequência inválida com estado final esperado.
- **AULA-017 — Race Conditions:** Fornecer transação completa e concorrência reproduzível; demonstrar conservação do saldo/estoque.
- **AULA-018 — Privilege Escalation:** Comparar usuários e capacidades em VM própria, com evidência de permissão antes/depois e reversão.
- **AULA-019 — JWT Avançado, Sessões e Refresh Tokens:** Demonstrar ciclo de refresh com replay detectado, invalidation e claims verificadas.
- **AULA-020 — OAuth 2.0, OpenID Connect, State e PKCE:** Separar material interpolado e fornecer Authorization Code + PKCE com callback e falhas de vínculo.
- **AULA-021 — Redes: IP, Portas, TCP e UDP:** Comparar listener TCP/UDP local, handshake, timeout e serviço em porta não padrão.
- **AULA-022 — Linux para Segurança:** Construir pequeno diagnóstico guiado com usuário, processo, socket e erro de permissão.
- **AULA-023 — Nmap — Mapeamento de Portas e Serviços:** Fornecer alvos locais conhecidos, resultados esperados e limites da inferência de versão.
- **AULA-024 — Wireshark — Observando Pacotes:** Fornecer captura local, filtro e sequência de pacotes comentada com casos negativos.
- **AULA-025 — Programas Compilados, CPU e Registradores:** Criar fonte mínimo, comandos compile/disassemble e rastreamento de uma instrução até registrador.
- **AULA-026 — Memória: Stack, Heap e Buffer Overflow:** Adicionar par de fixtures com limites, saída do sanitizer e patch, sem exploração fora do lab.
- **AULA-027 — Assembly — Comparações e Saltos:** Fixar arquitetura/sintaxe e mapear if/loop de C para cmp, flags e jump com valores.
- **AULA-028 — Ghidra e Engenharia Reversa:** Fornecer binário próprio e fonte, pontos de entrada e reconstrução comentada de uma função.
- **AULA-029 — Malware — Conceitos e Análise Segura:** Fornecer fixture educacional com hashes/strings conhecidos e limites do que ela simula.
- **AULA-030 — Stuxnet e Sistemas Industriais:** Contextualizar PLC, processo físico, zonas/conduítes e evidência histórica com fontes; usar simulação inerte.
- **AULA-031 — Metodologia de Pentest:** Produzir um exemplo de pentest fictício completo e explicar limites e critérios de interrupção.
- **AULA-032 — Reconhecimento e Superfície de Ataque:** Fornecer inventário sintético e demonstrar como validar ativo, serviço e exposição.
- **AULA-033 — De Pista a Hipótese:** Comparar versão aparente, teste mínimo e falso positivo, com conclusão sustentada.
- **AULA-034 — Validação de Impacto:** Rotular modelo didático; resolver impacto e severidade com vetor oficial e risco contextual separados.
- **AULA-035 — Relatório Profissional e Reteste:** Fornecer achado preenchido, evidência redigida, causa, correção e relatório de reteste.
- **AULA-036 — Threat Modeling com STRIDE:** Corrigir exemplo, construir DFD pequeno, fronteiras e ameaças justificadas por elemento.
- **AULA-037 — Secure Coding:** Aplicar validação na fronteira e apresentar entradas válidas, inválidas e resposta de erro segura.
- **AULA-038 — SAST, DAST, SCA e Secret Scanning:** Executar um caso por SAST/DAST/SCA/secrets e comparar cobertura e falsos positivos.
- **AULA-039 — DevSecOps:** Fornecer pipeline mínimo com gates, artefatos de evidência, falha intencional e reteste.
- **AULA-040 — Projeto Final — Pentest Completo de Laboratório:** Fornecer cenário integrado, escopo, estados iniciais e rubricar produtos com evidências reais.
- **AULA-041 — SSTI — Server-Side Template Injection:** Escolher engine local, mostrar renderização legítima, avaliação indevida inofensiva e separação template/dado.
- **AULA-042 — Insecure Deserialization:** Distinguir parsing de JSON, binding e deserialização com hooks; usar objeto educacional sem payload perigoso.
- **AULA-043 — GraphQL Security:** Montar GraphQL local, autorização por resolver e testes de aliases, batching e limites.
- **AULA-044 — WebSocket Security:** Fornecer lifecycle WebSocket, mensagens válidas/inválidas, origin, tamanho e sessão expirada.
- **AULA-045 — HTTP Request Smuggling:** Usar harness local de parsers, mensagens anotadas e fechamento/rejeição; incluir limites HTTP/2→1.
- **AULA-046 — Web Cache Poisoning:** Exibir chave calculada, entrada não incluída, resposta contaminada e teste de isolamento após correção.

### 47–60

047 é a única referência interna com laboratório físico completo e teste bem-sucedido do objetivo. As outras 13 têm conceitos específicos, mas a conversão V2 criou worked examples que narram passos, fading que apaga uma caixa do fluxo e expected genérico. Manter o conteúdo causal aproveitável e completar os cenários.

- **AULA-047 — Web Cache Deception:** Alinhar JSON/MD com X-Lab-User, normalizar snippets, ajustar promessa de bypass/TTL e substituir distratores óbvios; manter aula como referência.
- **AULA-048 — Prototype Pollution:** Diferenciar __proto__/constructor.prototype, demonstrar cadeia com objeto local e patch no merge real.
- **AULA-049 — Host Header Attacks:** Fornecer gerador local de links e testes Host/X-Forwarded-Host com política de proxy confiável.
- **AULA-050 — DOM-based Vulnerabilities:** Entregar página source→sink e caso postMessage com validação de origin e schema.
- **AULA-051 — Command Injection:** Fixar OS, chamar a função, reportar exit code e testar argumentos permitidos/rejeitados só localmente.
- **AULA-052 — Path Traversal e LFI/RFI:** Explicar realpath e TOCTOU; incluir symlink controlado e limitar explicitamente a garantia do exemplo.
- **AULA-053 — File Upload Vulnerabilities:** Fornecer endpoint e fixtures de MIME divergente, assinatura, nome seguro e resposta de download.
- **AULA-054 — JWT Security:** Entregar emissor/verificador e casos exp/aud/iss/assinatura; distinguir JWS/JWE e sessão.
- **AULA-055 — OAuth e OIDC Security:** Completar helpers e montar fluxo local com erros de state, nonce, redirect e troca do code.
- **AULA-056 — API Security avançada — BOLA, BFLA, Mass Assignment:** Fornecer API/fixtures e matriz objeto/função/campo, own-properties e schema em runtime.
- **AULA-057 — Rate Limit, Race Conditions e Business Logic Flaws:** Criar tabela/dados, harness paralelo, contagem de linhas afetadas e replay de idempotency key.
- **AULA-058 — CORS e Same-Origin Policy:** Entregar duas origens, headers e testes no navegador com/sem credenciais e origin rejeitada.
- **AULA-059 — CSP, Security Headers e Browser Protections:** Fornecer ambos os headers, página legítima, violação benigna, relatório e migração para enforcement.
- **AULA-060 — Encadeamento de Vulnerabilidades Web:** Dar cenário concreto autorizado com pré-condições, evidência por etapa e prova de quebra da cadeia.

### 61–78

Comandos de enumeração são aproveitáveis. A cadeia AD depende de domínio, RSAT, contas, DNS, relógio, GPO e audit policy não entregues. Diferenciar inventário de validação de vulnerabilidade; /health e banner não provam impacto.

- **AULA-061 — Enumeração Linux:** Anotar outputs e conectar serviço, usuário, capabilities e arquivo gravável a uma hipótese refutável.
- **AULA-062 — Enumeração Windows:** Preparar VM/contas e saídas de serviços, grupos e ACL com interpretações comparadas.
- **AULA-063 — Privilege Escalation Linux:** Provisionar exemplo mínimo de permissão indevida em VM e demonstrar correção reversível.
- **AULA-064 — Privilege Escalation Windows:** Mostrar caminho, permissões efetivas e conta do serviço; usar fixture benigna e validar hardening.
- **AULA-065 — Serviços, permissões e configurações inseguras:** Criar recursos de lab explicitamente, comparar owner/mode e documentar rollback sem tocar serviços reais.
- **AULA-066 — Nmap avançado e Service Fingerprinting:** Construir matriz de serviços e demonstrar perfis de coleta e divergência entre banner e serviço real.
- **AULA-067 — Vulnerability Scanning profissional — Nessus/OpenVAS/Nuclei:** Fixar templates revisados, versão, alvo local e limites; comparar Nessus/OpenVAS/Nuclei por evidência.
- **AULA-068 — CVE, CWE, CVSS e advisories:** Escolher advisory oficial com versão corrigida e resolver CVE/CWE/CVSS sem confundir risco contextual.
- **AULA-069 — Validação segura de PoCs em laboratório:** Definir propriedade vulnerável benigna observável, versão afetada/corrigida e critério de negação.
- **AULA-070 — Active Directory fundamentals:** Documentar DNS/tempo/DC/cliente/contas e rastrear autenticação e acesso autorizado.
- **AULA-071 — LDAP, Kerberos, NTLM:** Fornecer traces sanitizados, TGT/TGS, consultas LDAP e casos de erro de relógio/SPN.
- **AULA-072 — Enumeração AD:** Criar OU/usuários/grupos fictícios e explicar resultado de consultas e limitações da visibilidade.
- **AULA-073 — Misconfigurations em AD:** Fornecer ACEs comentadas e teste de permissão efetiva antes/depois da delegação.
- **AULA-074 — Privilege Escalation AD:** Construir grafo pequeno com pré-condições e caminho interrompido por mudança de permissão.
- **AULA-075 — Lateral Movement em laboratório:** Provisionar acesso remoto benigno autorizado com origem/destino e log de autenticação correlacionado.
- **AULA-076 — GPO e permissões:** Demonstrar política em OU de teste e gpresult, conflito e rollback.
- **AULA-077 — AD Hardening:** Atualizar administração privilegiada com referência Microsoft e medir controles com teste de acesso.
- **AULA-078 — Detection in Active Directory:** Fornecer EVTX sintético/exportado de lab e correlação de logon, privilégio e alteração de grupo.

### 79–100

Melhor concentração de exemplos defensivos específicos: Sigma, YARA, logs, árvores e métricas. Faltam datasets, geradores, schemas/pipelines e falsos positivos resolvidos. Não classificar query sintaticamente plausível como detecção operacional.

- **AULA-079 — Logs Windows/Linux:** Gerar evento benigno Linux/Windows, filtrar janela temporal e preservar identidade/fuso.
- **AULA-080 — Sysmon:** Completar configuração mínima e geração de ProcessCreate com campos e falso positivo comentados.
- **AULA-081 — Wireshark:** Fornecer PCAP pequeno com frames esperados, filtro de captura versus display e reconstrução de fluxo.
- **AULA-082 — IDS/IPS com Suricata:** Fixar versão/sintaxe, executar teste de configuração e replay local; explicar alerta benigno versus suspeita.
- **AULA-083 — SIEM:** Fornecer dados sintéticos, query e janela/threshold com true/false positives explicados.
- **AULA-084 — MITRE ATT&CK:** Mapear pequeno caso com IDs, versão e justificativa; diferenciar cobertura declarada de detecção validada.
- **AULA-085 — IOC, IOA e TTP:** Dar evidências com contexto e classificar, incluindo indicadores fracos e contraexemplos.
- **AULA-086 — Sigma:** Fornecer eventos positivos e negativos, conversão de campos e validação do resultado.
- **AULA-087 — YARA:** Entregar dois arquivos de fixture e comando YARA com saída esperada e limite de regra literal.
- **AULA-088 — Threat Hunting:** Fornecer linhas de processo e query, provar cobertura da fonte e comparar atividade administrativa normal.
- **AULA-089 — Incident Response:** Criar injects completos, autoridade de decisão e comparação de contenção; alinhar NIST SP 800-61r3.
- **AULA-090 — DFIR básico:** Fornecer artefato sintético, registro de aquisição e verificação com original/cópia e limites forenses.
- **AULA-091 — Arquitetura de antivírus:** Explicar pipeline real de decisões e fornecer features sintéticas, resultados e limitações do toy model.
- **AULA-092 — Assinaturas, hashes e reputação:** Comparar arquivos quase iguais e fonte de reputação fictícia; distinguir integridade, identidade e malícia.
- **AULA-093 — Heurística:** Entregar dataset e explicar features, threshold e falsos positivos sem apresentar score toy como AV real.
- **AULA-094 — Análise comportamental:** Adicionar PID/ProcessGuid/tempo e caso de eventos não relacionados para testar a inferência.
- **AULA-095 — Sandboxing:** Dar configuração concreta de isolamento e testes de rede/shared folders com restauração.
- **AULA-096 — Exploit Protection:** Anotar output e comparar binário próprio com flags e limites de ASLR/DEP/CFG.
- **AULA-097 — EDR e telemetria:** Disponibilizar eventos coerentes, campos obrigatórios e regra que distingue ação legítima.
- **AULA-098 — Process Trees:** Adicionar ProcessGuid/tempos e caso órfão, produzir árvore resolvida e limites da inferência.
- **AULA-099 — Falsos positivos e falsos negativos:** Explicitar população, matriz de confusão completa e precision/recall com casos de borda.
- **AULA-100 — Detection Engineering aplicado:** Entregar regra, corpus rotulado e relatório de regressão com cobertura e falsos positivos.

### 101–130

Vocabulário de C/internals/RE está presente, mas definições e flashcards circulares dominam. cc --version não substitui fonte/binário, disassembly e debugging. Capstone 130 precisa de artefatos e investigação integrada, não apenas matriz.

- **AULA-101 — C aplicado à Segurança:** Fornecer C completo com tipos, warnings e undefined behavior controlado, build e saída comentados.
- **AULA-102 — Ponteiros:** Explicar aliasing, dereferência, NULL e lifetime com diagrama de memória e dois casos resolvidos.
- **AULA-103 — Stack e Heap:** Demonstrar duração automática/dinâmica, falha de alocação, ownership e saída do sanitizer.
- **AULA-104 — Memória Virtual:** Explicar páginas, permissões e fault com mapa anotado e processo local controlado.
- **AULA-105 — Processes e Threads:** Criar duas threads, estado compartilhado, race e mutex com resultados reproduzíveis.
- **AULA-106 — Windows API:** Entregar projeto Windows C, tipos/handles/GetLastError e execução no shell explicitado.
- **AULA-107 — DLLs:** Compilar EXE/DLL próprios e mostrar export/import, caminho de carregamento e falha controlada.
- **AULA-108 — Formato PE:** Fornecer PE próprio, headers/seções/imports anotados e exercício de mapeamento de endereço.
- **AULA-109 — User Mode vs Kernel Mode:** Traçar API→syscall→kernel e relacionar privilégio, address space e falhas de acesso.
- **AULA-110 — Windows Internals:** Construir investigação guiada de processo próprio com handles, token, módulos e memória.
- **AULA-111 — Assembly x86/x64:** Fornecer main e builds x86/x64, sintaxe escolhida e rastreamento de registradores/flags.
- **AULA-112 — Registradores e Instruções:** Resolver sequência curta mov/add/cmp com valores, flags e tamanhos de operandos.
- **AULA-113 — Stack Frames e Calling Conventions:** Comparar ABI Windows x64 e System V separadamente com prólogo, argumentos e alinhamento.
- **AULA-114 — Jumps, Calls e Control Flow:** Fornecer função com branch/call e caminho resolvido, breakpoint e retorno.
- **AULA-115 — Ghidra:** Entregar binário próprio, roteiro de importação e função reconstruída com evidência.
- **AULA-116 — x64dbg:** Fornecer build Windows e percurso register/memory/step-over/step-into em função simples.
- **AULA-117 — Decompilation:** Gerar binários próprios nas duas otimizações e explicar artefatos de decompilação e incerteza.
- **AULA-118 — Xrefs, Strings e Imports:** Dar string com duas referências e import irrelevante; reconstruir uso e evitar conclusão por nome.
- **AULA-119 — Debugging dos próprios executáveis:** Entregar bug benigno, símbolos, breakpoint e observações que isolam causa de sintoma.
- **AULA-120 — Reconstrução de lógica:** Oferecer binário de função simples, entradas/saídas e reconstrução com testes de equivalência.
- **AULA-121 — Packing e Unpacking:** Gerar e empacotar toy binary, comparar seções/imports/entropia e documentar limites do UPX.
- **AULA-122 — Obfuscation e Deobfuscation:** Comparar função clara e transformação simples, recuperar lógica e validar com testes.
- **AULA-123 — Anti-Debugging:** Usar executável próprio que registra presença de debugger e discutir falso positivo/portabilidade.
- **AULA-124 — Anti-VM / Anti-Analysis:** Fornecer sinais sintéticos de ambiente, confiança e exemplos de virtualização legítima.
- **AULA-125 — Anti-Tamper:** Comparar alteração detectada com hash protegido e assinatura; explicar quem protege o verificador.
- **AULA-126 — Code Integrity:** Distinguir integridade por hash, assinatura e política de execução com binário próprio assinado/teste.
- **AULA-127 — Proteções de licença em software próprio:** Fornecer emissão/verificação offline sintética, clock/expiração e limite de confiança no cliente.
- **AULA-128 — Analisando nossas próprias proteções:** Comparar duas proteções do mesmo binário com evidência, hipótese adversária e limites medidos.
- **AULA-129 — Hardening contra Reverse Engineering:** Demonstrar símbolos/debug info/segredos e integridade em builds próprios, preservando suporte/diagnóstico.
- **AULA-130 — Capstone — Análise e Hardening de um binário próprio:** Alinhar objetivo e entregar binário/fonte, relatório resolvido, patch e regressão.

### 131–160

A triagem é anunciada sem amostra educacional, PCAP, EVTX e dump de memória. Entropy 135 contém ROP/DEP indevido. EICAR é útil para teste benigno de AV, mas não substitui uma fixture comportamental completa.

- **AULA-131 — Introdução a Malware:** Entregar arquivo educacional inerte e diferenciar teste AV de comportamento de malware.
- **AULA-132 — Tipos de Malware:** Comparar exemplos históricos referenciados e fixtures inertes por persistência/propagação/impacto.
- **AULA-133 — Static Analysis:** Fornecer amostra educacional, hash, file/strings/imports e hipóteses com limites.
- **AULA-134 — Hashes, Strings, Imports e Metadata:** Preparar dois binários próprios e diferenciar evidência de tipo/identidade de evidência de malícia.
- **AULA-135 — Entropy e Indicadores de Packing:** Substituir contaminação por entropia de Shannon, script, janelas e comparação texto/comprimido/aleatório.
- **AULA-136 — Laboratório Windows Isolado:** Documentar VM, rede, clipboard/shared folders, snapshot e testes de contenção com tráfego benigno.
- **AULA-137 — REMnux:** Fixar imagem/versão e conduzir triagem de fixture inerte com outputs e isolamento.
- **AULA-138 — Process Monitor e Process Explorer:** Gerar processo benigno que cria arquivo, aplicar filtros e correlacionar eventos/PID/tempo.
- **AULA-139 — Autoruns e Persistence:** Criar tarefa/entrada benigna em VM e comparar export antes/depois com cleanup.
- **AULA-140 — Dynamic Analysis:** Fornecer simulador inerte com eventos determinísticos e comparar hipóteses estática/dinâmica.
- **AULA-141 — Process e Child Process Analysis:** Entregar eventos parent/child com ProcessGuid e um falso relacionamento por reutilização de PID.
- **AULA-142 — Registry e File System Artifacts:** Gerar chave/arquivo benignos em VM e registrar caminho, timestamp, processo e reversão.
- **AULA-143 — Network Behavior:** Fornecer cliente local e tráfego conhecido; correlacionar host logs e PCAP sem inferir PID do pacote.
- **AULA-144 — FakeNet-NG:** Montar rede isolada e resposta DNS/HTTP simulada; provar que tráfego não alcança destinos externos.
- **AULA-145 — Malware Traffic:** Entregar tráfego sintético com DNS/HTTP, baseline e hipóteses alternativas.
- **AULA-146 — PCAP + Wireshark:** Fornecer captura pequena com fluxos anotados, filtro, timestamps e limitações de TLS.
- **AULA-147 — C2 e Beaconing — análise defensiva:** Gerar heartbeat benigno com/sem jitter e comparar atualização legítima versus hipótese C2.
- **AULA-148 — Memory Forensics:** Indicar dump educacional licenciado com hash/versão, aquisição e limites de interpretação.
- **AULA-149 — Volatility:** Fixar Volatility 3, dump/símbolos e resolver pslist/pstree com artefatos e erros comuns.
- **AULA-150 — Extração de IOCs:** Fornecer IOC derivado de fixture, provenance, expiração e conversão estruturada com contraexemplo.
- **AULA-151 — YARA aplicado:** Entregar arquivos positivos/quase iguais/negativos e medir falsos positivos da regra.
- **AULA-152 — Sigma aplicado:** Especificar Image e ParentImage, backend e eventos que diferenciem filho legítimo/suspeito.
- **AULA-153 — Detection Rules:** Entregar contrato de dados, regra, testes positivos/negativos e limites de cobertura.
- **AULA-154 — MITRE ATT&CK Mapping:** Associar comportamento sintético a técnica/subtécnica com versão e incerteza documentadas.
- **AULA-155 — Persistence Detection:** Gerar persistência benigna reversível e comparar alteração administrativa autorizada.
- **AULA-156 — Suspicious Execution:** Fornecer processo/linha de comando/assinatura/origem e caso administrativo similar.
- **AULA-157 — Suspicious PowerShell:** Fornecer script benigno, fontes habilitadas, evento e comparação com automação legítima.
- **AULA-158 — Process Injection Detection:** Entregar eventos simulados rotulados e hipóteses alternativas; não exigir payload operacional para ensinar detecção.
- **AULA-159 — SIEM Correlation:** Fornecer fontes distintas com IDs/clock e consulta que rejeite correlação espúria.
- **AULA-160 — Capstone — Investigação completa de amostra educacional:** Entregar pacote inerte integrado com gabarito parcial, timeline, regras e relatório reproduzível.

### 161–180

Todas as 20 unidades chamam make_fixtures.py ausente e ocultam erro. Precisa de cadeia fonte→build→input→crash→causa→patch→regressão, com mitigadores isolados e diferenças entre crash e explorabilidade.

- **AULA-161 — Memory Corruption:** Entregar programa mínimo com contrato de memória quebrado, crash, correção e regressão.
- **AULA-162 — Buffer Overflow:** Explicar decaimento array→ponteiro, contrato de capacidade e testes de limites com sanitizer.
- **AULA-163 — Debugger e Crash Analysis:** Fornecer crash benigno, símbolos e triagem de stack/registros sem concluir exploitability pelo crash.
- **AULA-164 — Stack Overflow:** Demonstrar recursão excessiva e violação de buffer em fixtures distintas com diagnósticos.
- **AULA-165 — Heap Fundamentals:** Construir sequência malloc/free e uso inválido diagnosticado; evitar tratar detalhes de allocator como universais.
- **AULA-166 — ASLR:** Comparar builds PIE/não PIE em OS definido, execuções repetidas e mapas, explicando limites de cast.
- **AULA-167 — DEP / NX:** Observar mappings e flags de binário próprio; explicar W^X e por que NX não corrige memória.
- **AULA-168 — Stack Canaries:** Criar matriz de builds com/sem proteção e explicar qual mecanismo produziu cada diagnóstico.
- **AULA-169 — ROP em laboratório educacional:** Usar modelo de stack e sequência simbólica inerte para explicar reutilização de código e mitigadores.
- **AULA-170 — Exploit Mitigations:** Construir tabela com evidência de flags/runtime e testes independentes por mitigador.
- **AULA-171 — Fuzzing:** Fornecer parser, harness, build, seeds e bug benigno com minimização e patch.
- **AULA-172 — Coverage-Guided Fuzzing:** Fixar número de execuções e mostrar evolução do corpus/cobertura e critérios de parada.
- **AULA-173 — Sanitizers:** Fornecer programa pequeno, compile/link corretos e stacktrace com causa e regressão.
- **AULA-174 — Crash Triage:** Entregar três inputs com causas repetidas/distintas e agrupar por causa, não só endereço.
- **AULA-175 — Root Cause Analysis:** Percorrer input→erro de cálculo→acesso inválido e distinguir causa de local do crash.
- **AULA-176 — Reproduzir Vulnerabilidade:** Empacotar reproducer benigno com hash, build, expected failure e teste da versão corrigida.
- **AULA-177 — Safe PoC:** Fornecer teste mínimo da propriedade violada, limite de efeitos e negativa após patch.
- **AULA-178 — Patch Diff:** Mostrar diff completo, contrato de tamanho explícito e regressão de limites.
- **AULA-179 — Variant Analysis:** Criar três padrões aparentados e justificar quais compartilham a causa, com testes.
- **AULA-180 — Capstone — CVE Research e correção reproduzível:** Escolher vulnerabilidade educacional autorizada, versão afetada/corrigida e pacote de reprodução limitado.

### 181–190

Escopo/ROE e intenção defensiva são pontos positivos. Simulações, IDs de técnicas, logs e cleanup não formam exercícios executáveis. Distinguir emular resultado de explorar uma falha e medir detecção com atividades benignas.

- **AULA-181 — Red Team Methodology:** Dar ROE preenchido, decisões de go/no-go, objetivos medidos e comunicação em cenário fictício.
- **AULA-182 — Adversary Emulation:** Escolher testes benignos revisados, IDs/versões, pré-condições, evidência e cleanup.
- **AULA-183 — Initial Access em laboratório:** Fornecer cenário inerte de entrada autorizada e logs, sem campanha real ou credenciais externas.
- **AULA-184 — Privilege Escalation em laboratório:** Distinguir emulação de resultado e exploração da fronteira; mostrar contexto anterior/posterior.
- **AULA-185 — Persistence — ofensivo e defensivo:** Criar tarefa benigna em VM, coletar evento e comprovar remoção após cleanup.
- **AULA-186 — Credential Access — conceitos e defesa:** Fornecer eventos rotulados e controles de proteção de credenciais sem coletar segredos reais.
- **AULA-187 — Lateral Movement em laboratório:** Montar acesso remoto benigno com logs em ambos os hosts e reversão de autorização.
- **AULA-188 — Defense Evasion — conceitos e telemetria:** Usar telemetria simulada de sensor interrompido e comparar falha operacional e hipótese adversária.
- **AULA-189 — Arquitetura conceitual de C2:** Usar cliente/servidor exclusivamente local e sinais sintéticos; medir canal e controle sem implantar C2 real.
- **AULA-190 — Capstone — Purple Team Exercise:** Fixar três testes, contratos de evidência, papéis, replay e relatório de cobertura defensiva.

### 191–200

Temas atuais foram comprimidos em fragmentos declarativos: IAM pseudo, CI sem steps, RLS sem ativação, Electron sem contexto. Cada tecnologia exige implementação mínima própria, identidade e testes de permissão.

- **AULA-191 — Docker Security:** Entregar app mínimo, build/run e testes de capabilities, readonly rootfs, secrets e versão fixa.
- **AULA-192 — Kubernetes Security:** Fornecer manifesto válido, cluster local e testes RBAC/network policy/Pod Security.
- **AULA-193 — IAM:** Escolher provedor/emulador e resolver allow/deny/condições com ações e recursos válidos.
- **AULA-194 — Secrets Management:** Usar segredo fictício e comprovar detecção, revogação, nova credencial e tratamento do histórico.
- **AULA-195 — CI/CD Security:** Entregar pipeline mínimo com permissões, dependências fixas, teste falho e evidência de bloqueio.
- **AULA-196 — SAST, DAST e SCA em pipelines:** Integrar fixtures e relatórios por classe, threshold justificado e exceção documentada.
- **AULA-197 — Software Supply Chain:** Gerar SBOM e attestation de app toy e verificar dependência alterada/assinatura.
- **AULA-198 — Supabase / Firebase Security:** Demonstrar RLS habilitada, SELECT/INSERT/UPDATE e isolamento; separar tutorial Firebase Rules com emulador.
- **AULA-199 — Serverless Security:** Fornecer handler executável, validação, repetição de evento e mínimos privilégios com logs.
- **AULA-200 — Capstone — Electron/Desktop Security e aplicação moderna:** Entregar main/preload/renderer/IPC com validação de sender/args e teste de autorização local.

### 201–208

Princípio modelo propõe/política decide é sólido. Rotular prompt não cria isolamento; bool approved não representa aprovação vinculada; RAG requer ACL e revogação reais. Edição OWASP 2026 existe, mas a aula não ensina seu conjunto de categorias.

- **AULA-201 — LLM Security Fundamentals:** Construir fluxo pequeno completo com política determinística e log de allow/deny verificável.
- **AULA-202 — Prompt Injection:** Comparar injeção direta/indireta em dados sintéticos com autorização externa e assertivas independentes do texto do modelo.
- **AULA-203 — Sensitive Information Disclosure:** Fornecer segredo-canário fictício, contexto mínimo e testes negativos de formato/fragmentação.
- **AULA-204 — RAG Security:** Entregar documentos sintéticos com ACL/provenance, dois usuários e testes de recuperação/citação indevida.
- **AULA-205 — Tool / Agent Abuse:** Definir approval record e validar vínculo/replay no mock agent com log de decisão.
- **AULA-206 — Model & AI Supply Chain:** Fornecer artefato sintético versionado, verificador e teste de alteração/supply chain.
- **AULA-207 — OWASP GenAI / LLM Top 10 2026:** Fixar edição oficial e mapear cada categoria a cenário/controle/teste, distinguindo LLM e Agentic Top 10.
- **AULA-208 — Defesa de Agentes e Capstone AI Security:** Fornecer agente mock integrado, documentos, ferramentas limitadas, política, evidências e rubricar bypass/retorno legítimo.

### 209–218

Dez produtos distintos têm praticamente o mesmo corpo e exemplo preenchido abstrato. Avaliação por artefatos é adequada ao capstone, mas deve usar insumos, produtos-modelo e critérios específicos da fase; quiz/flashcard são opcionais aqui.

- **AULA-209 — Definição do laboratório final:** Entregar escopo fictício, ativos permitidos, topologia e decisões de isolamento com critérios de revisão.
- **AULA-210 — Threat Modeling do laboratório:** Fornecer DFD/fronteiras e ameaça priorizada vinculada ao laboratório final.
- **AULA-211 — Reconhecimento e inventário autorizado:** Fornecer inventário sintético, comando de coleta autorizado e divergência investigada.
- **AULA-212 — Pentest controlado — hipóteses e validação:** Dar hipótese, evidência esperada, negação e critério de parada por achado de lab.
- **AULA-213 — Exploração controlada e prova de impacto:** Demonstrar impacto mínimo com dados fictícios, antes/depois e limite do que foi provado.
- **AULA-214 — Coleta e análise de logs:** Entregar logs com fusos/identidades e timeline construída com incertezas explícitas.
- **AULA-215 — Detecções — YARA, Sigma, EDR e SIEM:** Fornecer uma regra por fonte aplicável, positivo, negativo e resultado de replay.
- **AULA-216 — Correções e Hardening:** Dar plano preenchido com responsável, dependência, critério de aceite e risco residual.
- **AULA-217 — Reteste e regressão:** Entregar reteste do mesmo achado e matriz de controles com evidência vinculada.
- **AULA-218 — Relatório e apresentação final:** Fornecer exemplo redigido para público técnico/executivo, limitações, fontes de evidência e pontuação comentada.

### Logic

Não há algoritmos resolvidos: o exemplo repete entrada→regra do título→saída. Ensinar teste de mesa, condições, loops, funções, recursão e estados com valores concretos antes de pedir aplicação em segurança.

- **LOG-01 — Algoritmos e decomposição de problemas:** Decompor problema concreto em entradas, etapas, invariantes e teste de mesa preenchido.
- **LOG-02 — Variáveis, tipos e memória conceitual:** Comparar valor, tipo e representação de variável em uma sequência de atribuições.
- **LOG-03 — Operadores e expressões:** Resolver precedência, coerção e expressões booleanas com tabela de valores.
- **LOG-04 — Condições:** Executar condição verdadeira/falsa e caso de fronteira com decisão justificada.
- **LOG-05 — Laços de repetição:** Traçar contador e condição de parada, incluindo zero iterações e off-by-one.
- **LOG-06 — Arrays e coleções:** Percorrer coleção, índice válido e limite com tabela de elementos.
- **LOG-07 — Funções:** Definir parâmetros, retorno e contrato de função, com duas chamadas resolvidas.
- **LOG-08 — Escopo:** Mostrar shadowing e escopos local/global com valores antes e depois.
- **LOG-09 — Recursividade:** Traçar chamadas recursivas, caso base e terminação usando pilha de chamadas.
- **LOG-10 — Estruturas de dados básicas:** Comparar lista, fila, pilha e mapa em operações e custos básicos.
- **LOG-11 — Entrada → processamento → saída:** Resolver transformação completa de entrada em saída com validação na fronteira.
- **LOG-12 — Estado e mudança de estado:** Construir máquina de estados pequena com transição permitida e inválida.
- **LOG-13 — Buscar e filtrar dados:** Executar busca/filtro em dados definidos, incluindo nenhum resultado e duplicatas.
- **LOG-14 — Contadores, acumuladores e flags:** Separar contador, acumulador e flag em rastreamento de loop.
- **LOG-15 — Validação de entrada:** Validar tipo, intervalo e formato com entradas de fronteira.
- **LOG-16 — Tratamento de erros:** Propagar erro e recuperar sem ocultar falha, com resultado especificado.
- **LOG-17 — Debugging lógico:** Depurar erro lógico com hipótese, teste de mesa e contraexemplo.
- **LOG-18 — Ler código de outra pessoa:** Anotar código real de outra pessoa e inferir contratos sem executar primeiro.
- **LOG-19 — Refatoração básica:** Refatorar função mantendo comportamento por testes de equivalência.
- **LOG-20 — Projeto lógico final:** Entregar problema, dados e gabarito parcial para projeto lógico integrado.

### Python

16/20 exemplos técnicos são a mesma list comprehension. JSON/regex/hash são melhores sementes, porém arquivos, exceções, venv, sockets, CLI e parsing não são efetivamente ensinados.

- **PY-01 — Python do zero:** Instalar/invocar Python e executar primeiro script, explicando indentation e saída.
- **PY-02 — Variáveis e tipos:** Comparar str/int/bool, mutabilidade e conversão com erro de tipo.
- **PY-03 — Condições e loops:** Demonstrar if/for/while, break e caso de lista vazia.
- **PY-04 — Funções:** Criar def com parâmetros, retorno e escopo, incluindo teste de contrato.
- **PY-05 — Listas, dicts e sets:** Comparar listas/dicts/sets e operações de chave, ordem e duplicação.
- **PY-06 — Arquivos:** Ler/gravar arquivo com with, encoding e tratamento de caminho inexistente.
- **PY-07 — Exceções:** Demonstrar try/except/finally e distinguir exceções previstas de falhas ocultadas.
- **PY-08 — Módulos e ambientes:** Criar módulo, venv e dependência fixada; explicar resolução de imports.
- **PY-09 — JSON, CSV e dados:** Complementar JSON com CSV, tipos, aspas, encoding e input malformado.
- **PY-10 — Requests e HTTP:** Fornecer servidor local e comparar status, timeout, redirects e erro HTTP.
- **PY-11 — Sockets:** Construir cliente/servidor socket em loopback com framing e timeout.
- **PY-12 — Regex:** Explicar grupos/anchors e caso sem match, evitando regex excessivamente permissiva.
- **PY-13 — Processos:** Usar subprocess com argumentos separados, timeout, exit code e stderr.
- **PY-14 — Automação:** Construir automação idempotente com dry-run e falha parcial visível.
- **PY-15 — Parsing de logs:** Parsear arquivo de logs com registros válidos/inválidos e campos temporais.
- **PY-16 — Scanner defensivo:** Implementar scanner limitado a loopback com timeout e classificação de portas.
- **PY-17 — Hashes e arquivos:** Calcular hash de arquivo em chunks e comparar alteração de um byte.
- **PY-18 — PCAP e dados de segurança:** Ler PCAP sintético, extrair fluxo e discutir limites da criptografia.
- **PY-19 — Ferramentas CLI:** Implementar argparse, help, validação de flags e exit codes.
- **PY-20 — Projeto Python para Security:** Integrar CLI de triagem defensiva com fixture, testes e relatório.

### JavaScript/TypeScript

9/10 exemplos JS usam map; os cinco TS repetem User/role. DOM tem exemplo pertinente. Faltam closures, eventos, async, fetch, Node/Express e diferença entre tipo estático e validação em runtime.

- **JS-01 — JavaScript essencial:** Explicar tipos, let/const, coerção e execução de programa mínimo.
- **JS-02 — Objetos e arrays:** Comparar propriedade, array e mutabilidade com referências compartilhadas.
- **JS-03 — Funções e closures:** Demonstrar closure capturando estado e limites de escopo.
- **JS-04 — DOM:** Completar HTML do exemplo textContent e contrastar DOM com string HTML.
- **JS-05 — Eventos:** Registrar evento, target/currentTarget, propagação e remoção do listener.
- **JS-06 — Async / Promises:** Rastrear Promise, await e rejeição com sequência de microtasks.
- **JS-07 — Fetch e HTTP:** Executar fetch local e tratar status HTTP, rede, timeout e JSON inválido.
- **JS-08 — Node.js:** Configurar módulo Node, runtime e APIs de filesystem/processo.
- **JS-09 — Express:** Montar Express com middleware, rota e handler de erro.
- **JS-10 — APIs:** Criar API com contrato request/response, validação e teste de autorização.
- **TS-01 — TypeScript:** Configurar tsc/tsconfig strict e demonstrar tipo estático versus runtime.
- **TS-02 — Interfaces e types:** Comparar interface, type, union e narrowing em valores concretos.
- **TS-03 — Generics:** Criar função genérica com constraint e inferência, sem usar any.
- **TS-04 — Type safety para APIs:** Validar JSON em runtime e separar unknown de tipo confiável de API.
- **TS-05 — Segurança aplicada a Node/TypeScript:** Aplicar validação e autorização em Node, demonstrando que tipo não garante segurança.

### C

14 exemplos usam if; seis usam print de ponteiro. Arrays, strings, structs, heap/malloc, arquivos e sanitizers não recebem código correspondente. Esta lacuna inviabiliza progressão segura para 101–180.

- **C-01 — Sintaxe:** Explicar include/main/statement e compilação de primeiro programa.
- **C-02 — Tipos:** Comparar tamanhos, signedness, conversões e formatos de printf.
- **C-03 — Condições:** Explicar expressão condicional e demonstrar ambos os ramos com limites.
- **C-04 — Loops:** Executar for/while com invariantes e índices de fronteira.
- **C-05 — Funções:** Definir protótipo, parâmetros, retorno e passagem por valor.
- **C-06 — Arrays:** Declarar e percorrer array, explicar capacidade e acesso fora de limite.
- **C-07 — Strings:** Demonstrar terminador NUL, comprimento versus capacidade e cópia segura.
- **C-08 — Structs:** Definir struct, inicialização, layout/padding e acesso por ponteiro.
- **C-09 — Ponteiros:** Explicar endereço/dereferência, NULL e lifetime além do print de ponteiro.
- **C-10 — Endereços:** Comparar endereço, offset e aritmética de ponteiros dentro do mesmo objeto.
- **C-11 — Stack:** Relacionar variáveis automáticas, chamadas e duração de armazenamento.
- **C-12 — Heap:** Demonstrar alocação dinâmica real, ownership e falha de alocação.
- **C-13 — malloc e free:** Executar malloc/free, checar NULL e diagnosticar use-after-free controlado.
- **C-14 — Manipulação de memória:** Contrastar memcpy/memmove, sobreposição e capacidade do destino.
- **C-15 — Arquivos:** Abrir/ler/escrever/fechar arquivo com verificação de erro e bytes lidos.
- **C-16 — Compilação:** Separar preprocessing/compile/link e flags de warnings/debug.
- **C-17 — Debugging:** Depurar fonte própria com breakpoint, variável e backtrace.
- **C-18 — Código inseguro vs seguro:** Comparar contratos de tamanho/lifetime em código inseguro e corrigido.
- **C-19 — Sanitizers:** Compilar/ligar ASan/UBSan e interpretar um diagnóstico de fixture.
- **C-20 — Projeto C:** Entregar projeto C com parsing, testes de limites e build reproduzível.

### Bash

Os dez exemplos repetem printf/grep/rm em /tmp/lab.txt. Quoting, expansão, loops, funções, processos e diagnóstico de rede precisam de operações próprias. Ensinar mktemp/trap e não colidir com arquivos existentes.

- **BASH-01 — Terminal:** Explicar shell, argv, diretório e status de saída de comando.
- **BASH-02 — Filesystem:** Criar árvore temporária e manipular paths com espaços e permissões.
- **BASH-03 — Pipes e redirection:** Comparar stdin/stdout/stderr, pipe e exit status da pipeline.
- **BASH-04 — grep e find:** Combinar grep/find com fixtures e distinguir regex de glob.
- **BASH-05 — Variáveis:** Demonstrar expansão/quoting, variável vazia e word splitting.
- **BASH-06 — Loops:** Iterar dados com while/read e for, preservando nomes com espaços.
- **BASH-07 — Funções:** Criar função com argumentos, local, retorno e status.
- **BASH-08 — Processos:** Gerir processo filho, sinal, wait e cleanup reversível.
- **BASH-09 — Networking:** Diagnosticar listener local e timeout de conexão com comandos reais.
- **BASH-10 — Automação defensiva:** Criar script defensivo idempotente com mktemp/trap, logging e dry-run.

### PowerShell

As dez unidades repetem Get-Process/Select/Format-Table. Pipeline de objetos é uma boa introdução, mas não ensina serviços, rede, registry, AD ou coleta. Preservar objetos antes de formatar para tela.

- **PS-01 — Objetos e pipeline:** Diferenciar objeto de texto e manter objetos antes de Format-Table.
- **PS-02 — Filesystem:** Criar/ler arquivo e tratar LiteralPath, encoding e acesso negado.
- **PS-03 — Processos:** Filtrar processo por propriedade, obter PID/parent e limites de permissão.
- **PS-04 — Serviços:** Consultar serviço e dependência, comparar estado e configuração.
- **PS-05 — Rede:** Usar Get-NetTCPConnection/Test-NetConnection em alvo local.
- **PS-06 — Registry:** Ler/criar chave HKCU de teste e restaurar estado anterior.
- **PS-07 — Eventos:** Filtrar Get-WinEvent por log/ID/janela e interpretar propriedades.
- **PS-08 — Active Directory:** Preparar RSAT/domínio de laboratório e consultar objeto AD autorizado.
- **PS-09 — Automação:** Criar função/script com parâmetros, ShouldProcess e tratamento de erros.
- **PS-10 — Coleta de evidências:** Exportar evidências estruturadas com timestamp, hash e metadados de coleta.

### Networks

Há definições específicas úteis, porém exemplos frequentemente inventariam IP/rotas. HTTP claro é reaproveitado em HTTPS/TLS; PCAP inexistente. Ensinar cabeçalhos/estados com traces e limites TLS 1.3.

- **NET-01 — O que é uma rede:** Descrever troca concreta entre dois nós e identificar link/endereço/protocolo.
- **NET-02 — Modelo OSI:** Mapear um request por camadas OSI e explicar limites do modelo.
- **NET-03 — TCP/IP:** Relacionar encapsulamento TCP/IP a cabeçalhos e unidades de dados.
- **NET-04 — IPv4:** Resolver CIDR/sub-rede/gateway com endereços e rotas de exemplo.
- **NET-05 — IPv6:** Explicar prefixo IPv6, link-local, NDP e ausência de broadcast.
- **NET-06 — MAC e Ethernet:** Interpretar frame Ethernet, MAC origem/destino e domínio de broadcast.
- **NET-07 — ARP:** Mostrar ARP request/reply e cache de vizinhos com captura local.
- **NET-08 — Switching:** Demonstrar tabela MAC, flooding e separação por VLAN.
- **NET-09 — Routing:** Resolver longest-prefix-match e rota padrão com tabela preenchida.
- **NET-10 — NAT:** Traçar tradução NAT e tabela de estados para fluxo de laboratório.
- **NET-11 — TCP:** Analisar sequência/ACK/janela e confiabilidade TCP em captura anotada.
- **NET-12 — Three-way handshake:** Mostrar SYN/SYN-ACK/ACK e falha de estabelecimento com frames reais.
- **NET-13 — Flags TCP:** Interpretar flags TCP em sequência, sem concluir ataque por flag isolada.
- **NET-14 — UDP:** Contrastar datagrama UDP, perda e responsabilidade da aplicação.
- **NET-15 — Portas:** Explicar portas locais/remotas e listener com ss e cliente local.
- **NET-16 — Sockets:** Demonstrar socket como endpoint/API e relacionar a conexão observada.
- **NET-17 — Estado de conexões:** Comparar LISTEN/ESTABLISHED/TIME-WAIT; ss -lnt só mostra listeners.
- **NET-18 — Retransmissão:** Gerar perda controlada e identificar retransmissão versus pacote duplicado.
- **NET-19 — MTU e fragmentação:** Explicar MTU, PMTUD, fragmentação IPv4 e comportamento IPv6 com exemplo.
- **NET-20 — Diagnóstico de conectividade:** Isolar falha de link/rota/DNS/serviço em diagnóstico resolvido.
- **NET-21 — DNS:** Distinguir consulta DNS de resolução NSS/hosts, com cache e NXDOMAIN.
- **NET-22 — DHCP:** Apresentar DHCP DORA/lease e captura de rede própria.
- **NET-23 — HTTP:** Fornecer servidor local e request/response HTTP com método/status/body.
- **NET-24 — HTTPS:** Trocar HTTP claro por HTTPS local com CA de laboratório e verificação.
- **NET-25 — TLS:** Executar handshake TLS, validar certificado e explicar chaves negociadas.
- **NET-26 — SSH:** Demonstrar SSH local, host key e autenticação sem desabilitar verificação.
- **NET-27 — FTP e SFTP:** Diferenciar FTP/SFTP em canais, autenticação e proteção do transporte.
- **NET-28 — SMTP e IMAP:** Traçar envio SMTP e acesso IMAP com comandos/respostas sanitizados.
- **NET-29 — SMB:** Explicar sessão SMB, share versus NTFS e acesso autorizado.
- **NET-30 — LDAP:** Consultar diretório de laboratório, DN/filtro/atributos e TLS.
- **NET-31 — Wireshark básico:** Fornecer PCAP/interface/gerador e acompanhar fluxo conhecido no Wireshark.
- **NET-32 — Filtros Wireshark:** Comparar capture filter e display filter com expressão e resultado.
- **NET-33 — TCP no PCAP:** Anotar frames TCP, sequência/ACK/retransmissão e encerramento.
- **NET-34 — DNS no PCAP:** Fornecer PCAP DNS e correlacionar transaction ID/query/answer/erro.
- **NET-35 — HTTP no PCAP:** Fornecer PCAP HTTP e reconstruir request/response com limites de privacidade.
- **NET-36 — TLS no PCAP:** Usar tráfego TLS real; distinguir visibilidade TLS 1.2/1.3, SNI/ECH e secrets de sessão.
- **NET-37 — Fluxos:** Agrupar fluxo por 5-tupla e direção com timestamps e contagem.
- **NET-38 — Baseline de rede:** Construir baseline quantitativo por host/protocolo/janela de tempo.
- **NET-39 — Tráfego anômalo:** Comparar anomalia com baseline e falso positivo plausível rotulado.
- **NET-40 — Projeto de análise de PCAP:** Entregar PCAP com questões, frames de evidência e relatório parcial.

### Linux

26/30 exemplos usam pwd/id/uname. Permissões e processos têm sementes melhores; systemd, logs, sudoers, capabilities e firewall não têm demonstração do mecanismo.

- **LNX-01 — Filesystem:** Explicar hierarquia Linux, paths absolutos/relativos e tipos de arquivo.
- **LNX-02 — Terminal:** Demonstrar quoting, redirection e status no terminal.
- **LNX-03 — Arquivos e diretórios:** Manipular arquivos/symlinks em diretório temporário com efeitos observados.
- **LNX-04 — Permissões:** Interpretar rwx octal/simbólico e comparar acesso real por dois usuários.
- **LNX-05 — Usuários e grupos:** Criar usuários/grupos de lab e mostrar identidade efetiva e suplementar.
- **LNX-06 — sudo:** Inspecionar sudo -l e explicar política/comando/identidade de destino.
- **LNX-07 — Processos:** Correlacionar PID/PPID/UID, estado e comando com processo benigno.
- **LNX-08 — Signals:** Comparar SIGTERM/SIGKILL e cleanup em processo próprio.
- **LNX-09 — Packages:** Escolher distro e demonstrar repositório, assinatura, versão e atualização de pacote.
- **LNX-10 — Environment:** Mostrar export, herança de ambiente e exposição de variáveis sensíveis fictícias.
- **LNX-11 — systemd:** Criar unit systemd de lab e interpretar dependências/journal.
- **LNX-12 — Serviços:** Comparar serviço habilitado/ativo/falhando e configuração efetiva.
- **LNX-13 — Logs e journalctl:** Gerar evento e filtrar journalctl por unit, boot e tempo.
- **LNX-14 — cron:** Criar agendamento de teste reversível e interpretar ambiente reduzido do cron.
- **LNX-15 — Discos:** Explicar partição/filesystem/uso com lsblk e df em fixture não destrutiva.
- **LNX-16 — Mounts:** Mostrar mount options e noexec/nosuid com limites explícitos.
- **LNX-17 — Networking:** Correlacionar endereço/rota/socket e diagnóstico local.
- **LNX-18 — SSH:** Configurar SSH de laboratório e retestar identidade/chave/permissões.
- **LNX-19 — Firewall:** Definir regra de firewall local com contadores, allow/deny e rollback.
- **LNX-20 — Troubleshooting:** Resolver incidente pequeno por hipótese e evidência, sem trocar várias variáveis.
- **LNX-21 — Ownership e permissões:** Separar owner/grupo/mode e demonstrar decisão efetiva de acesso.
- **LNX-22 — SUID e SGID:** Explicar UID real/efetivo e efeito de SUID/SGID em fixture segura.
- **LNX-23 — Capabilities:** Listar capabilities e demonstrar privilégio específico sem atribuir root genérico.
- **LNX-24 — sudoers:** Validar sudoers com visudo e testar regra mínima/revogação.
- **LNX-25 — Secrets:** Mostrar limites de env/file permissions e rotação de segredo fictício.
- **LNX-26 — Processos suspeitos:** Comparar processo suspeito com atividade administrativa legítima e contexto.
- **LNX-27 — Conexões:** Usar ss com PID/estado para conectar processo a socket.
- **LNX-28 — Logs de autenticação:** Gerar log de autenticação controlado e interpretar sucesso/falha/identidade.
- **LNX-29 — Hardening:** Aplicar baseline de hardening medido e retestar operação legítima.
- **LNX-30 — Auditoria final:** Entregar inventário, achado, evidência e reteste de VM Linux.

### Windows

25/30 exemplos repetem whoami/Get-Process. Services/Registry/Event Viewer têm algo específico; Security Logs coleta System. Tokens, UAC, PE, Sysmon e hardening precisam de VM e evidência própria.

- **WIN-01 — Arquitetura Windows:** Relacionar kernel/user mode, processos, objetos e serviços em exemplo.
- **WIN-02 — Usuários e grupos:** Comparar usuário/grupo/token efetivo em conta de laboratório.
- **WIN-03 — Filesystem:** Explicar paths Windows, links e atributos com arquivos de teste.
- **WIN-04 — NTFS:** Interpretar DACL/ACE/herança NTFS e acesso efetivo por dois usuários.
- **WIN-05 — Processos:** Correlacionar PID/parent/token/módulos de processo benigno.
- **WIN-06 — Threads:** Inspecionar threads e explicar scheduling versus isolamento de processo.
- **WIN-07 — Services:** Explicar Service Control Manager, conta e estado de serviço.
- **WIN-08 — Registry:** Interpretar hive/chave/valor/tipo e fazer alteração HKCU reversível.
- **WIN-09 — Scheduled Tasks:** Criar tarefa benigna de laboratório, trigger/action/identidade e cleanup.
- **WIN-10 — Environment:** Mostrar escopo de environment e expansão por processo.
- **WIN-11 — PowerShell:** Demonstrar cmdlets, objetos, pipeline e erros de PowerShell.
- **WIN-12 — Networking:** Correlacionar adaptador/rota/listener e diagnóstico local.
- **WIN-13 — Firewall:** Aplicar regra Windows Firewall em VM e verificar fluxo permitido/bloqueado.
- **WIN-14 — Services — administração:** Consultar dependências/conta/path de serviço e validar mudança reversível.
- **WIN-15 — Event Viewer:** Interpretar Provider/ID/XML, filtrar janela e exportar evento.
- **WIN-16 — Windows Update:** Verificar build/KB/reboot pendente e distinguir instalado de efetivo.
- **WIN-17 — Permissions:** Calcular permissões efetivas e comparar share/NTFS/herança.
- **WIN-18 — UAC:** Explicar token filtrado/elevação UAC e limite de boundary.
- **WIN-19 — Defender:** Observar configuração/telemetria do Defender com teste benigno oficial.
- **WIN-20 — Troubleshooting:** Resolver falha de serviço com eventos, permissões e hipótese testada.
- **WIN-21 — Access Tokens:** Inspecionar SID/grupos/privilégios do access token e impersonation conceitual.
- **WIN-22 — Integrity Levels:** Comparar integrity levels e MIC com acesso controlado.
- **WIN-23 — Process Tree:** Construir árvore temporal com ProcessGuid e processo pai encerrado.
- **WIN-24 — DLLs:** Mostrar DLL própria, exports/imports e carregamento com caminho definido.
- **WIN-25 — PE Basics:** Inspecionar PE próprio, headers/seções/RVA e arquitetura.
- **WIN-26 — Persistence Locations:** Comparar tarefas/Run keys/serviços de baseline e alteração benigna.
- **WIN-27 — Security Logs:** Consultar Security log com audit policy e IDs relevantes; System não substitui Security.
- **WIN-28 — Sysmon:** Instalar/configurar Sysmon em VM e gerar ProcessCreate com campos esperados.
- **WIN-29 — Hardening:** Aplicar controles Windows com evidência de configuração e reteste.
- **WIN-30 — Investigação final:** Entregar EVTX/processos/artefatos sintéticos para investigação integrada.

### Web Development

32/40 exemplos imprimem input.length. Cinco unidades HTTP mostram a mesma request, inclusive Response/Status; três Express mostram /health. Sem fundamentos reais a trilha AppSec fica dependente de conhecimento externo.

- **WEB-01 — Browser:** Traçar navegação, renderer, rede, DOM e fronteiras do browser.
- **WEB-02 — URL:** Parsear scheme/host/port/path/query/fragment e normalização de URL.
- **WEB-03 — HTTP Request:** Enviar request completo a servidor local e explicar método/headers/body.
- **WEB-04 — HTTP Response:** Mostrar response real com status/headers/body; request não ensina response sozinho.
- **WEB-05 — Headers:** Comparar headers de request/response e efeito de Content-Type/Cache-Control.
- **WEB-06 — Methods:** Demonstrar GET/POST/PUT/DELETE e idempotência com estado no servidor.
- **WEB-07 — Status Codes:** Comparar 2xx/3xx/4xx/5xx e tratamento no cliente.
- **WEB-08 — Cookies:** Mostrar Set-Cookie/Cookie, Path/Domain/Secure/HttpOnly/SameSite.
- **WEB-09 — Sessions:** Demonstrar login, ID de sessão, expiração e invalidação.
- **WEB-10 — Same-Origin:** Comparar origens por scheme/host/port e leitura cross-origin no navegador.
- **WEB-11 — HTML:** Construir documento HTML semântico e explicar parser/atributos/texto.
- **WEB-12 — Forms:** Enviar formulário GET/POST e validar campos do lado servidor.
- **WEB-13 — DOM:** Construir e modificar DOM, distinguir atributo/propriedade e source/sink.
- **WEB-14 — JavaScript no navegador:** Executar JS em página e explicar carregamento/escopo/event loop.
- **WEB-15 — Fetch:** Usar fetch com status, erro, credenciais e abort em serviço local.
- **WEB-16 — Storage:** Comparar localStorage/sessionStorage/cookie, escopo e risco de dados persistidos.
- **WEB-17 — SPA:** Demonstrar estado SPA, chamadas API e fronteira de autorização.
- **WEB-18 — Routing:** Separar routing cliente/servidor, parâmetros e fallback.
- **WEB-19 — CORS:** Montar duas origens e preflight com allowlist e credenciais.
- **WEB-20 — Browser Security:** Aplicar CSP/framing/HTTPS e observar efeito e limite de cada controle.
- **WEB-21 — Node e Express:** Completar instalação/runtime Express e request/response do /health.
- **WEB-22 — Rotas:** Adicionar rotas parametrizadas, métodos e rota inexistente.
- **WEB-23 — Middleware:** Demonstrar ordem next/error middleware e autenticação antes da rota.
- **WEB-24 — Controllers:** Criar controller fino com parsing, resposta e delegação.
- **WEB-25 — Services:** Implementar regra de domínio em service e testar invariante.
- **WEB-26 — Databases:** Criar banco local com schema, consulta e transação.
- **WEB-27 — SQL:** Executar SELECT/INSERT parametrizados e discutir identificadores.
- **WEB-28 — ORM:** Demonstrar model/relation/query ORM e SQL gerado, evitando N+1.
- **WEB-29 — Validação:** Validar tipos/limites/unknown fields em runtime e gerar erros claros.
- **WEB-30 — Error Handling:** Tratar exceção/async error com resposta sanitizada e log correlacionável.
- **WEB-31 — Authentication:** Implementar autenticação local, hash/verify e sessão sem confundir autorização.
- **WEB-32 — Authorization:** Implementar matriz ação/recurso/usuário e caso de acesso alheio.
- **WEB-33 — Sessions no backend:** Demonstrar armazenamento, fixação, rotação e revogação de sessão.
- **WEB-34 — JWT:** Emitir/verificar JWT com algoritmo/issuer/audience/exp e distinguir JWS/JWE.
- **WEB-35 — OAuth:** Traçar Authorization Code + PKCE e finalidade de access/ID token.
- **WEB-36 — REST:** Modelar recursos REST, métodos/status e paginação com contrato.
- **WEB-37 — GraphQL:** Criar schema/resolver GraphQL e autorização por objeto/custo.
- **WEB-38 — WebSocket:** Montar handshake WebSocket e mensagens com origin/schema/limites.
- **WEB-39 — Uploads:** Validar bytes/tamanho/nome e servir upload fora do webroot.
- **WEB-40 — Projeto web completo:** Entregar app integrado com dados fictícios, auth, testes e evidência.

### Engineering/Git

Os 30 exemplos executam o mesmo commit inicial. Reutilizar repo seria saudável se cada etapa acrescentasse branch/merge/teste/CI; aqui os objetivos novos não são demonstrados. Separar Git de GitHub.

- **ENG-01 — Git:** Explicar working tree/index/commit e acompanhar estados com git status/diff.
- **ENG-02 — Commit:** Inspecionar snapshot, parent, hash e mensagem de commit em histórico real.
- **ENG-03 — Branch:** Criar branches divergentes e explicar ponteiros/HEAD.
- **ENG-04 — Merge:** Executar merge fast-forward e three-way com grafo e conflito.
- **ENG-05 — Rebase:** Executar rebase local e comparar novos commits sem reescrever trabalho compartilhado.
- **ENG-06 — Remote:** Usar remote local, fetch/push e distinguir referência remota de branch local.
- **ENG-07 — GitHub:** Distinguir Git de GitHub e explicar colaboração/permissões em repositório fictício.
- **ENG-08 — Pull Request:** Revisar diff e checks de PR com exemplo de comentário técnico.
- **ENG-09 — Conflitos:** Resolver conflito real explicando estágios e testes de comportamento.
- **ENG-10 — Estratégias de versionamento:** Comparar estratégia de branches/releases e política de integração.
- **ENG-11 — Estrutura de projeto:** Organizar projeto pequeno com fronteiras, entrypoint, configuração e testes.
- **ENG-12 — Dependências:** Construir grafo de dependências diretas/transitivas e lockfile.
- **ENG-13 — Package managers:** Comparar instalação determinística e atualização controlada de pacote.
- **ENG-14 — Configuração:** Validar config por schema e separar default, ambiente e segredo.
- **ENG-15 — Environment variables:** Demonstrar precedência/herança de env sem registrar segredo fictício.
- **ENG-16 — Testes:** Definir comportamento observável e caso positivo/negativo em teste executável.
- **ENG-17 — Unit tests:** Isolar função com casos de borda e evitar teste que espelha implementação.
- **ENG-18 — Integration tests:** Testar fronteira API/banco com fixture e cleanup.
- **ENG-19 — Debugging:** Resolver bug por hipótese, breakpoint e regressão.
- **ENG-20 — Logging:** Emitir logs estruturados com identidade/correlação e redaction.
- **ENG-21 — Build:** Gerar build reproduzível e explicar etapas/artefato.
- **ENG-22 — CI:** Executar pipeline CI com teste falhando e gate explícito.
- **ENG-23 — CD:** Demonstrar promoção entre ambientes e rollback em cenário simulado.
- **ENG-24 — Artifacts:** Gerar artefato com hash/metadados e verificar proveniência.
- **ENG-25 — Releases:** Criar release/tag/changelog e verificar conteúdo publicado em exemplo local.
- **ENG-26 — Semantic Versioning:** Resolver MAJOR/MINOR/PATCH com mudanças de compatibilidade concretas.
- **ENG-27 — Dependency Security:** Triar advisory de dependência, atualização e teste de regressão.
- **ENG-28 — Secrets:** Detectar segredo fictício, revogar/rotacionar e tratar histórico.
- **ENG-29 — Software Supply Chain:** Gerar SBOM/attestation e verificar cadeia de confiança do artefato.
- **ENG-30 — Projeto CI/CD seguro:** Entregar pipeline seguro integrado com permissões, gates e evidências.

### Labs/Tools

Todos os 30 exemplos mandam definir escopo/gerar evento/observar com [título]. As definições de ferramentas são úteis como glossário; falta ensinar uso, configuração, fixture, output e cleanup.

- **LAB-01 — Ética, autorização e escopo:** Preencher autorização/escopo com ativos, limites e critério de parada.
- **LAB-02 — Como documentar um laboratório:** Fornecer relatório preenchido com ambiente, comandos, outputs e hashes.
- **LAB-03 — Virtualização:** Configurar VM e modos de rede, snapshot e limites de isolamento.
- **LAB-04 — WSL:** Instalar/configurar WSL e explicar acesso ao host e isolamento limitado.
- **LAB-05 — Docker:** Executar container local, volumes, rede e cleanup com efeito observado.
- **LAB-06 — Redes Docker:** Criar rede Docker isolada e testar conexão permitida/bloqueada.
- **LAB-07 — Kali:** Preparar Kali com atualização, usuário e ferramentas de laboratório.
- **LAB-08 — Ubuntu:** Preparar Ubuntu com runtime e serviços mínimos reproduzíveis.
- **LAB-09 — Windows VM:** Preparar Windows VM licenciada/avaliativa com contas e logging.
- **LAB-10 — Snapshots:** Criar/restaurar snapshot e verificar estado e limites de persistência.
- **LAB-11 — Burp Suite:** Configurar proxy Burp e capturar/editar request local com resposta.
- **LAB-12 — OWASP ZAP:** Executar ZAP em aplicação local com escopo e triagem de alerta.
- **LAB-13 — DevTools:** Usar Network/Console/Sources com request e breakpoint concretos.
- **LAB-14 — curl:** Executar curl com headers/body/status/timeout e interpretar resposta local.
- **LAB-15 — Postman e Bruno:** Criar coleção Postman/Bruno com env fictício e assertivas de resposta.
- **LAB-16 — Nmap:** Escanear listener local conhecido e interpretar open/closed/filtered.
- **LAB-17 — Wireshark:** Capturar tráfego local e filtrar frames com gabarito.
- **LAB-18 — Nuclei:** Selecionar template Nuclei revisado e versão, executando só em alvo autorizado.
- **LAB-19 — Ghidra:** Importar binário próprio no Ghidra e reconstruir função com xrefs.
- **LAB-20 — x64dbg:** Depurar executável próprio no x64dbg com breakpoint e estado esperado.
- **LAB-21 — Sysmon:** Instalar/configurar Sysmon e validar evento de processo benigno.
- **LAB-22 — Procmon:** Filtrar Procmon por PID/path e observar criação de arquivo de teste.
- **LAB-23 — Process Explorer:** Inspecionar handles/threads/módulos em Process Explorer de processo benigno.
- **LAB-24 — Autoruns:** Exportar baseline Autoruns e comparar persistência benigna reversível.
- **LAB-25 — REMnux:** Usar REMnux com fixture inerte e artefatos de triagem anotados.
- **LAB-26 — Volatility:** Fixar Volatility 3/dump/símbolos, distinguindo do modelo antigo de profiles.
- **LAB-27 — Suricata:** Carregar regra Suricata e PCAP, verificar EVE JSON e caso negativo.
- **LAB-28 — SIEM:** Ingerir eventos sintéticos em SIEM definido e executar correlação.
- **LAB-29 — YARA e Sigma:** Executar YARA e Sigma em corpus/eventos com backend e resultados esperados.
- **LAB-30 — Laboratório integrado:** Entregar laboratório integrado com artefatos, regras e reteste verificável.

### Cloud/Containers/Kubernetes

Dez CLD usam matriz de IAM; dez CTR usam Dockerfile id/echo; K8S tem colisões de tema em Services/Security Context e capstone reduzido a Dockerfile. Alpine 3.20 está fora de suporte. Precisam de cenários por recurso e autorização verificável.

- **CLD-01 — O que é cloud:** Explicar responsabilidade compartilhada e plano de controle versus plano de dados.
- **CLD-02 — IaaS / PaaS / SaaS:** Comparar IaaS/PaaS/SaaS por tarefa operacional e controle de segurança.
- **CLD-03 — Regiões e zones:** Explicar região/zona, failure domain e residência de dados.
- **CLD-04 — Compute:** Provisionar compute sintético/emulado e identidade/permissões mínimas.
- **CLD-05 — Storage:** Comparar object/block/file storage com acesso público/privado e auditoria.
- **CLD-06 — Networking cloud:** Traçar VPC/subnet/route/security group e egress em topologia concreta.
- **CLD-07 — IAM:** Resolver avaliação de policy por principal/ação/recurso/condição e deny.
- **CLD-08 — Roles e policies:** Comparar role, policy, trust e credencial temporária em cenário.
- **CLD-09 — Secrets:** Demonstrar rotação/acesso auditado a segredo fictício e revogação.
- **CLD-10 — Logging:** Fornecer log de controle e dados, campos e consulta de detecção.
- **CTR-01 — Containers:** Explicar namespaces/cgroups/rootfs e limite de isolamento do container.
- **CTR-02 — Imagens:** Inspecionar camadas/digest/tag de imagem e origem.
- **CTR-03 — Dockerfile:** Construir Dockerfile com cache de camadas, USER e contexto mínimo.
- **CTR-04 — Volumes:** Montar volume e demonstrar persistência/permissões/remoção.
- **CTR-05 — Networking de containers:** Criar rede entre containers e medir portas expostas/isolamento.
- **CTR-06 — Registries:** Comparar registry/tag/digest e política de pull/autenticidade.
- **CTR-07 — docker-compose:** Entregar compose com serviços, healthchecks, volumes e cleanup.
- **CTR-08 — Permissions em containers:** Comparar UID/capabilities/rootless e host bind mount.
- **CTR-09 — Secrets em containers:** Usar segredo fictício montado em runtime sem embutir em imagem/env desnecessário.
- **CTR-10 — Container hardening:** Validar readonly/cap-drop/seccomp/non-root e versão suportada de base.
- **K8S-01 — Kubernetes:** Explicar control plane, reconciliação e recursos com cluster local.
- **K8S-02 — Pods:** Aplicar Pod, observar estado/eventos e readiness em exemplo.
- **K8S-03 — Deployments:** Criar Deployment, ReplicaSet, rollout e rollback observáveis.
- **K8S-04 — Services:** Definir Service/selector/endpoints e comunicação entre Pods; substituir exemplo de IAM.
- **K8S-05 — Secrets no Kubernetes:** Criar Secret fictício e explicar base64 versus criptografia, acesso e montagem.
- **K8S-06 — RBAC:** Aplicar Role/RoleBinding e verificar kubectl auth can-i com identidades distintas.
- **K8S-07 — Network Policies:** Aplicar NetworkPolicy com CNI compatível e testar allow/deny.
- **K8S-08 — Logs no Kubernetes:** Coletar logs/eventos de Pod e correlacionar restart/erro.
- **K8S-09 — Security Context:** Aplicar securityContext no nível correto e verificar UID/capabilities; substituir exemplo de IAM.
- **K8S-10 — Projeto Cloud/Containers/K8s:** Integrar Deployment/Service/RBAC/NetworkPolicy/logs em projeto; Dockerfile isolado não cobre capstone.


