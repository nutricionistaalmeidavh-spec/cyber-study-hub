# Fase 15 — Duplicações de conteúdo

## Método e interpretação

Comparação exata de código e parágrafos após normalizar whitespace; segundo passe substitui somente título/ID por marcador. Comparação aproximada por Jaccard de shingles de cinco palavras no corpo sem headings; os três vizinhos mais próximos acima de 0,45 estão no JSON. O índice mede semelhança textual, não originalidade intelectual, e não é usado sozinho para dar nota. Trechos curtos, sintaxe idiomática e títulos de seção não são prova de template nocivo.

**Padronização saudável:** escopo autorizado, cabeçalhos, registro de baseline, evidência, correção/reteste e instruções de organização podem se repetir. **Repetição artificial:** a mesma explicação/quiz/lab ocupa o lugar da competência distinta prometida pelo título. Reutilizar o mesmo projeto é saudável quando cada aula acrescenta comportamento observável e profundidade; repetir o mesmo commit ou print sem progressão não é.

## Padrões confirmados

| Padrão | Unidades | Consequência e substituição |
| --- | --- | --- |
| Quiz Q3–Q5 literal e cinco respostas A | Todas as 325 paralelas | Mede reconhecimento de boas práticas genéricas; criar problemas, logs/código e distratores de erro conceitual do tema |
| Quatro flashcards Baseline/Caso positivo/Caso negativo/Reteste repetidos | Todas as 325 paralelas | Úteis como glossário comum, não como revisão principal de 325 temas; centralizar e adicionar cards específicos |
| Definições de elementos e flashcards circulares | AULA-101–200 | “Elemento do modelo” e “explique sua função” não fornecem mecanismo/resposta; escrever contrato causal e exemplo |
| Quiz Q2–Q5 e gabarito A/B/B/B/A | AULA-101–200 | Trocar somente foco da Q1 não cria avaliação da nova competência |
| Exemplo input.length | 61 unidades, incluindo 29 principais e 32 WEB | É apenas inspeção de string; substituir por operação do objetivo; lista exata abaixo |
| List comprehension | 16 PY | Não ensina arquivo/exceção/socket/CLI; manter somente onde pertinente e completar tema |
| map em array | 9 JS | Não ensina eventos/Promises/fetch/Node/Express |
| if imprimindo ramo | 14 C | Não ensina arrays/strings/structs/arquivos/sanitizers |
| Print de ponteiro | 6 C | Pode introduzir endereço, mas não ensina heap/malloc/free/manipulação de memória |
| Commit inicial | ENG-01–30 | Branch/merge/rebase/testes/CI não aparecem no experimento |
| cc --version | 24 unidades entre 101–130 | Identifica toolchain; não é lab de internals/RE |
| make_fixtures.py ausente com erro ocultado | AULA-161–180 | Devolve aparente sucesso sem material; entregar fixtures e expor falha |
| Worked examples que conectam frases de etapas | JSON V2 AULA-048–060 | Não são soluções trabalhadas; mostrar entrada, valores, decisão e evidência reais |
| Mesmo lab, defesa e desafio do assistente | AULA-201–208 | Cada tema precisa de teste próprio: ACL, approval binding, provenance, output handling etc. |
| Exemplo preenchido abstrato | AULA-209–218 | Nome de produto muda, conteúdo não demonstra um produto concreto; fornecer exemplares por etapa |

Observação: contagens referem-se a presença em unidades, não número de ocorrências dentro do mesmo arquivo. Os trechos comuns do JSON V2 não aumentam o denominador de 543. Os clusters exatos abaixo incluem estruturas saudáveis e nocivas: o parecer acima e a lacuna individual decidem a relevância.

## Clusters de código — IDs exatos

### C001 — 325 unidades

Trecho normalizado: `data/hora: ambiente: versão: estado inicial: resultado esperado:`

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### C002 — 325 unidades

Trecho normalizado: `estado inicial ↓ entrada/operação de {TEMA} ↓ regra/componente que interpreta ↓ novo estado ↓ evidência observável`

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### C003 — 325 unidades

Trecho normalizado: `objeto → estado → operação → regra → evidência → controle`

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### C004 — 100 unidades

Trecho normalizado: `Procedimento de laboratório: Registre versão, ambiente e baseline`

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### C005 — 100 unidades

Trecho normalizado: `entrada/estado → componente que interpreta → regra/decisão → efeito no processo/sistema/dado → evidência observável → controle primário → reteste`

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### C006 — 100 unidades

Trecho normalizado: `quem? onde? quando? qual processo/identidade? qual recurso? qual origem? qual resultado? qual era o baseline? qual sequência veio antes/depois?`

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### C007 — 61 unidades

Trecho normalizado: `const input="lab"; console.log({input,length:input.length});`

IDs: AULA-001, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-046, WEB-01, WEB-02, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40.

### C008 — 53 unidades

Trecho normalizado: `entrada/estado → componente que interpreta → decisão → efeito observável → controle que quebra a cadeia`

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### C009 — 53 unidades

Trecho normalizado: `quem? onde? qual ação? qual recurso/destino? qual resultado? qual sequência temporal?`

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### C010 — 46 unidades

Trecho normalizado: `identidade/host + ação + recurso/destino + horário + resultado + contexto`

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### C011 — 41 unidades

Trecho normalizado: `1. Defina escopo 2. Gere um evento benigno conhecido 3. Observe com {TEMA} 4. Salve a menor evidência 5. Repita com caso negativo`

IDs: AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30.

### C012 — 30 unidades

Trecho normalizado: `mkdir -p /tmp/git-lab && cd /tmp/git-lab git init -q printf "v1\n" > note.txt git add note.txt git -c user.name=Lab -c user.email=lab@example.local commit -qm initial git log --oneline -1`

IDs: ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30.

### C013 — 27 unidades

Trecho normalizado: `ip addr 2>/dev/null || ifconfig ip route 2>/dev/null || netstat -rn`

IDs: AULA-022, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-18, NET-19, NET-20, NET-22, NET-26, NET-27, NET-28, NET-29, NET-30, NET-37, NET-38, NET-39.

### C014 — 25 unidades

Trecho normalizado: `whoami Get-Process | Select-Object -First 5 Name,Id`

IDs: WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-28, WIN-29, WIN-30.

### C015 — 24 unidades

Trecho normalizado: `hash -> static -> hypothesis -> isolated dynamic -> telemetry -> detection -> report`

IDs: AULA-131, AULA-132, AULA-133, AULA-134, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-148, AULA-149, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-160.

### C016 — 24 unidades

Trecho normalizado: `sha256sum sample.bin 2>/dev/null || echo "use fixture do curso"`

IDs: AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-144, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160.

### C017 — 20 unidades

Trecho normalizado: `Entrada → regra de {TEMA} → saída Caso válido e caso limite`

IDs: LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20.

### C018 — 20 unidades

Trecho normalizado: `Procedimento de laboratório: Repita após a correção com o mesmo input`

IDs: AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180.

### C019 — 20 unidades

Trecho normalizado: `python3 make_fixtures.py 2>/dev/null || true`

IDs: AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180.

### C020 — 17 unidades

Trecho normalizado: `entrada -> interpretação -> decisão -> efeito -> evidência -> controle`

IDs: AULA-101, AULA-105, AULA-109, AULA-110, AULA-112, AULA-115, AULA-116, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-128, AULA-129, AULA-130.

### C021 — 16 unidades

Trecho normalizado: `values=[1,2,3] result=[x*2 for x in values] print(result)`

IDs: PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-11, PY-13, PY-14, PY-15, PY-16, PY-18, PY-19, PY-20.

### C022 — 14 unidades

Trecho normalizado: `#include <stdio.h> int main(void){int x=5; if(x>3) puts("ramo verdadeiro"); return 0;}`

IDs: C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-15, C-16, C-17, C-18, C-19, C-20.

### C023 — 12 unidades

Trecho normalizado: `principal → ação → recurso → condição`

IDs: CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, K8S-04, K8S-09.

### C024 — 11 unidades

Trecho normalizado: `FROM alpine:3.20 RUN adduser -D app USER app CMD ["sh","-c","id && echo lab"]`

IDs: CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, K8S-10.

### C025 — 10 unidades

Trecho normalizado: `Get-Process | Select-Object -First 3 Name,Id | Format-Table -AutoSize`

IDs: PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10.

### C026 — 10 unidades

Trecho normalizado: `Objetivo: produzir o artefato desta etapa sem ampliar o escopo. Ambiente: lab-final / localhost-VM Hipótese: condição específica do laboratório merece validação. Evidência mínima: log/response/hash/diff ligado diretamente à hipótese. Critério de sucesso: outro analista reproduz a conclusão usando o registro. Critério de parada: evidência suficiente; não ampliar impacto sem necessidade.`

IDs: AULA-209, AULA-210, AULA-211, AULA-212, AULA-213, AULA-214, AULA-215, AULA-216, AULA-217, AULA-218.

### C027 — 10 unidades

Trecho normalizado: `Procedimento de laboratório: Adicione caso negativo e reteste`

IDs: AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### C028 — 10 unidades

Trecho normalizado: `Procedimento de laboratório: Confirme ROE: somente LAB01/LAB02 ou localhost; dados fictícios`

IDs: AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190.

### C029 — 10 unidades

Trecho normalizado: `Procedimento de laboratório: Execute cleanup/revogação`

IDs: AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190.

### C030 — 10 unidades

Trecho normalizado: `crash -> reproduce -> root cause -> minimal PoC -> patch -> regression -> variant analysis`

IDs: AULA-161, AULA-163, AULA-164, AULA-165, AULA-170, AULA-174, AULA-175, AULA-176, AULA-179, AULA-180.

### C031 — 10 unidades

Trecho normalizado: `escopo → hipótese → teste mínimo → evidência → impacto → detecção → correção → reteste → comunicação`

IDs: AULA-209, AULA-210, AULA-211, AULA-212, AULA-213, AULA-214, AULA-215, AULA-216, AULA-217, AULA-218.

### C032 — 10 unidades

Trecho normalizado: `git status --short 2>/dev/null || true`

IDs: AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### C033 — 10 unidades

Trecho normalizado: `printf "alpha\nbeta\n" > /tmp/lab.txt grep -n beta /tmp/lab.txt rm /tmp/lab.txt`

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10.

### C034 — 10 unidades

Trecho normalizado: `timestamp asset identity action expected observed evidence_path classification`

IDs: AULA-209, AULA-210, AULA-211, AULA-212, AULA-213, AULA-214, AULA-215, AULA-216, AULA-217, AULA-218.

### C035 — 9 unidades

Trecho normalizado: `const values=[1,2,3]; console.log(values.map(x=>x*2));`

IDs: JS-01, JS-02, JS-03, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10.

### C036 — 8 unidades

Trecho normalizado: `request_id user_id / agent_id model_version retrieval_document_ids tool_name validated_arguments policy_decision approval_actor result_class`

IDs: AULA-201, AULA-202, AULA-203, AULA-204, AULA-205, AULA-206, AULA-207, AULA-208.

### C037 — 8 unidades

Trecho normalizado: `usuário / conteúdo externo ↓ normalização + classificação de confiança ↓ modelo / RAG / planner ↓ POLICY ENFORCEMENT POINT ↓ identidade + autorização + aprovação ↓ tool / banco / API ↓ audit log + resultado`

IDs: AULA-201, AULA-202, AULA-203, AULA-204, AULA-205, AULA-206, AULA-207, AULA-208.

### C038 — 7 unidades

Trecho normalizado: `GET /health HTTP/1.1 Host: 127.0.0.1:3000 Accept: application/json`

IDs: AULA-002, AULA-045, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07.

### C039 — 7 unidades

Trecho normalizado: `apiVersion: v1 kind: Pod metadata: {name: lab} spec: automountServiceAccountToken: false containers: - name: app image: nginx:alpine`

IDs: K8S-01, K8S-02, K8S-03, K8S-05, K8S-06, K8S-07, K8S-08.

### C040 — 6 unidades

Trecho normalizado: `#include <stdio.h> int main(void){int x=7; int *p=&x; printf("%d %p\n",*p,(void*)p);}`

IDs: C-09, C-10, C-11, C-12, C-13, C-14.

### C041 — 6 unidades

Trecho normalizado: `powershell -NoProfile -Command "$PSVersionTable.PSVersion; Get-ComputerInfo | Select WindowsProductName,OsArchitecture"`

IDs: AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-125.

### C042 — 6 unidades

Trecho normalizado: `safe emulation -> telemetry -> detection -> investigation -> tune -> retest`

IDs: AULA-182, AULA-183, AULA-184, AULA-185, AULA-187, AULA-188.

### C043 — 5 unidades

Trecho normalizado: `Capture uma conexão local conhecida; filtre por tcp.port == 8000; siga o stream.`

IDs: AULA-024, NET-31, NET-32, NET-33, NET-40.

### C044 — 5 unidades

Trecho normalizado: `curl -I http://127.0.0.1:8000/ 2>/dev/null || true`

IDs: NET-23, NET-24, NET-25, NET-35, NET-36.

### C045 — 5 unidades

Trecho normalizado: `type User={id:string;role:"user"|"admin"}; const u:User={id:"lab-1",role:"user"}; console.log(u.role);`

IDs: TS-01, TS-02, TS-03, TS-04, TS-05.

## Parágrafos repetidos — principais clusters

### T001 — 325 unidades

> 1. defina o comportamento esperado; 2. reduza ambiguidade e privilégio; 3. valide entrada/estado relevante; 4. torne falhas observáveis; 5. aplique o controle; 6. repita o mesmo caso positivo; 7. repita o caso negativo e um fluxo legítimo.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T002 — 324 unidades

> **checkpoint 1:** descreva cada caixa do fluxo usando substantivos concretos desta aula. se você escrever apenas “sistema”, “coisa” ou “processo” sem especificar, refine.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T003 — 324 unidades

> - confirme runtime/ferramenta; - confirme ambiente próprio/local; - leia o erro completo; - verifique permissão, path, porta e versão; - restaure baseline; - reduza para o menor caso reproduzível.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T004 — 324 unidades

> 1. qual é a fronteira de confiança? 2. quem pode alterar o estado? 3. qual entrada é controlável? 4. qual evidência existe perto do mecanismo? 5. qual controle atua na causa?

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T005 — 324 unidades

> 4. **por que o caso negativo importa?** - a) porque testa se o sinal realmente discrimina a condição. ✅ - b) porque substitui o caso positivo. - c) porque todo caso negativo é incidente. - d) porque elimina o reteste.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T006 — 323 unidades

> - o nome do conceito não é o mesmo que uma ferramenta; - uma saída isolada não explica causa; - “funcionou” não significa “entendi”; - comportamento normal precisa de baseline para que desvio tenha significado.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T007 — 323 unidades

> 3. **qual é a melhor prática experimental?** - a) prever resultado, executar caso mínimo, variar uma condição e criar caso negativo. ✅ - b) mudar várias variáveis até funcionar. - c) copiar screenshot pronto. - d) ignorar o baseline.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T008 — 323 unidades

> 5. **após uma correção, o que deve ser repetido?** - a) o mesmo reproducer, mais caso legítimo/negativo. ✅ - b) um teste diferente para facilitar. - c) apenas a leitura do código. - d) nada, se o commit foi aceito.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T009 — 323 unidades

> imagine que você recebe somente uma captura, um erro ou uma saída relacionada a **{tema}**. se não souber quais objetos e estados deveriam existir, qualquer conclusão vira chute.

IDs: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-08, CLD-09, CLD-10, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20, ENG-21, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10, LAB-01, LAB-02, LAB-03, LAB-04, LAB-05, LAB-06, LAB-07, LAB-08, LAB-09, LAB-10, LAB-11, LAB-12, LAB-13, LAB-14, LAB-15, LAB-16, LAB-17, LAB-18, LAB-19, LAB-20, LAB-21, LAB-22, LAB-23, LAB-24, LAB-25, LAB-26, LAB-27, LAB-28, LAB-29, LAB-30, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30.

### T010 — 100 unidades

> - colete evidência próxima ao mecanismo, não apenas um nome de técnica; - compare caso positivo e negativo; - aplique a correção/mitigação no componente responsável; - repita o mesmo teste; - documente limitações residuais e possíveis falsos positivos.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T011 — 100 unidades

> - concluir pelo nome da técnica/ferramenta. - confundir capability com intenção. - usar resultado positivo sem caso negativo. - alterar várias variáveis antes do reteste. - tratar mitigador como correção do bug/configuração.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T012 — 100 unidades

> - confirme versão, arquitetura, ferramenta, permissões e estado inicial. - se um comando não existir na sua plataforma, registre a diferença antes de substituí-lo. - se não houver telemetria, valide a fonte de dados antes de concluir que nada ocorreu. - se o teste variar, reduza dependências externas e use fixture fixa. - limpe artefatos ou restaure snapshot após exercícios persistentes.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T013 — 100 unidades

> 0. **definir estado/baseline** 1. **introduzir a condição de laboratório** 2. **observar a decisão/comportamento** 3. **coletar evidência** 4. **aplicar controle** 5. **repetir o mesmo teste**

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T014 — 100 unidades

> 1. localize dados/estado de entrada. 2. marque a decisão que muda o fluxo. 3. identifique qual resultado seria observável. 4. pergunte qual validação/mitigação é primária. 5. liste o que esse snippet **não prova sozinho**.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T015 — 100 unidades

> > uso educacional/defensivo. testes ativos somente em laboratório, sistemas próprios ou escopo autorizado. nas fases de malware, exploit research e red team, use apenas fixtures, simuladores, localhost/vms e programas deliberadamente vulneráveis do curso.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T016 — 100 unidades

> a. mudar o teste para outro cenário. b. repetir o mesmo reproducer e verificar que a condição sumiu sem quebrar o caso legítimo. c. apagar evidências. d. desabilitar mitigadores.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T017 — 100 unidades

> em uma análise real, acrescente versão, identidade, permissões, caminho, tempo e origem do dado. essas dimensões explicam por que o mesmo comando pode ser benigno em um contexto e relevante em outro.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T018 — 100 unidades

> o controle primário corrige a causa/decisão. edr, ids, logging, rate limit, sandbox e alertas podem ser controles compensatórios importantes, mas não substituem automaticamente a correção.

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T019 — 100 unidades

> sempre pergunte: ```text quem? onde? quando? qual processo/identidade? qual recurso? qual origem? qual resultado? qual era o baseline? qual sequência veio antes/depois? ```

IDs: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200.

### T020 — 85 unidades

> - explicar {tema} por mecanismo, não por ferramenta. - identificar entrada/estado, intérprete, decisão, efeito e controle. - diferenciar observação, hipótese e confirmação. - executar um laboratório mínimo e reproduzível. - registrar resultado esperado e observado. - aplicar mitigação e provar melhora por reteste.

IDs: AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-113, AULA-114, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-131, AULA-132, AULA-133, AULA-134, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-181, AULA-182, AULA-183, AULA-185, AULA-186, AULA-189, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-197, AULA-198, AULA-199.

### T021 — 85 unidades

> 1. defina {tema} em uma frase sem usar o próprio termo na definição. 2. qual evidência do laboratório seria incompatível com sua hipótese? 3. qual controle atua na causa e qual atua apenas na detecção? 4. qual é o caso legítimo que precisa continuar funcionando após a correção?

IDs: AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-113, AULA-114, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-131, AULA-132, AULA-133, AULA-134, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-181, AULA-182, AULA-183, AULA-185, AULA-186, AULA-189, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-197, AULA-198, AULA-199.

### T022 — 54 unidades

> - **identidade** — localize este elemento no mecanismo e no experimento, não apenas na definição. - **recurso** — localize este elemento no mecanismo e no experimento, não apenas na definição. - **estado** — localize este elemento no mecanismo e no experimento, não apenas na definição. - **permissão** — localize este elemento no mecanismo e no experimento, não apenas na definição.

IDs: BASH-01, BASH-03, BASH-04, BASH-10, LNX-02, LNX-03, LNX-05, LNX-06, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-14, LNX-15, LNX-16, LNX-18, LNX-20, LNX-22, LNX-23, LNX-24, LNX-27, LNX-30, PS-01, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, WIN-01, WIN-02, WIN-04, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-14, WIN-15, WIN-16, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-28, WIN-30.

### T023 — 54 unidades

> - decorar identidade sem relacioná-lo ao estado real; - copiar comando sem prever saída; - trocar ferramenta antes de entender a camada; - não criar caso negativo; - confundir correlação temporal com causalidade; - corrigir e testar um caso diferente do reproducer original.

IDs: BASH-01, BASH-03, BASH-04, BASH-10, LNX-02, LNX-03, LNX-05, LNX-06, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-14, LNX-15, LNX-16, LNX-18, LNX-20, LNX-22, LNX-23, LNX-24, LNX-27, LNX-30, PS-01, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, WIN-01, WIN-02, WIN-04, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-14, WIN-15, WIN-16, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-28, WIN-30.

### T024 — 54 unidades

> 1. explicar {tema} sem definição circular; 2. reconhecer os elementos identidade; recurso; estado; permissão; 3. narrar o mecanismo passo a passo; 4. executar/simular um exemplo mínimo em ambiente próprio; 5. prever o resultado antes de executar; 6. produzir um caso positivo e um negativo; 7. registrar evidência suficiente para reteste; 8. relacionar o tema a uma decisão de segurança ou operação.

IDs: BASH-01, BASH-03, BASH-04, BASH-10, LNX-02, LNX-03, LNX-05, LNX-06, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-14, LNX-15, LNX-16, LNX-18, LNX-20, LNX-22, LNX-23, LNX-24, LNX-27, LNX-30, PS-01, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, WIN-01, WIN-02, WIN-04, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-14, WIN-15, WIN-16, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-28, WIN-30.

### T025 — 54 unidades

> 2. **qual conjunto pertence diretamente ao mecanismo desta aula?** - a) identidade; recurso; estado; permissão. ✅ - b) apenas nome do arquivo e cor da interface. - c) somente severidade sem evidência. - d) nenhum estado observável.

IDs: BASH-01, BASH-03, BASH-04, BASH-10, LNX-02, LNX-03, LNX-05, LNX-06, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-14, LNX-15, LNX-16, LNX-18, LNX-20, LNX-22, LNX-23, LNX-24, LNX-27, LNX-30, PS-01, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, WIN-01, WIN-02, WIN-04, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-14, WIN-15, WIN-16, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-28, WIN-30.

### T026 — 53 unidades

> - [ ] consigo explicar o mecanismo em minhas palavras. - [ ] sei diferenciar o conceito dos temas vizinhos. - [ ] sei executar/explicar o laboratório. - [ ] sei qual evidência procurar. - [ ] sei qual correção age na causa. - [ ] sei retestar.

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### T027 — 53 unidades

> - confirme versões, portas, identidade e estado inicial do laboratório. - colete baseline antes de mudar configuração. - se uma ferramenta “não encontrar”, verifique cobertura e fonte de dados antes de concluir ausência de risco. - se um finding aparecer, leia a evidência e a pré-condição antes de classificá-lo. - mantenha laboratório isolado e restaure snapshot quando a aula pedir mudança de conf

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### T028 — 53 unidades

> - confundir indicador com confirmação. - concluir vulnerabilidade pelo nome da ferramenta. - aplicar hardening sem testar impacto operacional. - não diferenciar prevenção de detecção. - fazer correção e esquecer o reteste.

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### T029 — 53 unidades

> não memorize apenas “payloads” ou comandos. a mesma classe de problema reaparece em frameworks e ferramentas diferentes quando a **mesma suposição** é quebrada.

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### T030 — 53 unidades

> o controle primário deve corrigir a decisão insegura. logging, waf, alerta, rate limit ou edr podem ser importantes, mas não devem ser vendidos como substitutos da correção quando a causa está no código/configuração.

IDs: AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100.

### T031 — 46 unidades

> - confundir ferramenta com conhecimento. - considerar ausência de erro como prova de segurança. - testar sem baseline. - classificar severidade antes de provar alcance/impacto. - pular o reteste.

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T032 — 46 unidades

> - o que é {tema}? - por que o problema/controle existe? - qual componente toma a decisão crítica? - qual evidência observar? - qual correção age na causa? - como provar a correção?

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T033 — 46 unidades

> - se o laboratório não reproduzir, confirme primeiro **versão, porta, rota e estado inicial**. - não mude várias variáveis ao mesmo tempo; compare um cenário por vez. - salve request/output/log antes de corrigir. sem “antes”, o reteste perde valor. - diferencie erro de configuração do laboratório de comportamento de segurança. - se uma ferramenta gerar um finding, trate como hipótese até entender 

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T034 — 46 unidades

> 1. **qual é a entrada ou estado?** quem controla e de onde vem? 2. **qual componente toma a decisão?** browser, backend, banco, proxy, so ou ferramenta? 3. **qual é a condição segura?** o que precisa ser validado antes da ação? 4. **qual evidência aparece?** status, log, arquivo, pacote, evento ou mudança de estado? 5. **como o reteste prova a correção?** repita o mesmo cenário e compare o resulta

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T035 — 46 unidades

> a correção deve agir sobre a causa. evite controles cosméticos como esconder ids, renomear rotas, desativar mensagens sem corrigir a decisão ou confiar somente no frontend.

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T036 — 46 unidades

> esta aula faz parte do retrofit das aulas 1–46. o objetivo não é apagar o que já foi estudado, mas transformar o material original em uma referência técnica mais completa, capaz de servir para revisão, aprofundamento e futura integração em qualquer plataforma.

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T037 — 46 unidades

> na prática, segurança não depende de decorar o nome da técnica. ela depende de localizar a fronteira de confiança, identificar o dado ou estado que muda a decisão e provar, com evidência mínima, se o controle impede o comportamento indesejado.

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046.

### T038 — 43 unidades

> - **entrada** — localize este elemento no mecanismo e no experimento, não apenas na definição. - **estado** — localize este elemento no mecanismo e no experimento, não apenas na definição. - **regra** — localize este elemento no mecanismo e no experimento, não apenas na definição. - **saída** — localize este elemento no mecanismo e no experimento, não apenas na definição.

IDs: JS-01, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, LOG-01, LOG-03, LOG-05, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-18, LOG-19, LOG-20, PY-01, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-14, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05.

### T039 — 43 unidades

> - **{tema}** → {tema} é estudado como uma transformação explícita de dados/estado, com entrada, regra e saída que podem ser testadas. - **entrada** → elemento que precisa aparecer na explicação do mecanismo. - **estado** → elemento que deve ser ligado a estado/evidência. - **baseline** → estado conhecido antes da variação. - **caso positivo** → cenário que deve produzir a evidência prevista. - **c

IDs: JS-01, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, LOG-01, LOG-03, LOG-05, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-18, LOG-19, LOG-20, PY-01, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-14, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05.

### T040 — 43 unidades

> - decorar entrada sem relacioná-lo ao estado real; - copiar comando sem prever saída; - trocar ferramenta antes de entender a camada; - não criar caso negativo; - confundir correlação temporal com causalidade; - corrigir e testar um caso diferente do reproducer original.

IDs: JS-01, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, LOG-01, LOG-03, LOG-05, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-18, LOG-19, LOG-20, PY-01, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-14, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05.

### T041 — 43 unidades

> 1. **qual definição descreve melhor {tema}?** - a) {tema} é estudado como uma transformação explícita de dados/estado, com entrada, regra e saída que podem ser testadas. ✅ - b) é apenas o nome de uma ferramenta. - c) é qualquer evento raro observado no ambiente. - d) é um controle que elimina a necessidade de entender o mecanismo.

IDs: JS-01, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, LOG-01, LOG-03, LOG-05, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-18, LOG-19, LOG-20, PY-01, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-14, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05.

### T042 — 43 unidades

> 1. explicar {tema} sem definição circular; 2. reconhecer os elementos entrada; estado; regra; saída; 3. narrar o mecanismo passo a passo; 4. executar/simular um exemplo mínimo em ambiente próprio; 5. prever o resultado antes de executar; 6. produzir um caso positivo e um negativo; 7. registrar evidência suficiente para reteste; 8. relacionar o tema a uma decisão de segurança ou operação.

IDs: JS-01, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, LOG-01, LOG-03, LOG-05, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-18, LOG-19, LOG-20, PY-01, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-14, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05.

### T043 — 43 unidades

> 2. **qual conjunto pertence diretamente ao mecanismo desta aula?** - a) entrada; estado; regra; saída. ✅ - b) apenas nome do arquivo e cor da interface. - c) somente severidade sem evidência. - d) nenhum estado observável.

IDs: JS-01, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, LOG-01, LOG-03, LOG-05, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-18, LOG-19, LOG-20, PY-01, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-14, PY-16, PY-17, PY-18, PY-19, PY-20, TS-01, TS-02, TS-03, TS-04, TS-05.

### T044 — 42 unidades

> explique {tema} sem usar apenas a definição. diga qual suposição de segurança existe, como ela pode falhar e qual evidência provaria que o controle está funcionando.

IDs: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042.

### T045 — 40 unidades

> nesta trilha, o objetivo é seguir o pacote do emissor ao receptor e separar enlace, rede, transporte e aplicação. o tema **{tema}** precisa virar um modelo que permita prever comportamento antes de abrir uma ferramenta.

IDs: NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40.

## Exemplos de proximidade textual

| Unidade 1 | Unidade 2 | Jaccard normalizado |
| --- | --- | --- |
| LOG-03 | LOG-19 | 0.97 |
| LOG-03 | LOG-18 | 0.97 |
| LOG-03 | LOG-16 | 0.97 |
| LOG-05 | LOG-19 | 0.97 |
| LOG-05 | LOG-18 | 0.97 |
| LOG-05 | LOG-16 | 0.97 |
| LOG-08 | LOG-19 | 0.97 |
| LOG-08 | LOG-18 | 0.97 |
| LOG-08 | LOG-16 | 0.97 |
| LOG-09 | LOG-19 | 0.97 |
| LOG-09 | LOG-18 | 0.97 |
| LOG-09 | LOG-16 | 0.97 |
| LOG-10 | LOG-19 | 0.97 |
| LOG-10 | LOG-18 | 0.97 |
| LOG-10 | LOG-16 | 0.97 |
| LOG-11 | LOG-19 | 0.97 |
| LOG-11 | LOG-18 | 0.97 |
| LOG-11 | LOG-16 | 0.97 |
| LOG-12 | LOG-19 | 0.97 |
| LOG-12 | LOG-18 | 0.97 |
| LOG-12 | LOG-16 | 0.97 |
| LOG-13 | LOG-19 | 0.97 |
| LOG-13 | LOG-18 | 0.97 |
| LOG-13 | LOG-16 | 0.97 |
| LOG-14 | LOG-19 | 0.97 |
| LOG-14 | LOG-18 | 0.97 |
| LOG-14 | LOG-16 | 0.97 |
| LOG-15 | LOG-19 | 0.97 |
| LOG-15 | LOG-18 | 0.97 |
| LOG-15 | LOG-16 | 0.97 |

Todos os clusters detectados estão no JSON. Não foi atribuída autoria nem inferida a ferramenta que gerou os textos. A conclusão é sobre repetição e utilidade didática observáveis.

