# Fase 15 — Auditoria de conteúdo do Cyber Study Hub

Data de corte: **2026-09-02**. Fonte principal: ZIP exato obtido no Google Drive. Escopo: conteúdo técnico e didático, sem alterações nas aulas.

## Parecer executivo

**A: 0 · B: 1 · C: 103 · D: 439 — 543 unidades.** O catálogo é abrangente, mas a maior parte do material ainda não sustenta estudo autônomo no nível anunciado. A presença de campos, extensão do arquivo e número de seções não foram usados como prova de qualidade.

A Aula 047 é B: seu núcleo e laboratório são substanciais e funcionam pelo percurso do Markdown; os reparos são localizados no contrato JSON/MD, snippets, limitações e distratores. A prioridade alta de alinhar esses comandos não significa reescrever seu núcleo. Nenhuma unidade recebeu A. As C preservam explicações específicas, mas exigem aprofundamento e prática; as D exigem reconstrução do núcleo, mesmo quando há um parágrafo correto ou um comando executável.

## Corpus e rastreabilidade

- 218 principais e 325 paralelas, identificadas pelo catálogo `src/curriculum/catalog.json`, com 543 IDs únicos e 543 Markdown existentes.
- 14 JSON V2 de 047–060 foram inspecionados junto aos MD; não foram contados como mais 14 aulas.
- O ZIP é um pacote cumulativo para aplicação em checkout existente. As conclusões de ausência valem para os arquivos recebidos; não presumem o conteúdo de versões externas.
- SHA-256 do ZIP: `f4855c54bba77ce956bb7c86f4533f4a1802af0d96e1edb945ff8bc36b6479d2`.
- Único diretório de laboratório fornecido: `public/course-labs/aula-047/` (cinco arquivos). Isso não significa que todo exercício deva possuir um diretório: código completo inline também pode ser suficiente. O problema é quando a atividade depende de arquivos/estado que o texto não fornece.
- Cada registro JSON contém caminho, hash, evidências com linha/seção, seis notas, 30 critérios, ações e fontes. As notas de linha são do arquivo original, sem correção.

## Método e escala

Leitura estática por unidade de texto, código, laboratório, quiz e flashcards, com comparação de blocos repetidos e inspeção das variantes. Também foram consideradas a profundidade anunciada, a adequação ao tema e as dependências didáticas. Os scripts fizeram inventário, extração, hashes, duplicação e consolidação; notas de presença/schema não determinaram a classe. Os trechos de evidência são seleções, não todo o texto utilizado.

As seis notas são julgamentos editoriais em passos de cinco: 0–19 ausente/scaffold; 20–39 fragmentário; 40–59 parcial; 60–79 núcleo útil com lacunas; 80–100 robusto para o objetivo. **Conteúdo técnico inclui precisão, profundidade e completude: 40 não significa 40% de afirmações verdadeiras.** A média é aritmética simples das seis dimensões, sem peso por tamanho. Médias por bloco dão peso igual a cada unidade. Classes são decisões qualitativas, não cortes automáticos da média. Diferenças pequenas de nota não sustentam uma hierarquia forte; empates são ordenados por ID.

Os 30 critérios constam em cada unidade JSON. “Não aplicável” é usado em 209–218 para código/quiz/flashcards quando o produto da etapa não os exige. Sua avaliação considera rubrica e produtos, não ausência de perguntas. Em Logic e aulas operacionais, defesa significa robustez/validação/observabilidade pertinente; não se exige inventar uma exploração em toda lição. Um exercício de mesa pode ser prática válida se tiver dados, decisões e gabarito.

**Limite experimental:** somente o lab 047 foi executado integralmente, em cópia. Snippets de 009, 036 e 052 receberam microtestes. Os demais labs foram avaliados estaticamente; não há alegação de execução de 543 laboratórios nem de certificação técnica exaustiva. Não foram usados ambientes Windows/AD, cloud ou Kubernetes reais. Isso não impede concluir que um arquivo referenciado está ausente ou que um quiz repete o de outra unidade.

## Achados prioritários

1. **Contaminação entre temas:** 001 ensina ORM no reforço; 135 inclui ROP/DEP em Entropy; K8S-04/09 recebem exemplo IAM; C-06 ensina arrays com if. Conteúdo correto em outro contexto pode ser incorreto didaticamente nesta aula.
2. **Prática incompleta:** 101 pede lab.c não fornecido; 131–160 dependem de amostras/telemetria ausentes; 161–180 chamam make_fixtures.py inexistente e escondem falha. Requisitar que o aluno crie o laboratório inteiro não equivale a entregá-lo.
3. **Defesa que parece completa, mas não é:** CSRF ausente passa em 009; SSRF 015 não controla redirects/IP; safePath 052 não impede symlink externo; RLS 198 não mostra ativação/roles. Distinguir demonstração limitada de controle suficiente. [CSRF](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html), [SSRF](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html), [RLS](https://www.postgresql.org/docs/current/ddl-rowsecurity.html).
4. **Avaliação previsível:** paralelas Q3–Q5 iguais, distratores óbvios e resposta A em todas as cinco; 101–200 repetem quatro das cinco perguntas e o padrão A/B/B/B/A. Não basta embaralhar alternativas: precisam representar erros plausíveis do tema.
5. **Definições circulares:** “elemento do modelo” e flashcards “explique sua função” não ensinam nem fornecem resposta de revisão.
6. **Falsa progressão:** versões/etiquetas “profunda”, “V2” e “v3” não garantem incremento substantivo. Worked examples de 048–060 frequentemente apenas conectam uma etapa verbal à seguinte.
7. **Modernização seletiva:** atualizar base Alpine 3.20, requisito Node 18+, modelos de símbolos de Volatility e visibilidade TLS 1.3. A edição OWASP LLM Top 10 2026 existe; a lacuna de 207 é não ensinar seu conteúdo de forma verificável. [Alpine](https://alpinelinux.org/releases/), [Node](https://nodejs.org/en/about/eol), [TLS 1.3](https://www.rfc-editor.org/rfc/rfc8446.html), [OWASP 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/).

## Aula 047 — referência interna, com ressalvas

Pontos fortes: problema concreto, cacheability versus cache key, diferença entre deception/poisoning, happy path de asset público, rota privada, duas identidades, comandos, headers e comparação antes/depois. É a referência de maior utilidade, sem impor sua forma a Logic ou capstones documentais.

Teste efetuado com os arquivos originais em cópia e Express instalado:

| Caso | Resultado observado |
| --- | --- |
| Proxy vulnerável: Alice depois Bob em /account/profile.css com X-Lab-User | MISS Alice → HIT Alice: vazamento reproduzido |
| Proxy corrigido: mesmas duas identidades | BYPASS Alice → BYPASS Bob: isolamento do caso reproduzido |
| Comandos equivalentes com Cookie, como no JSON V2 | anonymous para ambas as requisições: não demonstra isolamento entre usuários |
| Asset público aquecido anonimamente e depois pedido com X-Lab-User | HIT: consulta do cache ocorre antes de canStore; promessa de todo autenticado dar BYPASS é excessiva |

O último resultado não demonstrou vazamento de conteúdo privado no proxy corrigido: o asset é público. Ele demonstra divergência de contrato. Map não implementa TTL; o mock só transporta X-Lab-User. O relatório não trata esse código didático como proxy de produção. No JSON, o primeiro codeExample tem uma linha física e 12 sequências literais de barra-n, prejudicando cópia e anotações.

## Outros testes pontuais

| Unidade | Teste | Resultado |
| --- | --- | --- |
| 009 | Executar comparação com body/session presentes, mas csrfToken ausente em ambos | Fluxo passou |
| 036 | node --check do snippet STRIDE | SyntaxError no literal Denial of Service quebrado por newline |
| 052 | Symlink criado dentro de public-files apontando para arquivo sintético fora dela | safePath aceitou e leitura retornou o dado sintético externo |

## Pontos fortes preserváveis

O currículo cobre temas relevantes e conecta operação, investigação e correção. Delimita repetidamente ambientes próprios/autorizados. 048–100 possuem conceitos e pequenos exemplos úteis; 086/087/098/100 e 054/056/057 são boas sementes. O bloco AI acerta ao colocar autorização fora do modelo. Há intenção consistente de baseline, evidência, negativo e reteste. Preservar esses princípios; preencher sua implementação específica.

## Riscos pedagógicos e técnicos

Pedagógicos: decorar linguagem de investigação sem compreender mecanismo; interpretar quiz fácil como domínio; depender de conhecimentos não ensinados; confundir descrição de experimento com experimento; repetir uma definição superficial até parecer familiar. A trilha opcional pode continuar livre, mas a aula avançada precisa explicar requisitos ou apontar conteúdo realmente suficiente.

Técnicos: copiar fragmentos defensivos incompletos; aceitar sucesso ocultando erros; concluir vulnerabilidade por versão/healthcheck; correlacionar eventos sem identidade/tempo; operar software fora de suporte; confundir autorização simulada com controle real. As falhas do material não provam vulnerabilidades de um aplicativo implantado: esta auditoria não avaliou um sistema em produção.

## Consolidação por bloco

| Bloco | N | A | B | C | D | Técnico | Didática | Prática | Defesa | Avaliação | Especificidade | Média |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1–46 | 46 | 0 | 0 | 42 | 4 | 54.9 | 43.5 | 25.1 | 38.7 | 20.5 | 46.7 | 38.2 |
| 47–60 | 14 | 0 | 1 | 13 | 0 | 65.4 | 53.9 | 30.4 | 48.9 | 27.9 | 58.6 | 47.5 |
| 61–78 | 18 | 0 | 0 | 18 | 0 | 62.8 | 48.3 | 28.3 | 45.3 | 25.6 | 53.1 | 43.9 |
| 79–100 | 22 | 0 | 0 | 22 | 0 | 65.0 | 50.7 | 28.9 | 47.5 | 27.1 | 57.3 | 46.1 |
| 101–130 | 30 | 0 | 0 | 0 | 30 | 39.2 | 27.2 | 13.7 | 23.7 | 10.0 | 29.2 | 23.8 |
| 131–160 | 30 | 0 | 0 | 0 | 30 | 40.5 | 27.0 | 12.5 | 26.3 | 10.0 | 30.7 | 24.5 |
| 161–180 | 20 | 0 | 0 | 0 | 20 | 36.8 | 25.2 | 11.2 | 25.0 | 10.0 | 26.8 | 22.5 |
| 181–190 | 10 | 0 | 0 | 0 | 10 | 36.5 | 25.5 | 11.5 | 26.0 | 10.0 | 26.5 | 22.7 |
| 191–200 | 10 | 0 | 0 | 0 | 10 | 37.0 | 25.5 | 12.5 | 24.0 | 10.0 | 27.5 | 22.8 |
| 201–208 | 8 | 0 | 0 | 8 | 0 | 60.0 | 48.1 | 22.5 | 43.8 | 25.0 | 52.5 | 42.0 |
| 209–218 | 10 | 0 | 0 | 0 | 10 | 35.0 | 30.0 | 15.0 | 25.0 | 25.0 | 20.0 | 25.0 |
| Logic | 20 | 0 | 0 | 0 | 20 | 30.0 | 20.0 | 5.0 | 11.2 | 10.0 | 11.2 | 14.6 |
| Python | 20 | 0 | 0 | 0 | 20 | 33.8 | 21.8 | 17.0 | 15.0 | 10.0 | 18.5 | 19.3 |
| JavaScript/TypeScript | 15 | 0 | 0 | 0 | 15 | 32.0 | 21.7 | 16.7 | 15.0 | 10.0 | 18.3 | 18.9 |
| C | 20 | 0 | 0 | 0 | 20 | 45.0 | 21.2 | 15.0 | 15.0 | 10.0 | 17.5 | 20.6 |
| Bash | 10 | 0 | 0 | 0 | 10 | 45.0 | 22.0 | 18.0 | 15.0 | 10.0 | 19.0 | 21.5 |
| PowerShell | 10 | 0 | 0 | 0 | 10 | 45.0 | 21.0 | 14.0 | 15.0 | 10.0 | 17.0 | 20.3 |
| Networks | 40 | 0 | 0 | 0 | 40 | 44.2 | 20.8 | 12.6 | 14.6 | 10.0 | 16.1 | 19.7 |
| Linux | 30 | 0 | 0 | 0 | 30 | 45.0 | 21.2 | 14.7 | 15.0 | 10.0 | 17.3 | 20.5 |
| Windows | 30 | 0 | 0 | 0 | 30 | 45.0 | 21.2 | 14.7 | 15.0 | 10.0 | 17.3 | 20.5 |
| Web Development | 40 | 0 | 0 | 0 | 40 | 45.0 | 20.5 | 12.0 | 15.0 | 10.0 | 16.0 | 19.8 |
| Engineering/Git | 30 | 0 | 0 | 0 | 30 | 45.0 | 20.3 | 11.3 | 15.0 | 10.0 | 15.7 | 19.6 |
| Labs/Tools | 30 | 0 | 0 | 0 | 30 | 40.0 | 20.0 | 5.0 | 15.0 | 10.0 | 13.3 | 17.2 |
| Cloud/Containers/Kubernetes | 30 | 0 | 0 | 0 | 30 | 36.0 | 19.8 | 10.5 | 14.5 | 10.0 | 13.8 | 17.4 |


### 1–46

Núcleos úteis de Web/AppSec foram envolvidos em repetição do próprio resumo e reforços nem sempre pertinentes. Priorizar contaminação de ORM em 001, CSRF em 009, SSRF em 015, código interpolado em 020/036 e casos sem app. Nenhuma aula deve ganhar prontidão só por ter mais seções.

### 47–60

047 é a única referência interna com laboratório físico completo e teste bem-sucedido do objetivo. As outras 13 têm conceitos específicos, mas a conversão V2 criou worked examples que narram passos, fading que apaga uma caixa do fluxo e expected genérico. Manter o conteúdo causal aproveitável e completar os cenários.

### 61–78

Comandos de enumeração são aproveitáveis. A cadeia AD depende de domínio, RSAT, contas, DNS, relógio, GPO e audit policy não entregues. Diferenciar inventário de validação de vulnerabilidade; /health e banner não provam impacto.

### 79–100

Melhor concentração de exemplos defensivos específicos: Sigma, YARA, logs, árvores e métricas. Faltam datasets, geradores, schemas/pipelines e falsos positivos resolvidos. Não classificar query sintaticamente plausível como detecção operacional.

### 101–130

Vocabulário de C/internals/RE está presente, mas definições e flashcards circulares dominam. cc --version não substitui fonte/binário, disassembly e debugging. Capstone 130 precisa de artefatos e investigação integrada, não apenas matriz.

### 131–160

A triagem é anunciada sem amostra educacional, PCAP, EVTX e dump de memória. Entropy 135 contém ROP/DEP indevido. EICAR é útil para teste benigno de AV, mas não substitui uma fixture comportamental completa.

### 161–180

Todas as 20 unidades chamam make_fixtures.py ausente e ocultam erro. Precisa de cadeia fonte→build→input→crash→causa→patch→regressão, com mitigadores isolados e diferenças entre crash e explorabilidade.

### 181–190

Escopo/ROE e intenção defensiva são pontos positivos. Simulações, IDs de técnicas, logs e cleanup não formam exercícios executáveis. Distinguir emular resultado de explorar uma falha e medir detecção com atividades benignas.

### 191–200

Temas atuais foram comprimidos em fragmentos declarativos: IAM pseudo, CI sem steps, RLS sem ativação, Electron sem contexto. Cada tecnologia exige implementação mínima própria, identidade e testes de permissão.

### 201–208

Princípio modelo propõe/política decide é sólido. Rotular prompt não cria isolamento; bool approved não representa aprovação vinculada; RAG requer ACL e revogação reais. Edição OWASP 2026 existe, mas a aula não ensina seu conjunto de categorias.

### 209–218

Dez produtos distintos têm praticamente o mesmo corpo e exemplo preenchido abstrato. Avaliação por artefatos é adequada ao capstone, mas deve usar insumos, produtos-modelo e critérios específicos da fase; quiz/flashcard são opcionais aqui.

### Logic

Não há algoritmos resolvidos: o exemplo repete entrada→regra do título→saída. Ensinar teste de mesa, condições, loops, funções, recursão e estados com valores concretos antes de pedir aplicação em segurança.

### Python

16/20 exemplos técnicos são a mesma list comprehension. JSON/regex/hash são melhores sementes, porém arquivos, exceções, venv, sockets, CLI e parsing não são efetivamente ensinados.

### JavaScript/TypeScript

9/10 exemplos JS usam map; os cinco TS repetem User/role. DOM tem exemplo pertinente. Faltam closures, eventos, async, fetch, Node/Express e diferença entre tipo estático e validação em runtime.

### C

14 exemplos usam if; seis usam print de ponteiro. Arrays, strings, structs, heap/malloc, arquivos e sanitizers não recebem código correspondente. Esta lacuna inviabiliza progressão segura para 101–180.

### Bash

Os dez exemplos repetem printf/grep/rm em /tmp/lab.txt. Quoting, expansão, loops, funções, processos e diagnóstico de rede precisam de operações próprias. Ensinar mktemp/trap e não colidir com arquivos existentes.

### PowerShell

As dez unidades repetem Get-Process/Select/Format-Table. Pipeline de objetos é uma boa introdução, mas não ensina serviços, rede, registry, AD ou coleta. Preservar objetos antes de formatar para tela.

### Networks

Há definições específicas úteis, porém exemplos frequentemente inventariam IP/rotas. HTTP claro é reaproveitado em HTTPS/TLS; PCAP inexistente. Ensinar cabeçalhos/estados com traces e limites TLS 1.3.

### Linux

26/30 exemplos usam pwd/id/uname. Permissões e processos têm sementes melhores; systemd, logs, sudoers, capabilities e firewall não têm demonstração do mecanismo.

### Windows

25/30 exemplos repetem whoami/Get-Process. Services/Registry/Event Viewer têm algo específico; Security Logs coleta System. Tokens, UAC, PE, Sysmon e hardening precisam de VM e evidência própria.

### Web Development

32/40 exemplos imprimem input.length. Cinco unidades HTTP mostram a mesma request, inclusive Response/Status; três Express mostram /health. Sem fundamentos reais a trilha AppSec fica dependente de conhecimento externo.

### Engineering/Git

Os 30 exemplos executam o mesmo commit inicial. Reutilizar repo seria saudável se cada etapa acrescentasse branch/merge/teste/CI; aqui os objetivos novos não são demonstrados. Separar Git de GitHub.

### Labs/Tools

Todos os 30 exemplos mandam definir escopo/gerar evento/observar com [título]. As definições de ferramentas são úteis como glossário; falta ensinar uso, configuração, fixture, output e cleanup.

### Cloud/Containers/Kubernetes

Dez CLD usam matriz de IAM; dez CTR usam Dockerfile id/echo; K8S tem colisões de tema em Services/Security Context e capstone reduzido a Dockerfile. Alpine 3.20 está fora de suporte. Precisam de cenários por recurso e autorização verificável.

## 20 melhores unidades relativas

“Melhor” é posição relativa no corpus; C continua exigindo aprofundamento, e B ainda não é pronta. Empates por ID.

| ID | Título | Classe | Média | Achado determinante |
| --- | --- | --- | --- | --- |
| AULA-047 | Web Cache Deception | B | 80.8 | Lab MD reproduz vazamento e correção; JSON usa Cookie ignorado pelo origin, trechos com barra-n literal e contrato de bypass excessivo. |
| AULA-061 | Enumeração Linux | C | 51.7 | Inventário Linux oferece comandos reais, mas interpretação das saídas e fixture de permissões faltam. |
| AULA-079 | Logs Windows/Linux | C | 51.7 | Comandos de logs são reais, mas não há evento gerado e output anotado comparável. |
| AULA-087 | YARA | C | 51.7 | Regra YARA benigna é útil, mas execução e corpus de arquivos ainda ficam a cargo do aluno. |
| AULA-090 | DFIR básico | C | 51.7 | Hash/cópia sustentam integridade básica; aquisição, metadados e cadeia de custódia precisam de exemplo preenchido. |
| AULA-092 | Assinaturas, hashes e reputação | C | 51.7 | Hash de arquivo simples é reproduzível, mas reputação e significado de mudança de hash ficam rasos. |
| AULA-086 | Sigma | C | 50.8 | Sigma Office→PowerShell é específico, mas não há pipeline/backend nem eventos de teste. |
| AULA-098 | Process Trees | C | 50.8 | Árvore com três eventos é específica; falta tratar PID reutilizado e relações no tempo. |
| AULA-100 | Detection Engineering aplicado | C | 50.8 | Regra composta é específica, porém não há evaluator e fixtures positivas/negativas solicitadas. |
| AULA-062 | Enumeração Windows | C | 50.0 | Enumeração Windows tem comandos pertinentes, mas contexto de privilégios e baseline fixo faltam. |
| AULA-081 | Wireshark | C | 50.0 | Filtros Wireshark são pertinentes; PCAP e captura inicial não estão no ZIP. |
| AULA-050 | DOM-based Vulnerabilities | C | 49.2 | textContent ilustra defesa corretamente; falta HTML completo, fluxo transformado e comparação negativa. |
| AULA-054 | JWT Security | C | 49.2 | jwtVerify com RS256/iss/aud é específico, porém biblioteca/chaves/token não estão disponíveis. |
| AULA-056 | API Security avançada — BOLA, BFLA, Mass Assignment | C | 49.2 | Ownership e allowlist têm valor; db não existe e uso de in aceita propriedades herdadas sem validar tipos. |
| AULA-204 | RAG Security | C | 49.2 | ACL antes do retriever é boa decisão; falta corpus multiusuário, revogação e isolamento verificável. |
| AULA-057 | Rate Limit, Race Conditions e Business Logic Flaws | C | 48.3 | UPDATE condicional explica atomicidade, mas banco, executor concorrente e idempotência não são demonstrados. |
| AULA-078 | Detection in Active Directory | C | 48.3 | IDs de eventos úteis não trazem campos, audit policy e eventos positivos/negativos. |
| AULA-096 | Exploit Protection | C | 48.3 | Get-ProcessMitigation é concreto, mas não distingue configuração declarada de proteção efetiva de binário. |
| AULA-043 | GraphQL Security | C | 47.5 | Resolver verifica owner de forma útil, mas schema/servidor/dados e análise de aliases/custo faltam. |
| AULA-080 | Sysmon | C | 47.5 | XML Sysmon filtra PowerShell, mas não entrega instalação/config nem eventos prometidos além do filtro. |


## 20 piores unidades relativas

Empates por ID. Outras unidades D empatadas ou próximas exigem a mesma atenção; esta lista não limita o backlog.

| ID | Título | Classe | Média | Achado determinante |
| --- | --- | --- | --- | --- |
| K8S-04 | Services | D | 10.8 | O exemplo real é principal → ação → recurso → condição. Não demonstra o mecanismo central do tema anunciado. Conteúdo de IAM substitui o assunto Kubernetes. |
| K8S-09 | Security Context | D | 10.8 | O exemplo real é principal → ação → recurso → condição. Não demonstra o mecanismo central do tema anunciado. Conteúdo de IAM substitui o assunto Kubernetes. |
| K8S-10 | Projeto Cloud/Containers/K8s | D | 12.5 | O exemplo real é FROM alpine:3.20 / RUN adduser -D app / USER app / CMD ["sh","-c","id && echo lab"]. Não demonstra o mecanismo central do tema anunciado. Base alpine:3.20 está fora de suporte na data da auditoria. |
| LOG-01 | Algoritmos e decomposição de problemas | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-03 | Operadores e expressões | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-05 | Laços de repetição | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-08 | Escopo | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-09 | Recursividade | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-10 | Estruturas de dados básicas | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-11 | Entrada → processamento → saída | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-12 | Estado e mudança de estado | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-13 | Buscar e filtrar dados | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-14 | Contadores, acumuladores e flags | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-15 | Validação de entrada | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-16 | Tratamento de erros | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-18 | Ler código de outra pessoa | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-19 | Refatoração básica | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| LOG-20 | Projeto lógico final | D | 13.3 | Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido. |
| CLD-01 | O que é cloud | D | 15.0 | Exemplo repete “principal → ação → recurso → condição”, sem cenário/serviço e decisão de política resolvida. |
| CLD-02 | IaaS / PaaS / SaaS | D | 15.0 | Exemplo repete “principal → ação → recurso → condição”, sem cenário/serviço e decisão de política resolvida. |


## Maiores lacunas globais

1. Fundamentos executáveis de programação, redes e sistemas nas paralelas.
2. Mecanismo causal com estado concreto, exemplo resolvido e explicação das decisões.
3. Fixtures versionadas, inputs, comandos, resultados observáveis e limpeza.
4. Happy path, caso que demonstra a falha, negativo plausível e regressão após correção.
5. Telemetria com schema, campos, identidade, tempo, consulta/regra e falsos positivos.
6. Avaliação de transferência: interpretar código/log/trace novo; distratores plausíveis e cards com respostas específicas.
7. Capstones integrados com materiais e produtos de referência, não apenas nomes de arquivos.
8. Atualização controlada e fontes por mecanismo, com versão e data de revisão.

## Ordem recomendada para a Fase 16

1. Corrigir contradições/erros de maior impacto e estabilizar a referência 047: 001, 009, 015, 020, 036, 047, 052, 135, 193, 195, 198 e colisões K8S; reparar os comandos/fixtures de 161–180 antes de usá-los.
2. Reconstruir fundações que desbloqueiam o restante: Logic, Python básico, C básico, Web HTTP/JS, Networks e Labs de isolamento. Trabalhar em pequenos lotes com um exemplo aceito antes de escalar.
3. Completar Web/AppSec 001–060 com apps e dados locais, priorizando autenticação/autorização, CSRF/SSRF/cache e API.
4. Completar 061–100 e paralelas Linux/Windows/Networks com VMs, logs e datasets; usar Sigma/YARA como pilotos defensivos.
5. Reconstruir 101–180 em três cadeias de fixtures: binários próprios, investigação inerte e bugs de memória com patch/reteste.
6. Completar 181–200 e Engineering/Cloud/Containers/K8S com políticas e pipelines executáveis e controles de identidade.
7. Integrar 201–208 e 209–218 depois de os blocos precedentes terem materiais utilizáveis; revisar avaliações ao concluir cada lote, não só no fim.

Critério de aceite por lote: explicar mecanismo, executar ou resolver a prática no ambiente declarado, reproduzir resultado, testar negativo/happy path, corrigir e retestar, responder avaliação específica. Não exigir mecanicamente todas as etapas de exploração em temas conceituais.

## Entregáveis e decisão

CSV contém uma linha por unidade e os campos solicitados. JSON contém a mesma auditoria, 30 critérios e rastreabilidade adicional. Backlog, duplicações, lacunas e fontes detalham ações e IDs. O pacote de evidências inclui resultados dos testes e scripts de consolidação. **Nenhuma aula foi corrigida ou reescrita. A Fase 16 depende de sua aprovação.**

