SOURCES = [
('F01','OWASP Cheat Sheet Series','https://cheatsheetseries.owasp.org/','Catálogo de controles; selecionar a página correspondente ao mecanismo e criar exemplo próprio.','catálogo consultado'),
('F02','PortSwigger Web Security Academy','https://portswigger.net/web-security','Mecanismos Web, laboratórios autorizados e casos negativos; não copiar soluções.','consultada para Web Cache Deception'),
('F03','RFC 9111 — HTTP Caching','https://www.rfc-editor.org/rfc/rfc9111.html','Cache-Control, chave, reutilização e armazenamento de respostas.','consultada'),
('F04','OWASP CSRF Prevention','https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html','Existência e vínculo do token; critérios de rejeição.','consultada'),
('F05','OWASP SSRF Prevention','https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html','Validação de destino, resolução e redirecionamentos.','consultada'),
('F06','OWASP Password Storage','https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html','Argon2id, custo e limites do bcrypt.','consultada'),
('F07','RFC 9700 — OAuth 2.0 Security BCP','https://www.rfc-editor.org/rfc/rfc9700.html','Fluxos atuais, redirect URI, PKCE e proteção de tokens.','consultada'),
('F08','MDN — Web documentation','https://developer.mozilla.org/en-US/docs/Web','HTTP, DOM, SOP/CORS, fetch e JavaScript; montar exemplos completos.','recomendada para aprofundamento'),
('F09','Python — tutorial oficial','https://docs.python.org/3/tutorial/','Fundamentos, arquivos, exceções, módulos e código executável.','recomendada para aprofundamento'),
('F10','TypeScript — Handbook','https://www.typescriptlang.org/docs/handbook/intro.html','Tipos, narrowing, generics e limites da tipagem estática.','recomendada para aprofundamento'),
('F11','GNU Bash Reference Manual','https://www.gnu.org/software/bash/manual/bash.html','Expansão, quoting, redirecionamento, funções e status.','recomendada para aprofundamento'),
('F12','Microsoft Learn — PowerShell','https://learn.microsoft.com/en-us/powershell/','Objetos, cmdlets, erros, automação e documentação de versão.','recomendada para aprofundamento'),
('F13','Linux man-pages','https://www.kernel.org/doc/man-pages/','Processos, memória, sockets, permissões e interfaces do kernel.','recomendada para aprofundamento'),
('F14','Microsoft Learn — Windows security','https://learn.microsoft.com/en-us/windows/security/','Tokens, auditoria, hardening e administração Windows.','recomendada para aprofundamento'),
('F15','Microsoft Learn — Active Directory Domain Services','https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/','Domínio, GPO, identidade e administração de laboratório.','recomendada para aprofundamento'),
('F16','Wireshark User’s Guide','https://www.wireshark.org/docs/wsug_html_chunked/','Captura, filtros e reconstrução; criar PCAP sintético próprio.','recomendada para aprofundamento'),
('F17','RFC 8446 — TLS 1.3','https://www.rfc-editor.org/rfc/rfc8446.html','Handshake e limites da visibilidade de certificados após ServerHello.','consultada'),
('F18','Microsoft Sysmon','https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon','Configuração e eventos, campos e limites de coleta.','consultada'),
('F19','SigmaHQ — regras e especificação','https://github.com/SigmaHQ/sigma','Referência de regras, logsource, campos e falsos positivos; fixar revisão.','recomendada para aprofundamento'),
('F20','YARA — documentação','https://yara.readthedocs.io/en/stable/','Sintaxe, condições e execução contra corpus educacional.','recomendada para aprofundamento'),
('F21','Suricata — documentação','https://docs.suricata.io/en/latest/','Sintaxe de regra, teste de configuração, PCAP e EVE JSON; usar versão fixada.','recomendada para aprofundamento'),
('F22','MITRE ATT&CK','https://attack.mitre.org/','Mapear comportamentos/IDs com justificativa e versão.','consultada'),
('F23','NIST SP 800-61r3','https://csrc.nist.gov/pubs/sp/800/61/r3/final','Resposta a incidentes integrada à gestão de risco.','consultada'),
('F24','Ghidra — repositório oficial','https://github.com/NationalSecurityAgency/ghidra','Importação, análise e exemplos de extensibilidade com binários próprios.','recomendada para aprofundamento'),
('F25','x64dbg — documentação oficial','https://help.x64dbg.com/en/latest/','Breakpoints, stepping e leitura do estado de processo próprio.','recomendada para aprofundamento'),
('F26','Clang AddressSanitizer','https://clang.llvm.org/docs/AddressSanitizer.html','Compilação/link, diagnósticos, limites e configuração.','consultada'),
('F27','LLVM libFuzzer','https://llvm.org/docs/LibFuzzer.html','Harness, corpus, cobertura e minimização; confirmar versão/toolchain antes de adotar.','recomendada para aprofundamento'),
('F28','Volatility 3 — repositório oficial','https://github.com/volatilityfoundation/volatility3','Símbolos, plugins e requisitos para dumps educacionais.','recomendada para aprofundamento'),
('F29','REMnux — documentação','https://docs.remnux.org/','Preparação de ambiente e fluxo de análise inerte.','recomendada para aprofundamento'),
('F30','Atomic Red Team','https://github.com/redcanaryco/atomic-red-team','Selecionar testes benignos, revisar pré-condições e cleanup; fixar IDs e versão.','recomendada para aprofundamento'),
('F31','Docker — documentação','https://docs.docker.com/','Imagens, volumes, rede, secrets e permissões com exemplos locais.','recomendada para aprofundamento'),
('F32','Kubernetes — Pod Security Standards','https://kubernetes.io/docs/concepts/security/pod-security-standards/','Restrições por nível de segurança e localização correta dos campos.','consultada'),
('F33','AWS IAM — Policy evaluation logic','https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html','Exemplo concreto de avaliação allow/deny/condição; não usar action pseudo-AWS como policy real.','recomendada para aprofundamento'),
('F34','PostgreSQL — Row Security Policies','https://www.postgresql.org/docs/current/ddl-rowsecurity.html','Ativação de RLS, policies, WITH CHECK e papéis que podem bypassar.','consultada'),
('F35','Supabase — Row Level Security','https://supabase.com/docs/guides/database/postgres/row-level-security','Integração de auth.uid, políticas e isolamento multiusuário.','recomendada para aprofundamento'),
('F36','Firebase — Security Rules','https://firebase.google.com/docs/rules','Modelo de regras e testes com emulador separados de PostgreSQL RLS.','recomendada para aprofundamento'),
('F37','Electron — Security','https://www.electronjs.org/docs/latest/tutorial/security','Isolamento, IPC e validação da identidade do remetente.','consultada'),
('F38','OWASP GenAI LLM Top 10 2026','https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/','Fixar edição e mapear categorias a controles e testes próprios.','página oficial consultada; edição 2026 existe'),
('F39','OWASP Top 10 for Agentic Applications 2026','https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/','Riscos específicos de identidade, ferramentas e cadeias de decisão de agentes.','consultada'),
('F40','MITRE ATLAS','https://atlas.mitre.org/','Modelo de ameaças AI; selecionar técnicas pertinentes e documentar evidência.','página acessada; conteúdo dinâmico não extraído integralmente'),
('F41','Git — documentação oficial','https://git-scm.com/doc','Histórico, index, branches, merge/rebase e exemplos locais reproduzíveis.','recomendada para aprofundamento'),
('F42','GitHub Actions — security hardening','https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions','Permissões de workflow, dependências e proteção de credenciais.','recomendada para aprofundamento'),
('F43','SLSA — especificação','https://slsa.dev/spec/','Provenance e confiança no build; fixar versão da especificação.','recomendada para aprofundamento'),
('F44','OWASP WebGoat','https://github.com/WebGoat/WebGoat','Aplicação intencionalmente vulnerável para prática local com objetivos delimitados.','repositório recomendado'),
('F45','OWASP Juice Shop','https://github.com/juice-shop/juice-shop','Cenários web integrados; usar instalação local e tarefas alinhadas à aula.','repositório recomendado'),
('F46','OWASP crAPI','https://github.com/OWASP/crAPI','BOLA, BFLA e cenários de API em laboratório autorizado.','repositório recomendado'),
('F47','Alpine — release branches','https://alpinelinux.org/releases/','Conferir suporte da imagem base; branch 3.20 encerrou suporte em 2026-04-01.','consultada em 2026-09-02'),
('F48','Node.js — EOL','https://nodejs.org/en/about/eol','Atualizar requisito Node 18+ e fixar versão mantida para laboratório.','consultada em 2026-09-02'),
('F49','Alhassan — Self-Explanation with Worked Examples','http://iiste.org/Journals/index.php/JEP/article/view/35501','Leitura pedagógica para desenhar autoexplicação e exemplos resolvidos em programação.','metadados localizados via Sider Scholar, W2594233825; texto integral não validado'),
('F50','Renkl — Learning from Worked-Out Examples','https://doi.org/10.1207/s15516709cog2101_1','Referência para estudar diferenças na aprendizagem com exemplos resolvidos.','metadados localizados via Sider Scholar; não usada para alegar tamanho de efeito'),
('F51','Nmap — Reference Guide','https://nmap.org/book/man.html','Interpretação dos estados e fingerprint, com limites e alvo de laboratório.','recomendada para aprofundamento'),
('F52','Microsoft — PE format','https://learn.microsoft.com/en-us/windows/win32/debug/pe-format','Headers/seções/imports e interpretação de endereços de PE.','recomendada para aprofundamento'),
('F53','Microsoft — x64 calling convention','https://learn.microsoft.com/en-us/cpp/build/x64-calling-convention','ABI Windows x64, argumentos, stack e alinhamento.','recomendada para aprofundamento'),
('F54','OWASP File Upload','https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html','Validação de conteúdo, nome, storage e entrega; completar os labs de upload.','recomendada para aprofundamento'),
]

def source_ids(r):
    if r['kind']=='parallel':
        p=r['code'].split('-')[0]
        n=int(r['code'].split('-')[1])
        if p=='LAB':
            return {1:['F23','F30'],2:['F23'],3:['F29'],4:['F14'],5:['F31'],6:['F31'],7:['F13'],8:['F13'],9:['F14'],10:['F29'],11:['F02'],12:['F01','F44'],13:['F08'],14:['F08'],15:['F08'],16:['F51'],17:['F16'],18:['F51','F01'],19:['F24'],20:['F25'],21:['F18'],22:['F14','F18'],23:['F14'],24:['F14'],25:['F29'],26:['F28'],27:['F21'],28:['F22','F23'],29:['F19','F20'],30:['F16','F18','F23']}[n]
        if p=='NET':return ['F16']+(['F17'] if n in [24,25,36] else ['F13'])
        if p=='WIN':return ['F14']+(['F18'] if n in [15,23,27,28,30] else ['F52'] if n in [24,25] else ['F12'])
        if p=='ENG':return ['F41'] if n<=10 else ['F42','F43'] if n>=21 else ['F09','F41']
        if p=='JS':return ['F08']+(['F48'] if n>=8 else [])
        return {'LOG':['F09','F49'],'PY':['F09','F49'],'TS':['F10','F08'],'C':['F13','F26'], 'BASH':['F11','F13'],'PS':['F12','F14'],'LNX':['F13','F11'],'WEB':['F08','F01','F02'],'CLD':['F33','F43'],'CTR':['F31','F47'],'K8S':['F32','F31']}[p]
    n=r['id']; s=[]
    if n<=60:s=['F01','F02']
    elif n<=78:s=['F13','F14'] if n<70 else ['F15','F14','F22']
    elif n<=100:s=['F18','F22','F23']
    elif n<=130:s=['F24','F25','F26']
    elif n<=160:s=['F28','F29','F22']
    elif n<=180:s=['F26','F27']
    elif n<=190:s=['F30','F22']
    elif n<=200:s=['F42','F43','F01']
    elif n<=208:s=['F38','F39','F40']
    else:s=['F23','F22','F45']
    extra={4:['F06'],9:['F04'],13:['F54'],15:['F05'],20:['F07'],21:['F16'],22:['F13'],23:['F51'],24:['F16'],26:['F26'],28:['F24'],40:['F45'],46:['F03'],47:['F03','F48'],53:['F54'],55:['F07'],56:['F46'],61:['F13'],66:['F51'],79:['F13'],80:['F18'],81:['F16'],82:['F21'],86:['F19'],87:['F20'],100:['F19'],108:['F52'],113:['F53'],138:['F18'],146:['F16'],149:['F28'],151:['F20'],152:['F19'],191:['F31'],192:['F32'],193:['F33'],198:['F34','F35','F36'],200:['F37'],215:['F19','F20']}
    return list(dict.fromkeys(s+extra.get(n,[])))
