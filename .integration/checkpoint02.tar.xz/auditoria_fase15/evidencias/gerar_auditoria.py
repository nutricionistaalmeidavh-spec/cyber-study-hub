from pathlib import Path
import re,json,csv,hashlib,statistics,collections,itertools,zipfile
from fontes import SOURCES,source_ids

BASE=Path(__file__).resolve().parent
ROOT=BASE/'original/CyberStudyHub_Fases_00_14_cumulativo'
OUT=BASE/'entregaveis';OUT.mkdir(exist_ok=True)
catalog=json.loads((ROOT/'src/curriculum/catalog.json').read_text())
raws=catalog['main']+catalog['parallel']
notes={}
for line in (BASE/'notas_main.tsv').read_text().splitlines():
    i,grade,scores,issue,action=line.split('|');notes[int(i)]=(grade,list(map(int,scores.split(','))),issue,action)
goals={};p=None
for line in (BASE/'lacunas_parallel.txt').read_text().splitlines():
    if line.startswith('['):p=line[1:-1];goals[p]=[]
    elif line:goals[p].append(line)
DIM=['conteúdo_técnico','didática','prática','defesa','avaliação','especificidade']
CRIT=['precisão técnica','profundidade adequada','progressão didática','mecanismo interno','exemplos específicos','exemplos resolvidos','qualidade do código/configuração','comentários e explicações do código','laboratório prático','executabilidade do laboratório','comandos concretos','resultados esperados','checkpoints','troubleshooting específico','explicação causal','escopo próprio/autorizado','detecção','correção/hardening','reteste','erros comuns','desafio final','qualidade do quiz','plausibilidade dos distratores','flashcards específicos','repetição entre aulas','definições genéricas/template','placeholders de exemplo/lab','lacunas do tema','atualidade','referências a adicionar']
RANGES=[(1,46),(47,60),(61,78),(79,100),(101,130),(131,160),(161,180),(181,190),(191,200),(201,208),(209,218)]
PNAMES={'LOG':'Logic','PY':'Python','JS':'JavaScript/TypeScript','TS':'JavaScript/TypeScript','C':'C','BASH':'Bash','PS':'PowerShell','NET':'Networks','LNX':'Linux','WIN':'Windows','WEB':'Web Development','ENG':'Engineering/Git','LAB':'Labs/Tools','CLD':'Cloud/Containers/Kubernetes','CTR':'Cloud/Containers/Kubernetes','K8S':'Cloud/Containers/Kubernetes'}
blocks=[f'{a}–{b}' for a,b in RANGES]+list(dict.fromkeys(PNAMES.values()))
P0MAIN={1,4,9,15,20,36,47,52,101,130,135,160,172,180,193,195,198,200}
P0PAR={'C-06','C-07','C-12','C-13','C-19','JS-07','NET-24','NET-25','NET-36','WIN-27','K8S-04','K8S-09','K8S-10'}
P0FOUND={'LOG-01','LOG-02','LOG-04','LOG-05','LOG-07','PY-01','PY-04','PY-06','PY-07','PY-08','C-01','C-09','LAB-01','LAB-03','LAB-09','LAB-10'}
PAR_RELEVANT={'PY-01','PY-02','PY-03','PY-05','PY-09','PY-12','PY-17','JS-01','JS-02','JS-04','TS-01','TS-02','C-01','C-02','C-03','C-09','C-10','BASH-01','BASH-02','BASH-03','BASH-04','PS-01','PS-03','NET-01','NET-04','NET-05','NET-09','NET-15','NET-16','LNX-01','LNX-02','LNX-04','LNX-05','LNX-07','LNX-21','LNX-26','WIN-02','WIN-05','WIN-07','WIN-08','WIN-11','WIN-14','WIN-15','WEB-03','WEB-05','WEB-21','WEB-22','ENG-01','ENG-02','CTR-01','CTR-02','CTR-03','CTR-08','K8S-01','K8S-02'}

def blockof(r):
    if r['kind']=='parallel':return PNAMES[r['code'].split('-')[0]]
    return next(f'{a}–{b}' for a,b in RANGES if a<=r['id']<=b)

def parts(t):
    fences=[(m.start(),m.end()) for m in re.finditer(r'```.*?```',t,re.S)]
    heads=[m for m in re.finditer(r'(?m)^#{1,2} (.+)$',t) if not any(a<=m.start()<b for a,b in fences)];out=[]
    for j,m in enumerate(heads):
        end=heads[j+1].start() if j+1<len(heads) else len(t)
        out.append({'heading':m.group(1),'start':t[:m.start()].count('\n')+1,'text':t[m.start():end].strip()})
    return out

def norm(t,r):
    for key in [r['title'],r['title'].lower(),r['code']]:t=t.replace(key,'{TEMA}')
    t=re.sub(r'(?m)^#{1,4} .*\n?','',t)
    return re.sub(r'\s+',' ',t).strip().lower()

def quote_evidence(t,ss,kind,needle,limit=420):
    sel=next((s for s in ss if re.search(needle,s['heading'],re.I)),None)
    if not sel:return {'id':kind,'status':'seção correspondente não identificada; consultar demais evidências','escopo_busca':'headings do arquivo integral; não implica ausência absoluta de conteúdo relacionado'}
    body=sel['text'].split('\n',1)[1].strip() if '\n' in sel['text'] else sel['text']
    return {'id':kind,'seção':sel['heading'],'linha_inicial':sel['start'],'trecho':body[:limit],'trecho_abreviado':len(body)>limit}

rows=[];text_by={};sec_by={};code_groups=collections.defaultdict(set);para_groups=collections.defaultdict(set)
for r in raws:
    code=r['code'];path=ROOT/('public'+r['contentPath']);t=path.read_text();ss=parts(t);text_by[code]=t;sec_by[code]=ss
    cb=[]
    for m in re.finditer(r'```([^\n]*)\n(.*?)```',t,re.S):
        lang=m.group(1).strip();body=m.group(2).strip();ln=t[:m.start()].count('\n')+1
        cb.append({'linguagem':lang,'linha':ln,'texto':body})
        if len(body)>=35:code_groups[re.sub(r'\s+',' ',body.replace(r['title'],'{TEMA}')).strip()].add(code)
    for par in re.split(r'\n\s*\n',t):
        pnorm=norm(par,r)
        if len(pnorm)>=160 and not pnorm.startswith('```'):para_groups[pnorm].add(code)
    ev=[quote_evidence(t,ss,'E-FUND',r'fundamento|problema em|problema concreto|objetivo'),quote_evidence(t,ss,'E-MEC',r'mecanismo|modelo mental|arquitetura mental|fluxo|procedimento'),quote_evidence(t,ss,'E-LAB',r'laboratório|prática guiada|procedimento|atividade'),quote_evidence(t,ss,'E-QUIZ',r'quiz'),quote_evidence(t,ss,'E-FLASH',r'flashcard'),quote_evidence(t,ss,'E-DEF',r'detectar|detecção|observabilidade|defesa|corrigir|hardening|quality gate')]
    primary=next((c for c in cb if c['linguagem'] not in ['text','mermaid',''] and not c['texto'].startswith('identidade/host')),cb[0] if cb else None)
    if r['kind']=='parallel':
        ex=next(s for s in ss if s['heading'].startswith('5.'))
        found=re.search(r'```([^\n]*)\n(.*?)```',ex['text'],re.S)
        primary={'linguagem':found.group(1),'linha':ex['start']+ex['text'][:found.start()].count('\n'),'texto':found.group(2).strip()}
    ev.append({'id':'E-CODE','linha_inicial':primary['linha'],'linguagem':primary['linguagem'],'trecho':primary['texto'][:650],'trecho_abreviado':len(primary['texto'])>650} if primary else {'id':'E-CODE','status':'não localizado'})
    if r['kind']=='main':
        n=r['id'];grade,scores,issue,action=notes[n];family='retrofit' if n<=46 else 'gold' if n==47 else 'intermediate' if n<=100 else 'scaffold' if n<=200 else 'ai' if n<=208 else 'capstone'
        shared={'retrofit':'Mecanismo repete o resumo; lab não entrega ambiente completo; quiz tem distratores óbvios e flashcards de revisão pouco discriminativos.', 'gold':'Material substantivo com happy path, duas identidades, evidência e reteste; revisar divergências de apresentação e limites do proxy didático.', 'intermediate':'Conceitos específicos aproveitáveis; exemplo resolvido, troubleshooting e testes negativos ainda insuficientes. Quiz privilegia alternativa óbvia.', 'scaffold':'Quatro conceitos usam definições circulares e flashcards não explicativos; lab intercala comandos de inventário e procedimentos em texto. Reforço v3 curto não resolve o núcleo.', 'ai':'Fundamentos específicos, mas mecanismo, cinco passos de lab, defesa, desafio e perguntas reutilizados; faltam fixtures e resultados de política concretos.', 'capstone':'Etapa tem produto próprio, mas procedimento, exemplo preenchido e rubrica são genéricos. Ausência de quiz/flashcard não é penalizada por si só.'}[family]
        problems=[issue,shared];actions=[action]
    else:
        pre,num=code.split('-');n=int(num);family='parallel';goal=goals[pre][n-1]
        fundamental=next(s for s in ss if s['heading'].startswith('3.'))['text']
        generic='é estudado como uma transformação' in fundamental or 'elemento do modelo' in fundamental
        relevant=code in PAR_RELEVANT
        scores=[30 if generic else 45,25 if relevant else 20,30 if relevant else 10,15,10,25 if relevant else 15]
        if pre in ['LOG','LAB','CLD']:scores[2]=5
        if pre=='LOG' and generic:scores=[25,20,5,10,10,10]
        if pre=='LAB' and n<=10:scores=[30,20,5,15,10,10]
        if pre=='CLD':scores=[30,20,5,15,10,10]
        if pre=='CTR':scores=[40,20,20 if relevant else 10,15,10,20 if relevant else 15]
        if code in ['K8S-04','K8S-09']:scores=[20,15,5,10,10,5]
        if code in ['NET-24','NET-25','NET-36']:scores=[35,20,5,10,10,10]
        if code=='K8S-10':scores=[25,15,5,10,10,10]
        grade='D'
        issue=f"O exemplo real é {primary['texto'].replace(chr(10),' / ')[:150]}. "+('Demonstra apenas uma fração do objetivo.' if relevant else 'Não demonstra o mecanismo central do tema anunciado.')
        if pre=='LOG':issue='Exemplo é somente o fluxo “Entrada → regra de [tema] → saída”; não há algoritmo, valores ou teste de mesa resolvido.'
        if pre=='LAB':issue=f'Exemplo manda “Observe com {r["title"]}”, sem operação concreta da ferramenta ou artefato fornecido.'
        if pre=='CLD':issue='Exemplo repete “principal → ação → recurso → condição”, sem cenário/serviço e decisão de política resolvida.'
        if code=='NET-36':issue+=' Curl usa HTTP claro, não TLS; promessa de observar certificados deve distinguir TLS 1.3.'
        if code=='WIN-27':issue+=' Coleta System, embora o objetivo seja Security Logs.'
        if code in ['K8S-04','K8S-09']:issue+=' Conteúdo de IAM substitui o assunto Kubernetes.'
        if code=='LAB-26':issue+=' Distinguir profiles antigos do modelo de símbolos do Volatility 3.'
        if pre=='CTR' or code=='K8S-10':issue+=' Base alpine:3.20 está fora de suporte na data da auditoria.'
        shared='Definição '+('genérica/circular' if generic else 'curta, ainda sem aprofundamento')+'; prática guiada transfere a criação do caso positivo/negativo ao aluno; quiz Q3–Q5 idêntico nas 325 unidades e distratores implausíveis; flashcards de elementos não definem os conceitos.'
        problems=[issue,shared];actions=[goal+'.','Reconstruir explicação causal e exemplo resolvido; fornecer exercício parcial, prática independente e quiz/flashcards específicos do objetivo.']
    if family not in ['parallel','gold','capstone']:actions.append('Completar fixture/comandos/saída, negativo e reteste; reescrever distratores e flashcards para decisões próprias do tema, sem apenas trocar o título.')
    if family=='capstone':actions.append('Manter avaliação por produto, substituindo rubrica abstrata por critérios observáveis e exemplos de trabalho insuficiente/adequado.')
    if family=='gold':actions.append('Validar novamente os comandos publicados contra os arquivos do lab; declarar limitações de TTL, autenticação simulada e uso exclusivamente didático.')
    priority='P0' if (r['kind']=='main' and n in P0MAIN) or code in P0PAR or code in P0FOUND else 'P1'
    if r['kind']=='main' and 161<=n<=180:priority='P0'
    srcs=source_ids(r)
    if (r['kind']=='parallel' and pre=='CTR') or code=='K8S-10':srcs=list(dict.fromkeys(srcs+['F47']))
    score=dict(zip(DIM,scores));answers=re.findall(r'\*\*Resposta:\*\*\s*([A-D])',t)
    answers+=re.findall(r'\*\*Resposta:\s*([A-D])',t)
    answers+=re.findall(r'(?m)^\s*- ([A-D])\).*✅',t)
    status_update='Não foi identificado desatualizado concreto na leitura; isso não certifica atualidade de toda a bibliografia.'
    if code=='AULA-047':status_update='Requisito Node 18+ inclui runtime EOL; fixar versão mantida. Ref. F48.'
    if (r['kind']=='parallel' and pre=='CTR') or code=='K8S-10':status_update='alpine:3.20 encerrou suporte em 2026-04-01; atualizar base e fixar versão/digest. Ref. F47.'
    if code=='AULA-207':status_update='A edição OWASP LLM Top 10 2026 existe; lacuna é conteúdo/versionamento/mapeamento, não inexistência da edição. Ref. F38.'
    if code in ['LAB-26','NET-36']:status_update='Há nuance de versão indispensável: '+issue
    criteria=[]
    for idx,title in enumerate(CRIT,1):
        state='parcial';detail='';refs=[]
        if idx==1:detail=problems[0];refs=['E-FUND','E-CODE']
        elif idx==2:detail=actions[0];state='insuficiente' if grade=='D' else 'adequado' if grade=='B' else 'parcial';refs=['E-FUND','E-MEC']
        elif idx==3:detail='Sequência nominal existe; faltam dependências explicadas e progressão por dificuldade com solução comentada.';refs=['E-MEC','E-LAB']
        elif idx==4:detail=shared;refs=['E-MEC']
        elif idx==5:detail=problems[0];refs=['E-CODE']
        elif idx==6:detail='Explicar o exemplo não equivale a resolver um caso: faltam entradas, decisões intermediárias e conclusão verificável.';state='insuficiente';refs=['E-CODE','E-LAB']
        elif idx==7:detail=issue;refs=['E-CODE']
        elif idx==8:detail='Explicação em torno do snippet é curta ou procedimental; faltam contratos, contexto de execução e limites por linha relevante.';refs=['E-CODE']
        elif idx==9:detail='Há atividade indicada; avaliar os passos reais, não a existência da seção.';refs=['E-LAB']
        elif idx==10:detail='Auditoria estática: dependências, inputs ou resultados não fecham uma execução autônoma completa. '+actions[0];state='insuficiente';refs=['E-LAB','E-CODE']
        elif idx==11:detail='Há código/comando, mas ele deve produzir a evidência do objetivo, não só versão/inventário ou sucesso genérico.';refs=['E-CODE','E-LAB']
        elif idx==12:detail='Resultado geral é descrito, mas falta saída concreta e verificável para o cenário completo.';refs=['E-LAB']
        elif idx==13:detail='Checkpoints pedem explicação/evidência em termos gerais; falta resposta de referência por passo.';refs=['E-LAB']
        elif idx==14:detail='Troubleshooting predominantemente versão/permissão/path/estado; não conecta sintoma específico à causa e correção.';state='insuficiente';refs=['E-LAB']
        elif idx==15:detail='Fluxo e princípio são mencionados; causalidade precisa de estado concreto e contraexemplo. '+actions[0];refs=['E-MEC']
        elif idx==16:detail='O texto delimita ambiente próprio, local, fictício ou explicitamente autorizado. A auditoria não promove uso em terceiros.';state='adequado';refs=['E-LAB']
        elif idx==17:detail='Sinais/observabilidade são indicados, sem contrato completo de dados e teste positivo/negativo.';refs=['E-DEF']
        elif idx==18:detail='Princípios defensivos existem; falta demonstrar aplicação ao caso, limites e preservação de uso legítimo.';refs=['E-DEF','E-CODE']
        elif idx==19:detail='Reteste é solicitado; mesmo input, assertiva e saída corrigida ainda precisam ser fornecidos.';refs=['E-LAB','E-DEF']
        elif idx==20:detail='Erros comuns são em grande parte hábitos gerais de investigação; incluir enganos conceituais do tema.';refs=['E-MEC']
        elif idx==21:detail='Desafio pede sintetizar ou criar cenário; falta escopo concreto, insumos e critério de sucesso específico.';refs=['E-LAB']
        elif idx==22:detail='Perguntas frequentemente recuperam frases da aula ou boas práticas gerais, sem exigir aplicação a evidência nova.';state='insuficiente';refs=['E-QUIZ']
        elif idx==23:detail='Distratores caricatos tornam o gabarito previsível. '+('Respostas encontradas: '+''.join(answers)+'.' if answers else '');state='insuficiente';refs=['E-QUIZ']
        elif idx==24:detail='Cards repetem definições curtas ou convites para explicar, sem recuperação discriminativa e exemplos contrastantes.';state='insuficiente' if family in ['parallel','scaffold'] else 'parcial';refs=['E-FLASH']
        elif idx==25:detail=shared;state='problema identificado';refs=['E-QUIZ','E-FLASH','E-LAB']
        elif idx==26:detail=shared;state='problema identificado' if grade=='D' else 'parcial';refs=['E-FUND','E-MEC']
        elif idx==27:detail=issue;state='problema identificado' if grade=='D' else 'parcial';refs=['E-CODE','E-LAB']
        elif idx==28:detail=actions[0];state='lacuna identificada';refs=['E-FUND','E-CODE','E-LAB']
        elif idx==29:detail=status_update;state='revisar' if ('EOL' in detail or 'encerrou' in detail or 'nuance' in detail) else 'sem erro concreto identificado';refs=[]
        elif idx==30:detail='Referências recomendadas: '+', '.join(srcs)+'. Consultar o arquivo de fontes para finalidade e status de validação.';state='recomendação';refs=[]
        if family=='gold' and idx in [3,4,5,6,8,9,11,12,13,15,17,18,19,20,21,24,25,26,27]:state='adequado' if idx not in [18,24] else 'parcial';detail='Conteúdo específico com casos públicos/privados, Alice/Bob, mecanismo de chave/cacheability, comandos e reteste. '+('Ajustar limites descritos e qualidade da avaliação.' if idx in [18,24] else '');refs=['E-CODE','E-LAB']
        if family=='gold' and idx==10:state='executado com ressalvas';detail='Lab original executado em cópia: vazamento Alice→Bob e correção reproduzidos por X-Lab-User. Comandos Cookie do JSON produziram anonymous; contrato de bypass para asset autenticado diverge.'
        if family=='capstone' and idx in [7,8,11,22,23,24]:state='não aplicável';detail='Etapa de projeto avaliada pelo produto e rubrica; não se exige quiz, flashcard ou código quando não são o objetivo. A nota de avaliação considera a qualidade da rubrica.'
        if family=='parallel' and pre in ['LOG','LAB','CLD'] and idx in [7,8,11]:state='insuficiente';detail='Texto dentro de code fence descreve intenção; não fornece algoritmo, decisão resolvida ou comando operacional. '+actions[0]
        criteria.append({'n':idx,'critério':title,'status':state,'análise':detail,'evidências':refs})
    row={'id':code,'trilha':r['track'],'título':r['title'],'classificação':grade,**score,'problemas':problems,'ações_recomendadas':actions,'bloco':blockof(r),'média':round(statistics.mean(scores),2),'prioridade':priority,'tipo':r['kind'],'profundidade_declarada':r.get('depth'),'família_editorial':family,'arquivo':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'avaliação_estática':True,'execução': 'lab original executado em cópia' if code=='AULA-047' else 'microteste do snippet' if code in ['AULA-009','AULA-036','AULA-052'] else 'não executada; análise estática','evidências':ev,'critérios':criteria,'fontes_recomendadas':srcs,'gabarito_observado':answers,'blocos_de_código':[{'linha':c['linha'],'linguagem':c['linguagem'],'sha256':hashlib.sha256(c['texto'].encode()).hexdigest()} for c in cb]}
    if r['kind']=='main' and 47<=n<=60:
        jp=ROOT/f'src/content/main/{n:03}/lesson.json';j=json.loads(jp.read_text())
        row['representações_adicionais']=[{'arquivo':str(jp.relative_to(ROOT)),'sha256':hashlib.sha256(jp.read_bytes()).hexdigest(),'quiz_gabarito':[q.get('answer') for q in j.get('review',{}).get('quiz',[])],'nota':'JSON V2 inspecionado junto ao MD; não contado como unidade adicional. Exemplo resolvido/fading/expecativas de 48–60 ainda gerados por template.' if n!=47 else 'Divergências confirmadas no teste e inspeção: Cookie/X-Lab-User e barra-n literal nos snippets.'}]
    rows.append(row)

# Comparação transversal de conteúdo, preservando a lista de unidades por bloco.
# Shingles de cinco palavras após retirar headings e normalizar apenas título/ID.
shingles=[]
for r in raws:
    words=re.findall(r'\w+',norm(text_by[r['code']],r));shingles.append(set(zip(*(words[k:] for k in range(5)))))
neighbors=[[] for _ in rows]
for i in range(len(rows)):
    for j in range(i+1,len(rows)):
        inter=len(shingles[i]&shingles[j]);union=len(shingles[i])+len(shingles[j])-inter
        val=inter/union if union else 0
        if val>=.45:neighbors[i].append((val,j));neighbors[j].append((val,i))
for i,row in enumerate(rows):row['vizinhos_textuais']=[{'id':rows[j]['id'],'jaccard_5_palavras':round(v,3)} for v,j in sorted(neighbors[i],reverse=True)[:3]]
stats=[]
for b in blocks:
    rr=[r for r in rows if r['bloco']==b];cnt=collections.Counter(r['classificação'] for r in rr)
    stats.append({'bloco':b,'unidades':len(rr),**{x:cnt[x] for x in 'ABCD'},**{d:round(statistics.mean(r[d] for r in rr),2) for d in DIM},'média':round(statistics.mean(r['média'] for r in rr),2)})
counts={k:sum(r['classificação']==k for r in rows) for k in 'ABCD'}
rank=sorted(rows,key=lambda r:(-r['média'],r['id']));worst=sorted(rows,key=lambda r:(r['média'],r['id']))
clusters=[]
for typ,g in [('código',code_groups),('parágrafo',para_groups)]:
    for txt,ids in sorted(g.items(),key=lambda x:(-len(x[1]),x[0])):
        if len(ids)>=5:clusters.append({'tipo':typ,'unidades':sorted(ids),'quantidade':len(ids),'texto_normalizado':txt,'sha256':hashlib.sha256(txt.encode()).hexdigest()})
meta={'fase':15,'data':'2026-09-02','escopo':'conteúdo; nenhuma aula corrigida','zip':'CyberStudyHub_Fases_00_14_cumulativo.zip','zip_sha256':hashlib.sha256((BASE/'CyberStudyHub_Fases_00_14_cumulativo.zip').read_bytes()).hexdigest(),'drive_file_id':'1_yxE0prbL9x715ZxR51AzSg3BQoa_bX6','unidades':543,'principais':218,'paralelas':325,'contagens':counts,'dimensões':DIM,'escala':'julgamento editorial em passos de 5; não é medida psicométrica nem percentual de afirmações verdadeiras','classificação':'A pronta; B revisão localizada; C núcleo aproveitável que exige aprofundamento; D núcleo majoritariamente scaffolding/template. Classificação não é calculada só pela média.','leitura':'Inspeção estática por unidade, agrupamento de trechos repetidos e exame das variantes de texto/código/lab/quiz/flashcards. MD e os 14 JSON V2 considerados conjuntamente.','limites':'Somente Aula 47 executada integralmente no ambiente disponível; 9/36/52 receberam microtestes. Sem VMs Windows/AD, cluster ou cloud real. Não houve validação experimental dos demais labs. Ausência refere-se ao pacote auditado, não a arquivos fora dele.'}
payload={'metadados':meta,'resumo_por_bloco':stats,'melhores_20':[r['id'] for r in rank[:20]],'piores_20':[r['id'] for r in worst[:20]],'unidades':rows,'duplicações':clusters,'fontes':[dict(zip(['id','título','url','uso','status'],s)) for s in SOURCES]}
(OUT/'FASE_15_QA_543.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
fields=['id','trilha','título','classificação']+DIM+['problemas','ações_recomendadas']
with (OUT/'FASE_15_QA_543.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for row in rows:w.writerow({k:' | '.join(row[k]) if isinstance(row[k],list) else row[k] for k in fields})

def esc(x):return str(x).replace('|','\\|').replace('\n',' ')
def table(headers,data):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(esc(x) for x in line)+' |\n' for line in data)
def blocktable():return table(['Bloco','N','A','B','C','D','Técnico','Didática','Prática','Defesa','Avaliação','Especificidade','Média'],[[s['bloco'],s['unidades'],*[s[k] for k in 'ABCD'],*[f'{s[k]:.1f}' for k in DIM],f"{s['média']:.1f}"] for s in stats])
def ranking(rr):return table(['ID','Título','Classe','Média','Achado determinante'],[[r['id'],r['título'],r['classificação'],f"{r['média']:.1f}",r['problemas'][0]] for r in rr])
def ids(rr):return ', '.join(r['id'] for r in rr)
def write(name,txt):(OUT/name).write_text(txt+'\n')

BLOCK_NOTES={
'1–46':'Núcleos úteis de Web/AppSec foram envolvidos em repetição do próprio resumo e reforços nem sempre pertinentes. Priorizar contaminação de ORM em 001, CSRF em 009, SSRF em 015, código interpolado em 020/036 e casos sem app. Nenhuma aula deve ganhar prontidão só por ter mais seções.',
'47–60':'047 é a única referência interna com laboratório físico completo e teste bem-sucedido do objetivo. As outras 13 têm conceitos específicos, mas a conversão V2 criou worked examples que narram passos, fading que apaga uma caixa do fluxo e expected genérico. Manter o conteúdo causal aproveitável e completar os cenários.',
'61–78':'Comandos de enumeração são aproveitáveis. A cadeia AD depende de domínio, RSAT, contas, DNS, relógio, GPO e audit policy não entregues. Diferenciar inventário de validação de vulnerabilidade; /health e banner não provam impacto.',
'79–100':'Melhor concentração de exemplos defensivos específicos: Sigma, YARA, logs, árvores e métricas. Faltam datasets, geradores, schemas/pipelines e falsos positivos resolvidos. Não classificar query sintaticamente plausível como detecção operacional.',
'101–130':'Vocabulário de C/internals/RE está presente, mas definições e flashcards circulares dominam. cc --version não substitui fonte/binário, disassembly e debugging. Capstone 130 precisa de artefatos e investigação integrada, não apenas matriz.',
'131–160':'A triagem é anunciada sem amostra educacional, PCAP, EVTX e dump de memória. Entropy 135 contém ROP/DEP indevido. EICAR é útil para teste benigno de AV, mas não substitui uma fixture comportamental completa.',
'161–180':'Todas as 20 unidades chamam make_fixtures.py ausente e ocultam erro. Precisa de cadeia fonte→build→input→crash→causa→patch→regressão, com mitigadores isolados e diferenças entre crash e explorabilidade.',
'181–190':'Escopo/ROE e intenção defensiva são pontos positivos. Simulações, IDs de técnicas, logs e cleanup não formam exercícios executáveis. Distinguir emular resultado de explorar uma falha e medir detecção com atividades benignas.',
'191–200':'Temas atuais foram comprimidos em fragmentos declarativos: IAM pseudo, CI sem steps, RLS sem ativação, Electron sem contexto. Cada tecnologia exige implementação mínima própria, identidade e testes de permissão.',
'201–208':'Princípio modelo propõe/política decide é sólido. Rotular prompt não cria isolamento; bool approved não representa aprovação vinculada; RAG requer ACL e revogação reais. Edição OWASP 2026 existe, mas a aula não ensina seu conjunto de categorias.',
'209–218':'Dez produtos distintos têm praticamente o mesmo corpo e exemplo preenchido abstrato. Avaliação por artefatos é adequada ao capstone, mas deve usar insumos, produtos-modelo e critérios específicos da fase; quiz/flashcard são opcionais aqui.',
'Logic':'Não há algoritmos resolvidos: o exemplo repete entrada→regra do título→saída. Ensinar teste de mesa, condições, loops, funções, recursão e estados com valores concretos antes de pedir aplicação em segurança.',
'Python':'16/20 exemplos técnicos são a mesma list comprehension. JSON/regex/hash são melhores sementes, porém arquivos, exceções, venv, sockets, CLI e parsing não são efetivamente ensinados.',
'JavaScript/TypeScript':'9/10 exemplos JS usam map; os cinco TS repetem User/role. DOM tem exemplo pertinente. Faltam closures, eventos, async, fetch, Node/Express e diferença entre tipo estático e validação em runtime.',
'C':'14 exemplos usam if; seis usam print de ponteiro. Arrays, strings, structs, heap/malloc, arquivos e sanitizers não recebem código correspondente. Esta lacuna inviabiliza progressão segura para 101–180.',
'Bash':'Os dez exemplos repetem printf/grep/rm em /tmp/lab.txt. Quoting, expansão, loops, funções, processos e diagnóstico de rede precisam de operações próprias. Ensinar mktemp/trap e não colidir com arquivos existentes.',
'PowerShell':'As dez unidades repetem Get-Process/Select/Format-Table. Pipeline de objetos é uma boa introdução, mas não ensina serviços, rede, registry, AD ou coleta. Preservar objetos antes de formatar para tela.',
'Networks':'Há definições específicas úteis, porém exemplos frequentemente inventariam IP/rotas. HTTP claro é reaproveitado em HTTPS/TLS; PCAP inexistente. Ensinar cabeçalhos/estados com traces e limites TLS 1.3.',
'Linux':'26/30 exemplos usam pwd/id/uname. Permissões e processos têm sementes melhores; systemd, logs, sudoers, capabilities e firewall não têm demonstração do mecanismo.',
'Windows':'25/30 exemplos repetem whoami/Get-Process. Services/Registry/Event Viewer têm algo específico; Security Logs coleta System. Tokens, UAC, PE, Sysmon e hardening precisam de VM e evidência própria.',
'Web Development':'32/40 exemplos imprimem input.length. Cinco unidades HTTP mostram a mesma request, inclusive Response/Status; três Express mostram /health. Sem fundamentos reais a trilha AppSec fica dependente de conhecimento externo.',
'Engineering/Git':'Os 30 exemplos executam o mesmo commit inicial. Reutilizar repo seria saudável se cada etapa acrescentasse branch/merge/teste/CI; aqui os objetivos novos não são demonstrados. Separar Git de GitHub.',
'Labs/Tools':'Todos os 30 exemplos mandam definir escopo/gerar evento/observar com [título]. As definições de ferramentas são úteis como glossário; falta ensinar uso, configuração, fixture, output e cleanup.',
'Cloud/Containers/Kubernetes':'Dez CLD usam matriz de IAM; dez CTR usam Dockerfile id/echo; K8S tem colisões de tema em Services/Security Context e capstone reduzido a Dockerfile. Alpine 3.20 está fora de suporte. Precisam de cenários por recurso e autorização verificável.'}

master=f'''# Fase 15 — Auditoria de conteúdo do Cyber Study Hub

Data de corte: **2026-09-02**. Fonte principal: ZIP exato obtido no Google Drive. Escopo: conteúdo técnico e didático, sem alterações nas aulas.

## Parecer executivo

**A: {counts['A']} · B: {counts['B']} · C: {counts['C']} · D: {counts['D']} — 543 unidades.** O catálogo é abrangente, mas a maior parte do material ainda não sustenta estudo autônomo no nível anunciado. A presença de campos, extensão do arquivo e número de seções não foram usados como prova de qualidade.

A Aula 047 é B: seu núcleo e laboratório são substanciais e funcionam pelo percurso do Markdown; os reparos são localizados no contrato JSON/MD, snippets, limitações e distratores. A prioridade alta de alinhar esses comandos não significa reescrever seu núcleo. Nenhuma unidade recebeu A. As C preservam explicações específicas, mas exigem aprofundamento e prática; as D exigem reconstrução do núcleo, mesmo quando há um parágrafo correto ou um comando executável.

## Corpus e rastreabilidade

- 218 principais e 325 paralelas, identificadas pelo catálogo `src/curriculum/catalog.json`, com 543 IDs únicos e 543 Markdown existentes.
- 14 JSON V2 de 047–060 foram inspecionados junto aos MD; não foram contados como mais 14 aulas.
- O ZIP é um pacote cumulativo para aplicação em checkout existente. As conclusões de ausência valem para os arquivos recebidos; não presumem o conteúdo de versões externas.
- SHA-256 do ZIP: `{meta['zip_sha256']}`.
- Único diretório de laboratório fornecido: `public/course-labs/aula-047/` (cinco arquivos). Isso não significa que todo exercício deva possuir um diretório: código completo inline também pode ser suficiente. O problema é quando a atividade depende de arquivos/estado que o texto não fornece.
- Cada registro JSON contém caminho, hash, evidências com linha/seção, seis notas, 30 critérios, ações e fontes. As notas de linha são do arquivo original, sem correção.

## Método e escala

Leitura estática por unidade de texto, código, laboratório, quiz e flashcards, com comparação de blocos repetidos e inspeção das variantes. Também foram consideradas a profundidade anunciada, a adequação ao tema e as dependências didáticas. Os scripts fizeram inventário, extração, hashes, duplicação e consolidação; notas de presença/schema não determinaram a classe. Os trechos de evidência são seleções, não todo o texto utilizado.

As seis notas são julgamentos editoriais em passos de cinco: 0–19 ausente/scaffold; 20–39 fragmentário; 40–59 parcial; 60–79 núcleo útil com lacunas; 80–100 robusto para o objetivo. **Conteúdo técnico inclui precisão, profundidade e completude: 40 não significa 40% de afirmações verdadeiras.** A média é aritmética simples das seis dimensões, sem peso por tamanho. Médias por bloco dão peso igual a cada unidade. Classes são decisões qualitativas, não cortes automáticos da média. Diferenças pequenas de nota não sustentam uma hierarquia forte; empates são ordenados por ID.

Os 30 critérios constam em cada unidade JSON. “Não aplicável” é usado em 209–218 para código/quiz/flashcards quando o produto da etapa não os exige. Sua avaliação considera rubrica e produtos, não ausência de perguntas. Em Logic e aulas operacionais, defesa significa robustez/validação/observabilidade pertinente; não se exige inventar uma exploração em toda lição. Um exercício de mesa pode ser prática válida se tiver dados, decisões e gabarito.

**Limite experimental:** somente o lab 047 foi executado integralmente, em cópia. Snippets de 009, 036 e 052 receberam microtestes. Os demais labs foram avaliados estaticamente; não há alegação de execução de 543 laboratórios nem de certificação técnica exaustiva. Não foram usados ambientes Windows/AD, cloud ou Kubernetes reais. Isso não impede concluir que um arquivo referenciado está ausente ou que um quiz repete o de outra unidade.

## Achados prioritários

1. **Contaminação entre temas:** 001 ensina ORM no reforço; 135 inclui ROP/DEP em Entropy; K8S-04/09 recebem exemplo IAM; C-06 ensina arrays com if. Conteúdo correto em outro contexto pode ser incorreto didaticamente nesta aula.
2. **Prática incompleta:** 101 pede lab.c não fornecido; 131–160 dependem de amostras/telemetria ausentes; 161–180 chamam make_fixtures.py inexistente e escondem falha. Requisitar que o aluno crie o laboratório inteiro não equivale a entregá-lo.
3. **Defesa que parece completa, mas não é:** CSRF ausente passa em 009; SSRF 015 não controla redirects/IP; safePath 052 não impede symlink externo; RLS 198 não mostra ativação/roles. Distinguir demonstração limitada de controle suficiente. [CSRF](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html), [SSRF](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html), [RLS](https://www.postgresql.org/docs/current/ddl-rowsecurity.html).
4. **Avaliação previsível:** paralelas Q3–Q5 iguais, distratores óbvios e resposta A em todas as cinco; 101–200 repetem quatro das cinco perguntas e o padrão A/B/B/B/A. Não basta embaralhar alternativas: precisam representar erros plausíveis do tema.
5. **Definições circulares:** “elemento do modelo” e flashcards “explique sua função” não ensinam nem fornecem resposta de revisão.
6. **Falsa progressão:** versões/etiquetas “profunda”, “V2” e “v3” não garantem incremento substantivo. Worked examples de 048–060 frequentemente apenas conectam uma etapa verbal à seguinte.
7. **Modernização seletiva:** atualizar base Alpine 3.20, requisito Node 18+, modelos de símbolos de Volatility e visibilidade TLS 1.3. A edição OWASP LLM Top 10 2026 existe; a lacuna de 207 é não ensinar seu conteúdo de forma verificável. [Alpine](https://alpinelinux.org/releases/), [Node](https://nodejs.org/en/about/eol), [TLS 1.3](https://www.rfc-editor.org/rfc/rfc8446.html), [OWASP 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/).

## Aula 047 — referência interna, com ressalvas

Pontos fortes: problema concreto, cacheability versus cache key, diferença entre deception/poisoning, happy path de asset público, rota privada, duas identidades, comandos, headers e comparação antes/depois. É a referência de maior utilidade, sem impor sua forma a Logic ou capstones documentais.

Teste efetuado com os arquivos originais em cópia e Express instalado:

| Caso | Resultado observado |
| --- | --- |
| Proxy vulnerável: Alice depois Bob em /account/profile.css com X-Lab-User | MISS Alice → HIT Alice: vazamento reproduzido |
| Proxy corrigido: mesmas duas identidades | BYPASS Alice → BYPASS Bob: isolamento do caso reproduzido |
| Comandos equivalentes com Cookie, como no JSON V2 | anonymous para ambas as requisições: não demonstra isolamento entre usuários |
| Asset público aquecido anonimamente e depois pedido com X-Lab-User | HIT: consulta do cache ocorre antes de canStore; promessa de todo autenticado dar BYPASS é excessiva |

O último resultado não demonstrou vazamento de conteúdo privado no proxy corrigido: o asset é público. Ele demonstra divergência de contrato. Map não implementa TTL; o mock só transporta X-Lab-User. O relatório não trata esse código didático como proxy de produção. No JSON, o primeiro codeExample tem uma linha física e 12 sequências literais de barra-n, prejudicando cópia e anotações.

## Outros testes pontuais

| Unidade | Teste | Resultado |
| --- | --- | --- |
| 009 | Executar comparação com body/session presentes, mas csrfToken ausente em ambos | Fluxo passou |
| 036 | node --check do snippet STRIDE | SyntaxError no literal Denial of Service quebrado por newline |
| 052 | Symlink criado dentro de public-files apontando para arquivo sintético fora dela | safePath aceitou e leitura retornou o dado sintético externo |

## Pontos fortes preserváveis

O currículo cobre temas relevantes e conecta operação, investigação e correção. Delimita repetidamente ambientes próprios/autorizados. 048–100 possuem conceitos e pequenos exemplos úteis; 086/087/098/100 e 054/056/057 são boas sementes. O bloco AI acerta ao colocar autorização fora do modelo. Há intenção consistente de baseline, evidência, negativo e reteste. Preservar esses princípios; preencher sua implementação específica.

## Riscos pedagógicos e técnicos

Pedagógicos: decorar linguagem de investigação sem compreender mecanismo; interpretar quiz fácil como domínio; depender de conhecimentos não ensinados; confundir descrição de experimento com experimento; repetir uma definição superficial até parecer familiar. A trilha opcional pode continuar livre, mas a aula avançada precisa explicar requisitos ou apontar conteúdo realmente suficiente.

Técnicos: copiar fragmentos defensivos incompletos; aceitar sucesso ocultando erros; concluir vulnerabilidade por versão/healthcheck; correlacionar eventos sem identidade/tempo; operar software fora de suporte; confundir autorização simulada com controle real. As falhas do material não provam vulnerabilidades de um aplicativo implantado: esta auditoria não avaliou um sistema em produção.

## Consolidação por bloco

{blocktable()}

'''+''.join(f'### {b}\n\n{BLOCK_NOTES[b]}\n\n' for b in blocks)+f'''## 20 melhores unidades relativas

“Melhor” é posição relativa no corpus; C continua exigindo aprofundamento, e B ainda não é pronta. Empates por ID.

{ranking(rank[:20])}

## 20 piores unidades relativas

Empates por ID. Outras unidades D empatadas ou próximas exigem a mesma atenção; esta lista não limita o backlog.

{ranking(worst[:20])}

## Maiores lacunas globais

1. Fundamentos executáveis de programação, redes e sistemas nas paralelas.
2. Mecanismo causal com estado concreto, exemplo resolvido e explicação das decisões.
3. Fixtures versionadas, inputs, comandos, resultados observáveis e limpeza.
4. Happy path, caso que demonstra a falha, negativo plausível e regressão após correção.
5. Telemetria com schema, campos, identidade, tempo, consulta/regra e falsos positivos.
6. Avaliação de transferência: interpretar código/log/trace novo; distratores plausíveis e cards com respostas específicas.
7. Capstones integrados com materiais e produtos de referência, não apenas nomes de arquivos.
8. Atualização controlada e fontes por mecanismo, com versão e data de revisão.

## Ordem recomendada para a Fase 16

1. Corrigir contradições/erros de maior impacto e estabilizar a referência 047: 001, 009, 015, 020, 036, 047, 052, 135, 193, 195, 198 e colisões K8S; reparar os comandos/fixtures de 161–180 antes de usá-los.
2. Reconstruir fundações que desbloqueiam o restante: Logic, Python básico, C básico, Web HTTP/JS, Networks e Labs de isolamento. Trabalhar em pequenos lotes com um exemplo aceito antes de escalar.
3. Completar Web/AppSec 001–060 com apps e dados locais, priorizando autenticação/autorização, CSRF/SSRF/cache e API.
4. Completar 061–100 e paralelas Linux/Windows/Networks com VMs, logs e datasets; usar Sigma/YARA como pilotos defensivos.
5. Reconstruir 101–180 em três cadeias de fixtures: binários próprios, investigação inerte e bugs de memória com patch/reteste.
6. Completar 181–200 e Engineering/Cloud/Containers/K8S com políticas e pipelines executáveis e controles de identidade.
7. Integrar 201–208 e 209–218 depois de os blocos precedentes terem materiais utilizáveis; revisar avaliações ao concluir cada lote, não só no fim.

Critério de aceite por lote: explicar mecanismo, executar ou resolver a prática no ambiente declarado, reproduzir resultado, testar negativo/happy path, corrigir e retestar, responder avaliação específica. Não exigir mecanicamente todas as etapas de exploração em temas conceituais.

## Entregáveis e decisão

CSV contém uma linha por unidade e os campos solicitados. JSON contém a mesma auditoria, 30 critérios e rastreabilidade adicional. Backlog, duplicações, lacunas e fontes detalham ações e IDs. O pacote de evidências inclui resultados dos testes e scripts de consolidação. **Nenhuma aula foi corrigida ou reescrita. A Fase 16 depende de sua aprovação.**
'''
write('FASE_15_AUDITORIA_CONTEUDO_MASTER.md',master)

# Backlog: todos os IDs, com P0/P1 específico e lotes editoriais posteriores.
back='''# Fase 15 — Backlog de conteúdo

Somente plano de correção; nenhuma tarefa abaixo foi implementada. P0 indica erro/inadequação com alto impacto no aprendizado ou dependência que bloqueia o percurso, não necessariamente vulnerabilidade explorável. P1 é aprofundamento/reconstrução substantiva. P2 e P3 devem ocorrer depois da aceitação técnica do lote. Cada uma das 543 unidades tem tarefa individual abaixo; lotes compartilham infraestrutura, não texto de aula.

## Critérios de conclusão

Toda tarefa P0/P1 deve produzir o conteúdo específico solicitado, insumos, resultado esperado e evidência de revisão. Para labs: happy path, caso-alvo, negativo, correção, reteste e cleanup quando aplicáveis. Para teoria/projeto: caso resolvido, decisão justificada e produto avaliado. Reclassificar só após leitura e execução/resolução correspondente; não promover por schema.

'''
for priority in ['P0','P1']:
    back+=f'## {priority} — '+('Conteúdo inadequado/importante' if priority=='P0' else 'Aprofundamento necessário')+'\n\n'
    for b in blocks:
        rr=[r for r in rows if r['prioridade']==priority and r['bloco']==b]
        if not rr:continue
        back+=f'### Lote {b}\n\n'
        for r in rr:back+=f'- [ ] **{r["id"]} — {r["título"]} ({r["classificação"]})**. Problema: {r["problemas"][0]} Ação: '+ ' '.join(r['ações_recomendadas'])+'\n'
        back+='\n'
back+='## P2 — Melhoria editorial\n\n'
for b in blocks:
    rr=[r for r in rows if r['bloco']==b]
    back+=f'- [ ] **{b}**: padronizar terminologia, idioma, links internos e rótulos de linguagem; remover artefatos de conversão; revisar pré-requisitos e tempo sugerido depois de medir a prática. IDs: {ids(rr)}.\n'
back+='\n## P3 — Refinamento opcional\n\n'
for b in blocks:
    rr=[r for r in rows if r['bloco']==b]
    back+=f'- [ ] **{b}**: acrescentar variantes de ambiente, exercícios de transferência e referências comentadas opcionais após estabilizar o núcleo. IDs: {ids(rr)}.\n'
write('FASE_15_BACKLOG_CONTEUDO.md',back)

dup='''# Fase 15 — Duplicações de conteúdo

## Método e interpretação

Comparação exata de código e parágrafos após normalizar whitespace; segundo passe substitui somente título/ID por marcador. Comparação aproximada por Jaccard de shingles de cinco palavras no corpo sem headings; os três vizinhos mais próximos acima de 0,45 estão no JSON. O índice mede semelhança textual, não originalidade intelectual, e não é usado sozinho para dar nota. Trechos curtos, sintaxe idiomática e títulos de seção não são prova de template nocivo.

**Padronização saudável:** escopo autorizado, cabeçalhos, registro de baseline, evidência, correção/reteste e instruções de organização podem se repetir. **Repetição artificial:** a mesma explicação/quiz/lab ocupa o lugar da competência distinta prometida pelo título. Reutilizar o mesmo projeto é saudável quando cada aula acrescenta comportamento observável e profundidade; repetir o mesmo commit ou print sem progressão não é.

## Padrões confirmados

| Padrão | Unidades | Consequência e substituição |
| --- | --- | --- |
| Quiz Q3–Q5 literal e cinco respostas A | Todas as 325 paralelas | Mede reconhecimento de boas práticas genéricas; criar problemas, logs/código e distratores de erro conceitual do tema |
| Quatro flashcards Baseline/Caso positivo/Caso negativo/Reteste repetidos | Todas as 325 paralelas | Úteis como glossário comum, não como revisão principal de 325 temas; centralizar e adicionar cards específicos |
| Definições de elementos e flashcards circulares | AULA-101–200 | “Elemento do modelo” e “explique sua função” não fornecem mecanismo/resposta; escrever contrato causal e exemplo |
| Quiz Q2–Q5 e gabarito A/B/B/B/A | AULA-101–200 | Trocar somente foco da Q1 não cria avaliação da nova competência |
| Exemplo input.length | 61 unidades, incluindo 29 principais e 32 WEB | É apenas inspeção de string; substituir por operação do objetivo; lista exata abaixo |
| List comprehension | 16 PY | Não ensina arquivo/exceção/socket/CLI; manter somente onde pertinente e completar tema |
| map em array | 9 JS | Não ensina eventos/Promises/fetch/Node/Express |
| if imprimindo ramo | 14 C | Não ensina arrays/strings/structs/arquivos/sanitizers |
| Print de ponteiro | 6 C | Pode introduzir endereço, mas não ensina heap/malloc/free/manipulação de memória |
| Commit inicial | ENG-01–30 | Branch/merge/rebase/testes/CI não aparecem no experimento |
| cc --version | 24 unidades entre 101–130 | Identifica toolchain; não é lab de internals/RE |
| make_fixtures.py ausente com erro ocultado | AULA-161–180 | Devolve aparente sucesso sem material; entregar fixtures e expor falha |
| Worked examples que conectam frases de etapas | JSON V2 AULA-048–060 | Não são soluções trabalhadas; mostrar entrada, valores, decisão e evidência reais |
| Mesmo lab, defesa e desafio do assistente | AULA-201–208 | Cada tema precisa de teste próprio: ACL, approval binding, provenance, output handling etc. |
| Exemplo preenchido abstrato | AULA-209–218 | Nome de produto muda, conteúdo não demonstra um produto concreto; fornecer exemplares por etapa |

Observação: contagens referem-se a presença em unidades, não número de ocorrências dentro do mesmo arquivo. Os trechos comuns do JSON V2 não aumentam o denominador de 543. Os clusters exatos abaixo incluem estruturas saudáveis e nocivas: o parecer acima e a lacuna individual decidem a relevância.

## Clusters de código — IDs exatos

'''
for i,c in enumerate([c for c in clusters if c['tipo']=='código'],1):
    dup+=f'### C{i:03} — {c["quantidade"]} unidades\n\nTrecho normalizado: `{c["texto_normalizado"].replace("`","")[:450]}`\n\nIDs: '+', '.join(c['unidades'])+'.\n\n'
dup+='## Parágrafos repetidos — principais clusters\n\n'
for i,c in enumerate([c for c in clusters if c['tipo']=='parágrafo'][:45],1):
    dup+=f'### T{i:03} — {c["quantidade"]} unidades\n\n> {c["texto_normalizado"][:400]}\n\nIDs: '+', '.join(c['unidades'])+'.\n\n'
dup+='## Exemplos de proximidade textual\n\n'
pairs=[];seen=set()
for r in rows:
    for v in r['vizinhos_textuais']:
        pair=tuple(sorted([r['id'],v['id']]))
        if pair not in seen:seen.add(pair);pairs.append((*pair,v['jaccard_5_palavras']))
dup+=table(['Unidade 1','Unidade 2','Jaccard normalizado'],sorted(pairs,key=lambda x:-x[2])[:30])
dup+='\nTodos os clusters detectados estão no JSON. Não foi atribuída autoria nem inferida a ferramenta que gerou os textos. A conclusão é sobre repetição e utilidade didática observáveis.\n'
write('FASE_15_DUPLICACOES.md',dup)

gaps='''# Fase 15 — Lacunas de conteúdo

Ausência significa que o conhecimento não está explicado/praticado de maneira suficiente no pacote, mesmo quando aparece citado em um objetivo. Não significa que nenhum termo relacionado exista. Esta lista não exige exploração em toda aula nem substitui a disciplina por ferramentas.

## Lacunas globais

- Fundamentos operacionais, contratos de entrada/estado/saída e dependências explicadas.
- Exemplo resolvido com raciocínio intermediário; autoexplicação; exercício parcial; prática independente.
- Happy path e exemplos negativos concretos, não apenas a ordem “crie um negativo”.
- Código/configuração completos ou contexto explícito do fragmento; comentários de contratos e limites.
- Fixtures, versões, comandos, outputs, checkpoints e troubleshooting sintoma→causa→ação→reteste.
- Detecção por fonte/campo/identidade/tempo e avaliação de falso positivo.
- Correção causal, hardening compensatório, regressão legítima e risco residual.
- Quiz de aplicação e distratores plausíveis; flashcards com perguntas/respostas próprias do tema.
- Capstones integrados e referências por versão/mecanismo.

## Lacunas por bloco e unidade

'''
for b in blocks:
    gaps+=f'### {b}\n\n{BLOCK_NOTES[b]}\n\n'
    for r in rows:
        if r['bloco']==b:gaps+=f'- **{r["id"]} — {r["título"]}:** {r["ações_recomendadas"][0]}\n'
    gaps+='\n'
write('FASE_15_LACUNAS_DE_CONTEUDO.md',gaps)

sources='''# Fase 15 — Fontes recomendadas

Data de consulta: 2026-09-02. Fontes externas validam pontos e orientam enriquecimento; o corpus auditado continua sendo o ZIP real. “Consultada” indica acesso nesta auditoria; “recomendada para aprofundamento” não afirma leitura integral ou validação de todos os exemplos. Fixar versão, data e licença antes de incorporar material. Criar explicações e fixtures próprias; não copiar aulas, soluções nem material protegido.

Sider Scholar foi usado para localizar bibliografia de exemplos resolvidos/autoexplicação. Seus resultados bibliográficos não foram tratados como prova de eficácia desta plataforma; estudos listados apenas por metadados precisam de leitura integral antes de qualquer conclusão empírica. Resultados irrelevantes da busca foram descartados.

## Catálogo comentado e mapeamento

'''
for sid,title,url,use,status in SOURCES:
    rr=[r for r in rows if sid in r['fontes_recomendadas']]
    if sid=='F50':rr=[r for r in rows if r['bloco'] in ['Logic','Python','C']]
    if sid=='F44':rr=[r for r in rows if r['tipo']=='main' and int(r['id'][-3:])<=60]
    sources+=f'### {sid} — [{title}]({url})\n\nUso: {use}\n\nStatus: {status}.\n\nUnidades: '+(ids(rr) if rr else 'apoio transversal; selecionar aula pertinente na preparação do lote')+'.\n\n'
sources+='''## Como usar na Fase 16

Para cada aula, selecionar primeiro a especificação/documentação que explica o mecanismo; depois um projeto de laboratório que permita observá-lo; por fim uma referência defensiva com telemetria e correção. Não usar uma longa lista de links como substituto da explicação. Os links gerais precisam apontar para a seção concreta quando a aula for revisada. Registrar qual afirmação/experimento foi validado e qual versão foi testada.
'''
write('FASE_15_FONTES_RECOMENDADAS.md',sources)

evidence_dir=OUT/'evidencias';evidence_dir.mkdir(exist_ok=True)
for filename in ['lab47-resultados.json','microtestes.json']:(evidence_dir/filename).write_bytes((BASE/'verificacao'/filename).read_bytes())
manifest={'zip_sha256':meta['zip_sha256'],'arquivos':[{'id':r['id'],'arquivo':r['arquivo'],'sha256':r['sha256']} for r in rows],'json_v2':[x for r in rows for x in r.get('representações_adicionais',[])]}
(evidence_dir/'manifesto_fontes.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(evidence_dir/'notas_main.tsv').write_bytes((BASE/'notas_main.tsv').read_bytes())
(evidence_dir/'lacunas_parallel.txt').write_bytes((BASE/'lacunas_parallel.txt').read_bytes())
for filename in ['gerar_auditoria.py','fontes.py']:(evidence_dir/filename).write_bytes((BASE/filename).read_bytes())
write('FASE_15_LEIA-ME.md','''# Fase 15 — Conteúdo do pacote

Comece por FASE_15_AUDITORIA_CONTEUDO_MASTER.md. CSV/JSON contêm 543 unidades. JSON acrescenta 30 critérios por unidade, trechos/linhas/hashes, variantes V2 e clusters de duplicação. Os demais quatro relatórios detalham backlog, duplicações, lacunas e fontes.

A pasta evidencias contém manifesto dos arquivos-fonte, resultados de execução e notas/scripts de consolidação. Scripts são documentação do processo e dependem do ZIP original extraído no workspace; não reescrevem aulas. Notas são julgamento editorial, não certificação experimental de todos os labs. Nenhuma correção de conteúdo foi aplicada.
''')
assert len(rows)==543 and len({r['id'] for r in rows})==543
assert all(len(r['critérios'])==30 for r in rows)
assert sum(s['unidades'] for s in stats)==543
print(json.dumps({'counts':counts,'blocks':stats,'best20':[(r['id'],r['média']) for r in rank[:20]],'worst20':[(r['id'],r['média']) for r in worst[:20]],'clusters':len(clusters)},ensure_ascii=False,indent=2))
