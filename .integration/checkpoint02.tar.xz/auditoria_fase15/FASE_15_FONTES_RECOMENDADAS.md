# Fase 15 — Fontes recomendadas

Data de consulta: 2026-09-02. Fontes externas validam pontos e orientam enriquecimento; o corpus auditado continua sendo o ZIP real. “Consultada” indica acesso nesta auditoria; “recomendada para aprofundamento” não afirma leitura integral ou validação de todos os exemplos. Fixar versão, data e licença antes de incorporar material. Criar explicações e fixtures próprias; não copiar aulas, soluções nem material protegido.

Sider Scholar foi usado para localizar bibliografia de exemplos resolvidos/autoexplicação. Seus resultados bibliográficos não foram tratados como prova de eficácia desta plataforma; estudos listados apenas por metadados precisam de leitura integral antes de qualquer conclusão empírica. Resultados irrelevantes da busca foram descartados.

## Catálogo comentado e mapeamento

### F01 — [OWASP Cheat Sheet Series](https://cheatsheetseries.owasp.org/)

Uso: Catálogo de controles; selecionar a página correspondente ao mecanismo e criar exemplo próprio.

Status: catálogo consultado.

Unidades: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046, AULA-047, AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, LAB-12, LAB-18.

### F02 — [PortSwigger Web Security Academy](https://portswigger.net/web-security)

Uso: Mecanismos Web, laboratórios autorizados e casos negativos; não copiar soluções.

Status: consultada para Web Cache Deception.

Unidades: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046, AULA-047, AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, LAB-11.

### F03 — [RFC 9111 — HTTP Caching](https://www.rfc-editor.org/rfc/rfc9111.html)

Uso: Cache-Control, chave, reutilização e armazenamento de respostas.

Status: consultada.

Unidades: AULA-046, AULA-047.

### F04 — [OWASP CSRF Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html)

Uso: Existência e vínculo do token; critérios de rejeição.

Status: consultada.

Unidades: AULA-009.

### F05 — [OWASP SSRF Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html)

Uso: Validação de destino, resolução e redirecionamentos.

Status: consultada.

Unidades: AULA-015.

### F06 — [OWASP Password Storage](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html)

Uso: Argon2id, custo e limites do bcrypt.

Status: consultada.

Unidades: AULA-004.

### F07 — [RFC 9700 — OAuth 2.0 Security BCP](https://www.rfc-editor.org/rfc/rfc9700.html)

Uso: Fluxos atuais, redirect URI, PKCE e proteção de tokens.

Status: consultada.

Unidades: AULA-020, AULA-055.

### F08 — [MDN — Web documentation](https://developer.mozilla.org/en-US/docs/Web)

Uso: HTTP, DOM, SOP/CORS, fetch e JavaScript; montar exemplos completos.

Status: recomendada para aprofundamento.

Unidades: JS-01, JS-02, JS-03, JS-04, JS-05, JS-06, JS-07, JS-08, JS-09, JS-10, TS-01, TS-02, TS-03, TS-04, TS-05, WEB-01, WEB-02, WEB-03, WEB-04, WEB-05, WEB-06, WEB-07, WEB-08, WEB-09, WEB-10, WEB-11, WEB-12, WEB-13, WEB-14, WEB-15, WEB-16, WEB-17, WEB-18, WEB-19, WEB-20, WEB-21, WEB-22, WEB-23, WEB-24, WEB-25, WEB-26, WEB-27, WEB-28, WEB-29, WEB-30, WEB-31, WEB-32, WEB-33, WEB-34, WEB-35, WEB-36, WEB-37, WEB-38, WEB-39, WEB-40, LAB-13, LAB-14, LAB-15.

### F09 — [Python — tutorial oficial](https://docs.python.org/3/tutorial/)

Uso: Fundamentos, arquivos, exceções, módulos e código executável.

Status: recomendada para aprofundamento.

Unidades: LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20.

### F10 — [TypeScript — Handbook](https://www.typescriptlang.org/docs/handbook/intro.html)

Uso: Tipos, narrowing, generics e limites da tipagem estática.

Status: recomendada para aprofundamento.

Unidades: TS-01, TS-02, TS-03, TS-04, TS-05.

### F11 — [GNU Bash Reference Manual](https://www.gnu.org/software/bash/manual/bash.html)

Uso: Expansão, quoting, redirecionamento, funções e status.

Status: recomendada para aprofundamento.

Unidades: BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30.

### F12 — [Microsoft Learn — PowerShell](https://learn.microsoft.com/en-us/powershell/)

Uso: Objetos, cmdlets, erros, automação e documentação de versão.

Status: recomendada para aprofundamento.

Unidades: PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-26, WIN-29.

### F13 — [Linux man-pages](https://www.kernel.org/doc/man-pages/)

Uso: Processos, memória, sockets, permissões e interfaces do kernel.

Status: recomendada para aprofundamento.

Unidades: AULA-022, AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-079, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20, BASH-01, BASH-02, BASH-03, BASH-04, BASH-05, BASH-06, BASH-07, BASH-08, BASH-09, BASH-10, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-37, NET-38, NET-39, NET-40, LNX-01, LNX-02, LNX-03, LNX-04, LNX-05, LNX-06, LNX-07, LNX-08, LNX-09, LNX-10, LNX-11, LNX-12, LNX-13, LNX-14, LNX-15, LNX-16, LNX-17, LNX-18, LNX-19, LNX-20, LNX-21, LNX-22, LNX-23, LNX-24, LNX-25, LNX-26, LNX-27, LNX-28, LNX-29, LNX-30, LAB-07, LAB-08.

### F14 — [Microsoft Learn — Windows security](https://learn.microsoft.com/en-us/windows/security/)

Uso: Tokens, auditoria, hardening e administração Windows.

Status: recomendada para aprofundamento.

Unidades: AULA-061, AULA-062, AULA-063, AULA-064, AULA-065, AULA-066, AULA-067, AULA-068, AULA-069, AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, PS-01, PS-02, PS-03, PS-04, PS-05, PS-06, PS-07, PS-08, PS-09, PS-10, WIN-01, WIN-02, WIN-03, WIN-04, WIN-05, WIN-06, WIN-07, WIN-08, WIN-09, WIN-10, WIN-11, WIN-12, WIN-13, WIN-14, WIN-15, WIN-16, WIN-17, WIN-18, WIN-19, WIN-20, WIN-21, WIN-22, WIN-23, WIN-24, WIN-25, WIN-26, WIN-27, WIN-28, WIN-29, WIN-30, LAB-04, LAB-09, LAB-22, LAB-23, LAB-24.

### F15 — [Microsoft Learn — Active Directory Domain Services](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/)

Uso: Domínio, GPO, identidade e administração de laboratório.

Status: recomendada para aprofundamento.

Unidades: AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078.

### F16 — [Wireshark User’s Guide](https://www.wireshark.org/docs/wsug_html_chunked/)

Uso: Captura, filtros e reconstrução; criar PCAP sintético próprio.

Status: recomendada para aprofundamento.

Unidades: AULA-021, AULA-024, AULA-081, AULA-146, NET-01, NET-02, NET-03, NET-04, NET-05, NET-06, NET-07, NET-08, NET-09, NET-10, NET-11, NET-12, NET-13, NET-14, NET-15, NET-16, NET-17, NET-18, NET-19, NET-20, NET-21, NET-22, NET-23, NET-24, NET-25, NET-26, NET-27, NET-28, NET-29, NET-30, NET-31, NET-32, NET-33, NET-34, NET-35, NET-36, NET-37, NET-38, NET-39, NET-40, LAB-17, LAB-30.

### F17 — [RFC 8446 — TLS 1.3](https://www.rfc-editor.org/rfc/rfc8446.html)

Uso: Handshake e limites da visibilidade de certificados após ServerHello.

Status: consultada.

Unidades: NET-24, NET-25, NET-36.

### F18 — [Microsoft Sysmon](https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon)

Uso: Configuração e eventos, campos e limites de coleta.

Status: consultada.

Unidades: AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100, AULA-138, WIN-15, WIN-23, WIN-27, WIN-28, WIN-30, LAB-21, LAB-22, LAB-30.

### F19 — [SigmaHQ — regras e especificação](https://github.com/SigmaHQ/sigma)

Uso: Referência de regras, logsource, campos e falsos positivos; fixar revisão.

Status: recomendada para aprofundamento.

Unidades: AULA-086, AULA-100, AULA-152, AULA-215, LAB-29.

### F20 — [YARA — documentação](https://yara.readthedocs.io/en/stable/)

Uso: Sintaxe, condições e execução contra corpus educacional.

Status: recomendada para aprofundamento.

Unidades: AULA-087, AULA-151, AULA-215, LAB-29.

### F21 — [Suricata — documentação](https://docs.suricata.io/en/latest/)

Uso: Sintaxe de regra, teste de configuração, PCAP e EVE JSON; usar versão fixada.

Status: recomendada para aprofundamento.

Unidades: AULA-082, LAB-27.

### F22 — [MITRE ATT&CK](https://attack.mitre.org/)

Uso: Mapear comportamentos/IDs com justificativa e versão.

Status: consultada.

Unidades: AULA-070, AULA-071, AULA-072, AULA-073, AULA-074, AULA-075, AULA-076, AULA-077, AULA-078, AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100, AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, AULA-209, AULA-210, AULA-211, AULA-212, AULA-213, AULA-214, AULA-215, AULA-216, AULA-217, AULA-218, LAB-28.

### F23 — [NIST SP 800-61r3](https://csrc.nist.gov/pubs/sp/800/61/r3/final)

Uso: Resposta a incidentes integrada à gestão de risco.

Status: consultada.

Unidades: AULA-079, AULA-080, AULA-081, AULA-082, AULA-083, AULA-084, AULA-085, AULA-086, AULA-087, AULA-088, AULA-089, AULA-090, AULA-091, AULA-092, AULA-093, AULA-094, AULA-095, AULA-096, AULA-097, AULA-098, AULA-099, AULA-100, AULA-209, AULA-210, AULA-211, AULA-212, AULA-213, AULA-214, AULA-215, AULA-216, AULA-217, AULA-218, LAB-01, LAB-02, LAB-28, LAB-30.

### F24 — [Ghidra — repositório oficial](https://github.com/NationalSecurityAgency/ghidra)

Uso: Importação, análise e exemplos de extensibilidade com binários próprios.

Status: recomendada para aprofundamento.

Unidades: AULA-028, AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, LAB-19.

### F25 — [x64dbg — documentação oficial](https://help.x64dbg.com/en/latest/)

Uso: Breakpoints, stepping e leitura do estado de processo próprio.

Status: recomendada para aprofundamento.

Unidades: AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, LAB-20.

### F26 — [Clang AddressSanitizer](https://clang.llvm.org/docs/AddressSanitizer.html)

Uso: Compilação/link, diagnósticos, limites e configuração.

Status: consultada.

Unidades: AULA-026, AULA-101, AULA-102, AULA-103, AULA-104, AULA-105, AULA-106, AULA-107, AULA-108, AULA-109, AULA-110, AULA-111, AULA-112, AULA-113, AULA-114, AULA-115, AULA-116, AULA-117, AULA-118, AULA-119, AULA-120, AULA-121, AULA-122, AULA-123, AULA-124, AULA-125, AULA-126, AULA-127, AULA-128, AULA-129, AULA-130, AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20.

### F27 — [LLVM libFuzzer](https://llvm.org/docs/LibFuzzer.html)

Uso: Harness, corpus, cobertura e minimização; confirmar versão/toolchain antes de adotar.

Status: recomendada para aprofundamento.

Unidades: AULA-161, AULA-162, AULA-163, AULA-164, AULA-165, AULA-166, AULA-167, AULA-168, AULA-169, AULA-170, AULA-171, AULA-172, AULA-173, AULA-174, AULA-175, AULA-176, AULA-177, AULA-178, AULA-179, AULA-180.

### F28 — [Volatility 3 — repositório oficial](https://github.com/volatilityfoundation/volatility3)

Uso: Símbolos, plugins e requisitos para dumps educacionais.

Status: recomendada para aprofundamento.

Unidades: AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, LAB-26.

### F29 — [REMnux — documentação](https://docs.remnux.org/)

Uso: Preparação de ambiente e fluxo de análise inerte.

Status: recomendada para aprofundamento.

Unidades: AULA-131, AULA-132, AULA-133, AULA-134, AULA-135, AULA-136, AULA-137, AULA-138, AULA-139, AULA-140, AULA-141, AULA-142, AULA-143, AULA-144, AULA-145, AULA-146, AULA-147, AULA-148, AULA-149, AULA-150, AULA-151, AULA-152, AULA-153, AULA-154, AULA-155, AULA-156, AULA-157, AULA-158, AULA-159, AULA-160, LAB-03, LAB-10, LAB-25.

### F30 — [Atomic Red Team](https://github.com/redcanaryco/atomic-red-team)

Uso: Selecionar testes benignos, revisar pré-condições e cleanup; fixar IDs e versão.

Status: recomendada para aprofundamento.

Unidades: AULA-181, AULA-182, AULA-183, AULA-184, AULA-185, AULA-186, AULA-187, AULA-188, AULA-189, AULA-190, LAB-01.

### F31 — [Docker — documentação](https://docs.docker.com/)

Uso: Imagens, volumes, rede, secrets e permissões com exemplos locais.

Status: recomendada para aprofundamento.

Unidades: AULA-191, LAB-05, LAB-06, CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10.

### F32 — [Kubernetes — Pod Security Standards](https://kubernetes.io/docs/concepts/security/pod-security-standards/)

Uso: Restrições por nível de segurança e localização correta dos campos.

Status: consultada.

Unidades: AULA-192, K8S-01, K8S-02, K8S-03, K8S-04, K8S-05, K8S-06, K8S-07, K8S-08, K8S-09, K8S-10.

### F33 — [AWS IAM — Policy evaluation logic](https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_policies_evaluation-logic.html)

Uso: Exemplo concreto de avaliação allow/deny/condição; não usar action pseudo-AWS como policy real.

Status: recomendada para aprofundamento.

Unidades: AULA-193, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10.

### F34 — [PostgreSQL — Row Security Policies](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)

Uso: Ativação de RLS, policies, WITH CHECK e papéis que podem bypassar.

Status: consultada.

Unidades: AULA-198.

### F35 — [Supabase — Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security)

Uso: Integração de auth.uid, políticas e isolamento multiusuário.

Status: recomendada para aprofundamento.

Unidades: AULA-198.

### F36 — [Firebase — Security Rules](https://firebase.google.com/docs/rules)

Uso: Modelo de regras e testes com emulador separados de PostgreSQL RLS.

Status: recomendada para aprofundamento.

Unidades: AULA-198.

### F37 — [Electron — Security](https://www.electronjs.org/docs/latest/tutorial/security)

Uso: Isolamento, IPC e validação da identidade do remetente.

Status: consultada.

Unidades: AULA-200.

### F38 — [OWASP GenAI LLM Top 10 2026](https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/)

Uso: Fixar edição e mapear categorias a controles e testes próprios.

Status: página oficial consultada; edição 2026 existe.

Unidades: AULA-201, AULA-202, AULA-203, AULA-204, AULA-205, AULA-206, AULA-207, AULA-208.

### F39 — [OWASP Top 10 for Agentic Applications 2026](https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/)

Uso: Riscos específicos de identidade, ferramentas e cadeias de decisão de agentes.

Status: consultada.

Unidades: AULA-201, AULA-202, AULA-203, AULA-204, AULA-205, AULA-206, AULA-207, AULA-208.

### F40 — [MITRE ATLAS](https://atlas.mitre.org/)

Uso: Modelo de ameaças AI; selecionar técnicas pertinentes e documentar evidência.

Status: página acessada; conteúdo dinâmico não extraído integralmente.

Unidades: AULA-201, AULA-202, AULA-203, AULA-204, AULA-205, AULA-206, AULA-207, AULA-208.

### F41 — [Git — documentação oficial](https://git-scm.com/doc)

Uso: Histórico, index, branches, merge/rebase e exemplos locais reproduzíveis.

Status: recomendada para aprofundamento.

Unidades: ENG-01, ENG-02, ENG-03, ENG-04, ENG-05, ENG-06, ENG-07, ENG-08, ENG-09, ENG-10, ENG-11, ENG-12, ENG-13, ENG-14, ENG-15, ENG-16, ENG-17, ENG-18, ENG-19, ENG-20.

### F42 — [GitHub Actions — security hardening](https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions)

Uso: Permissões de workflow, dependências e proteção de credenciais.

Status: recomendada para aprofundamento.

Unidades: AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30.

### F43 — [SLSA — especificação](https://slsa.dev/spec/)

Uso: Provenance e confiança no build; fixar versão da especificação.

Status: recomendada para aprofundamento.

Unidades: AULA-191, AULA-192, AULA-193, AULA-194, AULA-195, AULA-196, AULA-197, AULA-198, AULA-199, AULA-200, ENG-21, ENG-22, ENG-23, ENG-24, ENG-25, ENG-26, ENG-27, ENG-28, ENG-29, ENG-30, CLD-01, CLD-02, CLD-03, CLD-04, CLD-05, CLD-06, CLD-07, CLD-08, CLD-09, CLD-10.

### F44 — [OWASP WebGoat](https://github.com/WebGoat/WebGoat)

Uso: Aplicação intencionalmente vulnerável para prática local com objetivos delimitados.

Status: repositório recomendado.

Unidades: AULA-001, AULA-002, AULA-003, AULA-004, AULA-005, AULA-006, AULA-007, AULA-008, AULA-009, AULA-010, AULA-011, AULA-012, AULA-013, AULA-014, AULA-015, AULA-016, AULA-017, AULA-018, AULA-019, AULA-020, AULA-021, AULA-022, AULA-023, AULA-024, AULA-025, AULA-026, AULA-027, AULA-028, AULA-029, AULA-030, AULA-031, AULA-032, AULA-033, AULA-034, AULA-035, AULA-036, AULA-037, AULA-038, AULA-039, AULA-040, AULA-041, AULA-042, AULA-043, AULA-044, AULA-045, AULA-046, AULA-047, AULA-048, AULA-049, AULA-050, AULA-051, AULA-052, AULA-053, AULA-054, AULA-055, AULA-056, AULA-057, AULA-058, AULA-059, AULA-060.

### F45 — [OWASP Juice Shop](https://github.com/juice-shop/juice-shop)

Uso: Cenários web integrados; usar instalação local e tarefas alinhadas à aula.

Status: repositório recomendado.

Unidades: AULA-040, AULA-209, AULA-210, AULA-211, AULA-212, AULA-213, AULA-214, AULA-215, AULA-216, AULA-217, AULA-218.

### F46 — [OWASP crAPI](https://github.com/OWASP/crAPI)

Uso: BOLA, BFLA e cenários de API em laboratório autorizado.

Status: repositório recomendado.

Unidades: AULA-056.

### F47 — [Alpine — release branches](https://alpinelinux.org/releases/)

Uso: Conferir suporte da imagem base; branch 3.20 encerrou suporte em 2026-04-01.

Status: consultada em 2026-09-02.

Unidades: CTR-01, CTR-02, CTR-03, CTR-04, CTR-05, CTR-06, CTR-07, CTR-08, CTR-09, CTR-10, K8S-10.

### F48 — [Node.js — EOL](https://nodejs.org/en/about/eol)

Uso: Atualizar requisito Node 18+ e fixar versão mantida para laboratório.

Status: consultada em 2026-09-02.

Unidades: AULA-047, JS-08, JS-09, JS-10.

### F49 — [Alhassan — Self-Explanation with Worked Examples](http://iiste.org/Journals/index.php/JEP/article/view/35501)

Uso: Leitura pedagógica para desenhar autoexplicação e exemplos resolvidos em programação.

Status: metadados localizados via Sider Scholar, W2594233825; texto integral não validado.

Unidades: LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20.

### F50 — [Renkl — Learning from Worked-Out Examples](https://doi.org/10.1207/s15516709cog2101_1)

Uso: Referência para estudar diferenças na aprendizagem com exemplos resolvidos.

Status: metadados localizados via Sider Scholar; não usada para alegar tamanho de efeito.

Unidades: LOG-01, LOG-02, LOG-03, LOG-04, LOG-05, LOG-06, LOG-07, LOG-08, LOG-09, LOG-10, LOG-11, LOG-12, LOG-13, LOG-14, LOG-15, LOG-16, LOG-17, LOG-18, LOG-19, LOG-20, PY-01, PY-02, PY-03, PY-04, PY-05, PY-06, PY-07, PY-08, PY-09, PY-10, PY-11, PY-12, PY-13, PY-14, PY-15, PY-16, PY-17, PY-18, PY-19, PY-20, C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, C-15, C-16, C-17, C-18, C-19, C-20.

### F51 — [Nmap — Reference Guide](https://nmap.org/book/man.html)

Uso: Interpretação dos estados e fingerprint, com limites e alvo de laboratório.

Status: recomendada para aprofundamento.

Unidades: AULA-023, AULA-066, LAB-16, LAB-18.

### F52 — [Microsoft — PE format](https://learn.microsoft.com/en-us/windows/win32/debug/pe-format)

Uso: Headers/seções/imports e interpretação de endereços de PE.

Status: recomendada para aprofundamento.

Unidades: AULA-108, WIN-24, WIN-25.

### F53 — [Microsoft — x64 calling convention](https://learn.microsoft.com/en-us/cpp/build/x64-calling-convention)

Uso: ABI Windows x64, argumentos, stack e alinhamento.

Status: recomendada para aprofundamento.

Unidades: AULA-113.

### F54 — [OWASP File Upload](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html)

Uso: Validação de conteúdo, nome, storage e entrega; completar os labs de upload.

Status: recomendada para aprofundamento.

Unidades: AULA-013, AULA-053.

## Como usar na Fase 16

Para cada aula, selecionar primeiro a especificação/documentação que explica o mecanismo; depois um projeto de laboratório que permita observá-lo; por fim uma referência defensiva com telemetria e correção. Não usar uma longa lista de links como substituto da explicação. Os links gerais precisam apontar para a seção concreta quando a aula for revisada. Registrar qual afirmação/experimento foi validado e qual versão foi testada.

