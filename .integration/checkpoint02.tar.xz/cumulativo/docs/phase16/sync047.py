from pathlib import Path
import json
r=Path(__file__).resolve().parents[2]
lab=r/'public/course-labs/aula-047';p=r/'public/course-library/main/047.md'
code=(lab/'cache-policy.mjs').read_text()
s=p.read_text().replace('**Status:** padrão ouro v1','**Status:** revisada na Fase 16; evidência de execução no laboratório').replace('Node.js 18+','Node.js 24').replace('Os arquivos estão no diretório `lab/` desta aula.','Os arquivos estão em `public/course-labs/aula-047/` na raiz do pacote. `X-Lab-User` seleciona identidades fictícias; não é autenticação de produção.').replace('```bash\nnpm install\n```','```bash\ncd public/course-labs/aula-047\nnpm ci\n```')
a=s.index('## 14. Política defensiva melhor');b=s.index('# 16. Laboratório',a)
s=s[:a]+'''## 14. Política defensiva: decidir antes de ler e antes de guardar

O contrato deste cache é restrito: apenas GET anônimo em `/assets/`, resposta 200 com `public` e `max-age` explícitos, sem `Set-Cookie`, `Vary` ou diretivas privadas. Requisições com Cookie, Authorization ou X-Lab-User fazem BYPASS **antes de consultar uma entrada existente**. Guardar corretamente e selecionar incorretamente ainda pode misturar contextos.

Não basta testar o armazenamento com cache vazio. Primeiro aqueça `/assets/app.css` como anônimo; depois envie a mesma URL com identidade. A resposta deve fazer BYPASS, apesar de já existir um objeto cacheado. A regra de namespace sozinha não demonstra esse comportamento.

## 15. Código anotado e tempo de vida

O arquivo executado é `cache-policy.mjs`:

```js
'''+code+'''```

`isAnonymousAsset` aplica o contrato da requisição. `storageTtl` examina a resposta e retorna milissegundos de armazenamento, ou zero para recusa. A classe recebe um relógio para que o teste avance no tempo sem esperar uma hora; entradas expiradas são removidas no acesso. `Age` relata segundos desde o armazenamento nesta simulação; o lab limita a 100 entradas e a TTL de uma hora.

Esta é uma política deliberadamente menor que um cache HTTP completo. Não implementa revalidação, `s-maxage`, armazenamento persistente, variantes Vary ou todo o cálculo de idade da RFC. `no-cache` é recusado por falta de revalidação, embora não signifique universalmente “proibido armazenar”. Campos/diretivas desconhecidos não autorizam armazenamento por si. Não publique estes proxies didáticos como CDN.

### Exercício parcialmente resolvido

Uma implementação consulta `cache.get(key)` e só depois examina Cookie. Mova a decisão para antes da leitura: `const saved = isAnonymousAsset(req) ? cache.get(key) : null;`. Explique por que isso muda o resultado quando o cache já está aquecido. Gabarito: uma requisição autenticada deixa de poder reutilizar um objeto antes que sua elegibilidade seja conhecida.

### Prática independente

Classifique `/account`, `/api/me`, `/assets/app.css`, `/public/avatar/42` e `/reports/export.csv`. Neste lab, apenas `/assets/app.css` sem identidade pode entrar, condicionado à resposta. As demais rotas não estão no namespace autorizado. Em um produto real, avatar/export exigem descobrir se o recurso é público ou personalizado antes de ampliar a política; o nome não basta.

---

'''+s[b:]
# Keep existing guided experiment; add concrete warm-cache and automatic checks.
anchor='# 27. Como detectar em sistemas próprios'
extra='''## Teste de contexto com cache aquecido e TTL

Depois do MISS/HIT público, execute:

```sh
curl -i -H 'Cookie: session=ficticia' http://127.0.0.1:4001/assets/app.css
curl -i -H 'Authorization: Bearer ficticio' http://127.0.0.1:4001/assets/app.css
npm test
```

As duas requisições fazem BYPASS. Cookie e Authorization participam da recusa de cache; somente X-Lab-User simula a identidade no origin. O teste automático inicia três servidores em portas livres, exige Alice/MISS → Bob/HIT com corpo de Alice no antigo, isolamento no corrigido, público MISS/HIT, três headers de contexto com BYPASS e 404 sem armazenamento. Outro teste avança o relógio: Age=1 após um segundo e ausência da entrada na expiração; verifica `private`, `Set-Cookie` e `Vary`.

Limites: não testa CDN comercial, cache do navegador ou todas as regras HTTP. Ao terminar, Ctrl+C nos servidores manuais limpa seus Maps em memória; não existe diretório de cache a apagar.

'''
s=s.replace(anchor,extra+anchor)
s+='\n\n## Referências específicas\n\n- [PortSwigger — Web Cache Deception](https://portswigger.net/web-security/web-cache-deception): divergências de interpretação e exercícios complementares.\n- [RFC 9111 — HTTP Caching](https://www.rfc-editor.org/rfc/rfc9111.html): armazenamento, idade, freshness e revalidação; o laboratório implementa apenas o subconjunto declarado.\n'
p.write_text(s)
j=r/'src/content/main/047/lesson.json';d=json.loads(j.read_text())
def fix(v):
 if isinstance(v,str):return v.replace("Cookie: user=alice","X-Lab-User: alice").replace("Cookie: user=bob","X-Lab-User: bob")
 if isinstance(v,list):return [fix(x) for x in v]
 if isinstance(v,dict):return {k:fix(x) for k,x in v.items()}
 return v
d=fix(d)
d['codeExamples']=[{'id':'wcd-code-policy','title':'Política executada: requisição, resposta e TTL','language':'js','code':code,'explanation':'O proxy consulta isAnonymousAsset antes de ler uma entrada existente. storageTtl valida a resposta; TimedCache expira objetos com relógio injetável. Política restrita ao lab: não implementa toda a RFC 9111.','annotations':[{'lines':'2-6','note':'Contexto autenticado e caminhos fora de assets são recusados antes da consulta ao cache.'},{'lines':'8-14','note':'Status, diretivas, Set-Cookie e Vary decidem se e por quanto tempo guardar.'},{'lines':'16-29','note':'Relógio injetável, expiração, idade e limite de entradas.'}]}]
d['completionExercises']=[{'id':'wcd-completion-01','title':'Bloquear reutilização antes da consulta','prompt':'Uma entrada de asset foi aquecida por acesso anônimo. Complete A para que uma requisição com Cookie não receba essa entrada.','starterCode':"const key = `${req.method}:${req.originalUrl}`;\nconst saved = /* A */ ? cache.get(key) : null;",'expectedConcepts':['elegibilidade da requisição antes de cache.get','Cookie/Authorization/X-Lab-User fazem bypass','armazenamento e seleção são decisões distintas'],'solution':'A = isAnonymousAsset(req). Validar apenas quando cache.put é chamado não protege a seleção de objetos já armazenados.'}]
l=d['lab'];l['setup']=['Use Node.js 24 e execute, da raiz do pacote: cd public/course-labs/aula-047 && npm ci.','Terminal A: npm run origin (127.0.0.1:3000). Terminal B: npm run vulnerable (127.0.0.1:4000).','X-Lab-User é identidade fictícia escolhida pelo cliente, somente para o experimento; não é autenticação real.']
l['happyPath']=["curl -i -H 'X-Lab-User: alice' http://127.0.0.1:3000/account/profile.css", "curl -i -H 'X-Lab-User: bob' http://127.0.0.1:3000/account/profile.css",'O origin retorna a identidade correspondente e Cache-Control: private, no-store em ambos.']
l['steps'][2].update(command='npm run fixed',instruction='Em outro terminal no diretório do lab, inicie o proxy corrigido em 127.0.0.1:4001. Ele recusa contexto antes da consulta e respeita a política da resposta.')
l['steps'][3].update(command="curl -i -H 'X-Lab-User: alice' http://127.0.0.1:4001/account/profile.css\ncurl -i -H 'X-Lab-User: bob' http://127.0.0.1:4001/account/profile.css")
l['steps']+= [{'id':'lab-5','instruction':'Aqueça o asset público e confirme MISS/HIT.','command':'curl -i http://127.0.0.1:4001/assets/app.css\ncurl -i http://127.0.0.1:4001/assets/app.css','expected':'Primeira requisição MISS; segunda HIT com Age.','checkpoint':'A correção preserva o contrato público.'},{'id':'lab-6','instruction':'Mude o contexto com o cache já aquecido.','command':"curl -i -H 'Cookie: session=ficticia' http://127.0.0.1:4001/assets/app.css",'expected':'BYPASS apesar da entrada pública já presente.','checkpoint':'Elegibilidade foi conferida antes da leitura do cache.'},{'id':'lab-7','instruction':'Execute regressões HTTP e relógio determinístico.','command':'npm test','expected':'2 testes aprovados: isolamento, cache aquecido, TTL/Age, diretivas e headers de recusa.','checkpoint':'Expiração elimina a entrada; 404 e respostas privadas não são armazenadas.'}]
l['cleanup']=['Ctrl+C nos servidores iniciados manualmente. Os caches ficam somente em memória e desaparecem ao parar os processos.','O teste automático fecha seus próprios servidores em finally; não precisa apagar pastas do projeto.']
l['resources']=[{'label':name,'href':'/course-labs/aula-047/'+name} for name in ['README.md','origin.mjs','proxy-vulneravel.mjs','proxy-corrigido.mjs','cache-policy.mjs','lab.test.mjs','package.json','package-lock.json']]
l['troubleshooting']+=[{'symptom':'O corpo é anonymous apesar de enviar Cookie: user=alice.','likelyCause':'O origin deste exercício reconhece X-Lab-User, não Cookie como identidade.','action':'Use X-Lab-User: alice nos comandos de Alice; Cookie serve como sinal de bypass no proxy corrigido.'}]
d['remediation']['verification']+=['Aqueça asset anônimo; repita com Cookie, Authorization e X-Lab-User, exigindo BYPASS.','Avance o relógio do teste até a expiração e confira remoção da entrada.']
d['review']['flashcards']+=[{'front':'Por que verificar identidade antes de cache.get?','back':'Um objeto já aquecido pode ser reutilizado sem chegar à regra de armazenamento; a requisição precisa ser elegível antes da consulta.','concept':'warm-cache-bypass'},{'front':'no-cache proíbe guardar em qualquer cache?','back':'Não; exige validação antes de reutilizar. Este lab faz BYPASS porque não implementa revalidação.','concept':'revalidation'}]
j.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
