from pathlib import Path
import subprocess,json
r=Path(__file__).resolve().parents[2]
commands=[('web-p0',['node','--test','web.test.mjs'],r/'public/course-labs/phase16-web-p0'),('cache-047',['node','--test','lab.test.mjs'],r/'public/course-labs/aula-047'),('risk-stride',['node','read-models.mjs'],r/'public/course-labs/phase16-web-p0')]
result=[]
for label,cmd,cwd in commands:
 p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=60)
 result.append({'grupo':label,'command':cmd,'cwd':str(cwd.relative_to(r)),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 print(label,p.returncode)
(r/'docs/phase16/web-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
assert all(x['exit_code']==0 for x in result)
