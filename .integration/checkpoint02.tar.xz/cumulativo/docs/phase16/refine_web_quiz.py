from pathlib import Path
r=Path(__file__).resolve().parents[2]/'public/course-library/main'
changes={
'004':{
'A) Bcrypt é reversível. B) Cada cadastro usa salt distinto. C) O banco mudou a senha. D) A comparação sempre deve falhar.':'A) O mesmo hash sempre muda quando é lido do banco. B) Cada cadastro usa salt distinto. C) O salt é um segredo exclusivo fornecido pelo usuário. D) A diferença prova que uma das senhas foi digitada incorretamente.',
'A) Eliminar a necessidade de salt. B) Reduzir sempre a memória a zero. C) Invalidar matematicamente todos os hashes antigos. D) Aumentar latência e consumo de CPU por tentativa.':'A) Duplicar o tamanho do verificador salvo. B) Exigir trocar os salts de todos os registros antes do próximo login. C) Invalidar todos os hashes antigos por usarem outro custo. D) Aumentar latência e consumo de CPU por tentativa.'},
'009':{
'A) Gerar uma URL maior. B) Trocar POST por GET. C) Exigir presença e formato antes da comparação. D) Guardar o token no log.':'A) Comparar os valores depois de alterar o e-mail. B) Converter ambos os ausentes para string vazia e compará-los. C) Exigir presença e formato antes da comparação. D) Aceitar qualquer token que tenha sido emitido pelo servidor.'},
'015':{
'A) URLs não possuem origem. B) O parser sempre falha com 302. C) O cliente pode iniciar outra conexão sem repetir a política. D) O navegador precisa ler o corpo antes.':'A) A allowlist avalia somente a extensão do corpo final. B) Um 302 garante automaticamente que a nova origem é equivalente à inicial. C) O cliente pode iniciar outra conexão sem repetir a política. D) Verificar apenas o status 200 final também comprova autorização de todos os saltos.',
'A) Marcador interno e contador do serviço interno incrementado. B) Só um 500. C) Só latência maior. D) A extensão `.css` na URL.':'A) Marcador interno e contador do serviço interno incrementado. B) Só um 500 após a requisição. C) Só latência maior que a do catálogo. D) A URL inicial ter passado na allowlist.'},
'020':{
'A) Nonce do ID Token. B) PKCE. C) Cache-Control. D) Decodificação Base64URL.':'A) A comparação de nonce no ID Token. B) PKCE. C) A validade temporal do código, mesmo sem vínculo ao cliente. D) A verificação de state feita por outro cliente.',
'A) State precisa ser uma senha humana. B) Igualdade de ausências não prova uma transação iniciada. C) State só existe após emitir access token. D) State substitui client_id.':'A) A resposta deve ser aceita se a assinatura do código for legível. B) Igualdade de ausências não prova uma transação iniciada. C) A presença de um código basta para reconstruir qualquer transação ausente. D) Verifier e state sempre devem ser a mesma string.'}}
for name,replacements in changes.items():
 p=r/f'{name}.md';s=p.read_text()
 for a,b in replacements.items():
  assert a in s,(name,a);s=s.replace(a,b)
 p.write_text(s)
p=r/'052.md';s=p.read_text().replace('quatro rejeições e motivo FORA_DA_RAIZ para o link.','quatro rejeições e os quatro motivos exatos.').replace('a inspeção do passo anterior verifica os demais motivos individualmente.','a inspeção do passo anterior relaciona cada motivo à condição do código.');p.write_text(s)
