"""Arquivo histórico de autoria do checkpoint01; NÃO regenerar aulas revisadas."""
raise SystemExit("Autorador arquivado: regeneração sobrescreveria revisões manuais. Consulte foundations-status.json.")
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
LAB=ROOT/'public/course-labs/phase16-foundations'
def write(id,problem,mechanism,example,code,exercise,answer,robust,quiz,cards,lab=None,commands=None):
 p=ROOT/'public/course-library/parallel'/f'{id}.md'
 head=p.read_text(encoding='utf-8').split('---')[0].rstrip()
 text=head+'\n\n---\n\n## Problema e objetivo\n\n'+problem+'\n\n## Mecanismo e exemplo resolvido\n\n'+mechanism+'\n\n'+example+'\n\n'
 if code:text+='```'+code[0]+'\n'+code[1].strip()+'\n```\n\n'
 if lab:text+='## Laboratório reproduzível\n\nArquivos: '+', '.join(f'[{f}](/course-labs/phase16-foundations/{f})' for f in lab)+'. Baixe os arquivos para uma pasta própria e mantenha os nomes.\n\n'
 if commands:text+='```sh\n'+commands.strip()+'\n```\n\n'
 text+='## Prática e autoexplicação\n\n'+exercise+'\n\n## Solução comentada e checkpoints\n\n'+answer+'\n\n## Robustez, reteste e diagnóstico\n\n'+robust+'\n\n## Quiz\n\n'
 for i,(q,opts,key,why) in enumerate(quiz,1):
  text+=f'{i}. **{q}**\n'+''.join(f'   - {"ABCD"[j]}) {o}\n' for j,o in enumerate(opts))+'\n'
 text+='**Gabarito comentado:** '+ ' '.join(f'{i}: {q[2]} — {q[3]}' for i,q in enumerate(quiz,1))+'\n\n## Flashcards\n\n'+''.join(f'- **{a}** → {b}\n' for a,b in cards)
 p.write_text(text,encoding='utf-8')
 if not lab:
  (LAB/f'{id}-mesa.md').write_text('# Caderno de trabalho '+id+'\n\n'+problem+'\n\n'+example+'\n\n'+(code[1] if code else '')+'\n\n'+exercise+'\n\n## Solução para conferir depois\n\n'+answer,encoding='utf-8')
  t=p.read_text();t=t.replace('## Prática e autoexplicação',f'**Exercício de mesa para baixar:** [{id}-mesa.md](/course-labs/phase16-foundations/{id}-mesa.md). Não requer runtime.\n\n## Prática e autoexplicação');p.write_text(t)

write('LOG-01','Uma oficina possui 7 peças e recebe um pedido de 4. Precisamos aceitar somente pedidos inteiros positivos que caibam no estoque e informar saldo e decisão. Ao final, você deve decompor essa regra em entradas, etapas e invariantes, sem depender de uma linguagem.',
'As entradas são estoque e pedido; a saída é `(decisão, saldo)`. Primeiro valide domínio, depois compare disponibilidade, só então subtraia. A ordem impede que um pedido negativo aumente o estoque. Invariante: para entradas válidas, `0 ≤ saldo ≤ estoque`; uma recusa preserva o estoque. A comparação não modifica dados; a atribuição modifica o saldo.',
'| Estoque | Pedido | Domínio válido? | Cabe? | Decisão | Saldo |\n|---|---|---|---|---|---|\n| 7 | 4 | sim | sim | aceitar | 3 |\n| 7 | 8 | sim | não | recusar | 7 |\n| 7 | 0 | não | não avaliar | inválido | 7 |\n| 0 | 1 | sim | não | recusar | 0 |',
('text','receber estoque, pedido\nse estoque não é inteiro ou estoque < 0: devolver erro de estoque\nse pedido não é inteiro ou pedido <= 0: devolver inválido, estoque\nse pedido > estoque: devolver recusar, estoque\nsaldo ← estoque - pedido  // única etapa que altera a quantidade\ndevolver aceitar, saldo'),
'Parcial: complete `(7,7) → (____,____)` e identifique a etapa responsável. Independente: resolva `(3,-2)`, `(3,2.5)` e `(3,1)`, registrando cada comparação. Autoexplicação: por que subtrair antes de validar o pedido quebra a regra? Qual entrada prova isso?',
'Pedido 7 é aceito e saldo é 0. Os pedidos -2 e 2,5 são inválidos; saldo permanece 3. Pedido 1 produz saldo 2. O contraexemplo -2 produziria 5 se subtraído prematuramente. Checkpoint: cada execução retorna uma decisão e termina; “inválido” e “sem estoque” são motivos diferentes.',
'Se o saldo for negativo, revise a comparação de disponibilidade; se aumentar, revise o domínio do pedido. Reteste 0, 1, estoque e estoque+1 após corrigir. A lógica não trata concorrência: duas reservas simultâneas exigiriam uma transação em um sistema real. Aqui o contrato é uma única execução com estoque inicial fixo.',
[('Qual entrada viola o domínio do pedido?',['(7,8)','(7,0)','(0,1)'],'B','zero não representa pedido positivo.'),('Pedido igual ao estoque deve produzir:',['recusa e saldo zero','aceite e saldo original','aceite e saldo zero'],'C','a condição de recusa é estritamente maior.'),('Qual invariante vale para uma recusa por falta de peças?',['saldo = estoque','saldo = estoque − pedido','saldo = 0'],'A','nenhuma reserva foi aplicada.')],
[('Decomposição','Separar validação, decisão e atualização para testar cada regra.'),('Invariante do saldo','Permanece entre zero e estoque inicial nas entradas válidas.'),('Contraexemplo','Pedido -2 revela aumento indevido se a validação for omitida.')])

write('LOG-02','Um formulário recebe o texto "007". O atendente quer somar uma unidade ao número informado, preservando também o código original. Preveja valor e tipo após cada atribuição; não confunda a grafia exibida com a quantidade.',
'Variável é um nome associado a um valor. Nesta notação, `texto` e `numero` são tipos distintos; converter cria outro valor, sem editar o texto original. `←` atribui e `=` compara. Inteiros são tratados como valores: atribuir `copia ← quantidade` copia o valor conceitual, e reatribuir quantidade não altera copia. Não estamos modelando referências de listas nem endereços físicos.',
'| Etapa | código: texto | quantidade: inteiro | cópia: inteiro |\n|---|---|---|---|\n| código ← "007" | "007" | não definido | não definido |\n| quantidade ← inteiro(código) | "007" | 7 | não definido |\n| cópia ← quantidade | "007" | 7 | 7 |\n| quantidade ← quantidade + 1 | "007" | 8 | 7 |\n| código ← código + "1" | "0071" | 8 | 7 |',
('text','código ← "007"\nquantidade ← inteiro(código) // conversão decimal explícita\ncópia ← quantidade\nquantidade ← quantidade + 1 // soma numérica\ncódigo ← código + "1"      // concatenação de textos'),
'Parcial: substitua o texto inicial por "010" e complete quantidade final e código final. Independente: simule "dez" e marque a primeira etapa que não pode continuar. Autoexplicação: por que imprimir 7 e imprimir "7" pode parecer igual, mas somar 1 é uma operação diferente?',
'Com "010", quantidade final é 11, cópia é 10 e código final é "0101". Com "dez", a conversão decimal falha; quantidade e cópia não recebem valor. Checkpoint: não invente zero como resultado da conversão inválida. O texto pode ser um identificador; se zeros iniciais importam, mantenha-o como texto.',
'Defina no contrato se sinais, espaços e zeros iniciais são permitidos. Não dependa de coerção implícita. Para uma idade, valide intervalo após converter; para código postal, talvez não converta. Reteste "007", "0" e "dez"; observe tanto tipo quanto valor, porque a saída visual sozinha pode mascarar o erro.',
[('Após incrementar quantidade, cópia vale:',['8','"007"','7'],'C','a reatribuição não altera o inteiro anteriormente copiado.'),('Qual resultado corresponde à concatenação "07" + "1"?',['"071"','8','"08"'],'A','texto é concatenado, não somado.'),('Qual informação se perde ao converter "007" para inteiro?',['a quantidade sete','os zeros de apresentação','a possibilidade de soma'],'B','a representação textual não acompanha o inteiro.')],
[('Valor e representação','7 é uma quantidade; "007" é texto com três caracteres.'),('Reatribuição','Muda a associação de um nome; não reescreve outros inteiros.'),('Conversão','Operação explícita que pode falhar se o texto não representar número.')])

write('LOG-04','Um carrinho ganha frete grátis a partir de R$ 100,00, desde que a entrega seja local. Modele a decisão usando centavos inteiros e uma flag booleana. O caso exatamente no limite deve ser tratado sem ambiguidade.',
'A expressão `(subtotal >= 10000) E local` tem dois operandos booleanos. Ambos precisam ser verdadeiros para executar o primeiro ramo; qualquer falso leva ao segundo. O bloco `senão` pertence ao mesmo `se`: somente um ramo é executado. Usar centavos evita comparar aproximações de ponto flutuante para dinheiro neste exercício.',
'| Subtotal (centavos) | Local | >= 10000 | Resultado do E | Frete |\n|---|---|---|---|---|\n| 9999 | verdadeiro | falso | falso | 1500 |\n| 10000 | verdadeiro | verdadeiro | verdadeiro | 0 |\n| 10001 | falso | verdadeiro | falso | 1500 |',
('text','exigir subtotal inteiro >= 0 e local booleano\nse subtotal >= 10000 E local:\n    frete ← 0    // só este ramo concede gratuidade\nsenão:\n    frete ← 1500\ntotal ← subtotal + frete'),
'Parcial: calcule total para subtotal 10000 e local falso. Independente: construa um caso em que trocar E por OU conceda gratuidade incorreta e outro em que trocar >= por > negue a gratuidade. Autoexplicação: justifique a decisão sem citar apenas o nome do operador.',
'10000 com local falso resulta em frete 1500 e total 11500. Com subtotal 100 e local verdadeiro, OU aceitaria indevidamente; com subtotal 10000 local verdadeiro, > negaria indevidamente. Checkpoint: a saída do segundo ramo não depende de qual operando foi falso.',
'Uma string "false" não é automaticamente o booleano falso em toda linguagem. Valide o tipo antes da condição. Se R$ 100,00 cair no ramo pago, examine >=; se toda entrega local for gratuita, examine E/OU. Reteste as três linhas da tabela e subtotal negativo, que deve ser rejeitado antes da decisão.',
[('Qual subtotal local está na fronteira gratuita?',['10000','9999','10001 apenas'],'A','>= inclui a igualdade.'),('Com subtotal 12000 e local falso, o E resulta em:',['verdadeiro','erro aritmético','falso'],'C','um operando falso basta.'),('Qual mudança permite frete grátis indevido para subtotal 100 local?',['>= por >','E por OU','1500 por 1600'],'B','OU aceita somente a condição local.')],
[('Caso de fronteira','Valor exatamente onde a decisão muda: 10000.'),('Conjunção E','Verdadeira somente se ambos os operandos forem verdadeiros.'),('Exclusividade dos ramos','Um se/senão executa exatamente um dos dois blocos após avaliar a condição.')])

write('LOG-05','Precisamos emitir exatamente três etiquetas, numeradas 0, 1 e 2. O mesmo algoritmo deve aceitar zero etiquetas sem imprimir nada. Trace a condição antes de cada iteração e o avanço do contador.',
'Inicialize `i=0`. Antes de cada corpo, teste `i<n`. Ao final incremente i. Invariante: antes do teste, i etiquetas já foram emitidas e `0 ≤ i ≤ n`. A quantidade `n−i` diminui em uma unidade a cada iteração, justificando a terminação para n inteiro não negativo. O índice final n existe como contador, mas não como etiqueta emitida.',
'| Teste | i antes | i < 3 | Etiqueta | i depois |\n|---|---|---|---|---|\n| 1 | 0 | verdadeiro | 0 | 1 |\n| 2 | 1 | verdadeiro | 1 | 2 |\n| 3 | 2 | verdadeiro | 2 | 3 |\n| 4 | 3 | falso | nenhuma | 3 |\n\nPara n=0, o primeiro teste `0<0` é falso; o corpo não executa.',
('text','exigir n inteiro >= 0\ni ← 0\nenquanto i < n:\n    emitir etiqueta i\n    i ← i + 1  // progresso obrigatório\ndevolver i     // quantidade efetivamente emitida'),
'Parcial: preencha a tabela para n=1. Independente: troque < por <= e trace n=0 e n=3. Autoexplicação: por que contar testes da condição não é o mesmo que contar iterações?',
'n=1 emite 0, termina com i=1 e testa a condição duas vezes. Com <=, n=0 emite uma etiqueta e n=3 emite quatro. Checkpoint: n iterações geram n+1 testes neste enquanto, porque há um teste final falso. Sem incremento, n=3 repete etiqueta 0 indefinidamente.',
'Não tente corrigir duplicação começando i em 1 sem revisar o contrato de numeração. Corrija o limite e repita n=0,1,3. Limite também n na entrada se cada etiqueta consumir recursos; um algoritmo terminante ainda pode demorar demais. Nenhuma exploração de sistemas é necessária: a evidência é a tabela de estados.',
[('Para n=0, quantos corpos executam?',['1','0','depende da impressão'],'B','a condição inicial já é falsa.'),('Qual valor tem i ao terminar n=3?',['3','2','4'],'A','3 é contador final, não etiqueta impressa.'),('O que prova progresso rumo à parada?',['emitir texto','n continuar constante','n−i diminuir até zero'],'C','a distância ao limite decresce.')],
[('Off-by-one','Erro de uma unidade no limite, como <= onde o contrato exige <.'),('Invariante do contador','i corresponde à quantidade já emitida antes do teste.'),('Zero iterações','Um enquanto testa antes do corpo e pode não executá-lo.')])

write('LOG-07','Dois caixas calculam o mesmo subtotal e divergem porque uma rotina imprime o valor, mas não o devolve. Defina uma função de subtotal que outro cálculo possa usar, com parâmetros e retorno explícitos.',
'O contrato de `subtotal(preço, quantidade)` exige dois inteiros não negativos e retorna seu produto em centavos. Parâmetros são nomes locais que recebem os argumentos da chamada. Retorno entrega um valor ao chamador; impressão produz uma mensagem para uma pessoa e não substitui retorno. A função não lê nem modifica variáveis externas e, para os mesmos argumentos, devolve o mesmo resultado.',
'| Chamada | preço local | quantidade local | retorno | variável no chamador |\n|---|---|---|---|---|\n| a ← subtotal(250,3) | 250 | 3 | 750 | a=750 |\n| b ← subtotal(250,0) | 250 | 0 | 0 | b=0 |\n\nAo terminar cada chamada, os nomes locais deixam de participar daquela execução; a e b continuam no chamador.',
('text','função subtotal(preço, quantidade):\n    exigir preço e quantidade inteiros não negativos\n    valor ← preço * quantidade // nome local, não global\n    devolver valor\na ← subtotal(250, 3)\nb ← subtotal(250, 0)\ntotal ← a + b'),
'Parcial: complete `subtotal(125,4) → ____`. Independente: escreva o contrato de `com_frete(valor, frete)` e use o retorno de subtotal como argumento. Autoexplicação: o que impediria total de ser calculado se subtotal somente imprimisse 750?',
'Retorno 500. com_frete exige inteiros não negativos e devolve valor+frete; `com_frete(subtotal(125,4),150)` devolve 650. A função interna termina antes que a externa receba o argumento. Sem retorno numérico, total não tem os operandos exigidos. Checkpoint: quantidade -1 é erro de contrato, não subtotal negativo válido.',
'Valide na fronteira da função para que todos os chamadores recebam a mesma garantia. Não use quantidade global como dependência escondida. Se duas chamadas iguais diferirem, procure estado externo. Reteste (250,3), (250,0), (0,3) e entrada negativa. Em implementação com inteiros limitados, também é necessário tratar overflow.',
[('Qual é argumento em subtotal(250,3)?',['preço','valor','250'],'C','argumento é o valor fornecido na chamada.'),('Para somar depois, a função precisa:',['devolver número','imprimir número','alterar variável global'],'A','retorno compõe cálculos sem efeito externo.'),('Qual entrada viola o contrato?',['(0,3)','(250,-1)','(250,0)'],'B','quantidade deve ser não negativa.')],
[('Parâmetro','Nome local declarado na definição; recebe um argumento.'),('Retorno','Valor transferido ao chamador, distinto da saída no terminal.'),('Contrato de subtotal','Inteiros não negativos entram; produto em centavos sai.')])
pycode={
'PY-01':'''# Salve este arquivo como primeiro.py em UTF-8.
nome = "Ana"
quantidade = 3
if quantidade > 0:
    print(f"Olá, {nome}: {quantidade} itens")  # quatro espaços: corpo do if
print("Fim")  # fora do bloco: executa mesmo com quantidade zero
''',
'PY-04':'''def subtotal(preco, quantidade):
    """Recebe centavos/quantidade inteiros não negativos; retorna centavos."""
    # bool é subtipo de int em Python; este contrato recusa bool explicitamente.
    if type(preco) is not int or type(quantidade) is not int:
        raise TypeError("esperados inteiros")
    if preco < 0 or quantidade < 0:
        raise ValueError("valores negativos")
    valor = preco * quantidade  # variável local; não altera o chamador
    return valor

if __name__ == "__main__":
    valor = 99
    assert subtotal(250, 3) == 750
    assert subtotal(250, 0) == 0
    assert valor == 99
    for args, erro in [((-1, 2), ValueError), ((True, 2), TypeError)]:
        try:
            subtotal(*args)
        except erro:
            pass
        else:
            raise AssertionError(f"deveria rejeitar {args}")
    print("subtotal=750; zero=0; externo=99; inválidos rejeitados")
''',
'PY-06':'''from pathlib import Path
import tempfile


def resumir(origem, destino):
    # with fecha cada arquivo mesmo se a leitura ou escrita lançar exceção.
    with Path(origem).open("r", encoding="utf-8") as entrada:
        nomes = [linha.strip() for linha in entrada if linha.strip()]
    # Somente escrevemos depois de a leitura inteira terminar com sucesso.
    with Path(destino).open("w", encoding="utf-8", newline="\\n") as saida:
        saida.write(f"registros={len(nomes)}\\n")
    return nomes

if __name__ == "__main__":
    # Pasta temporária própria: não sobrescreve documentos do aluno.
    with tempfile.TemporaryDirectory(prefix="aula arquivos ") as pasta:
        base = Path(pasta)
        origem, destino = base / "nomes ação.txt", base / "resumo.txt"
        origem.write_text("Ana\\nJoão\\n\\n", encoding="utf-8")
        assert resumir(origem, destino) == ["Ana", "João"]
        assert destino.read_text(encoding="utf-8") == "registros=2\\n"
        try:
            resumir(base / "ausente.txt", destino)
        except FileNotFoundError:
            print("ausente: arquivo não encontrado; resumo preservado")
        else:
            raise AssertionError("ausente deveria falhar")
        assert destino.read_text(encoding="utf-8") == "registros=2\\n"
        print("UTF-8: João; registros=2; caminhos com espaços OK")
''',
'PY-07':'''def converter(texto, trilha):
    try:
        numero = int(texto)
    except ValueError:  # texto inválido é uma falha prevista
        trilha.append("formato inválido")
        return None
    else:
        trilha.append("conversão concluída")
        return numero
    finally:
        trilha.append("finalizado")  # não faça return aqui: ocultaria o resultado/erro

if __name__ == "__main__":
    for entrada, esperado, eventos in [
        ("12", 12, ["conversão concluída", "finalizado"]),
        ("x", None, ["formato inválido", "finalizado"]),
    ]:
        trilha = []
        assert converter(entrada, trilha) == esperado
        assert trilha == eventos
        print(repr(entrada), esperado, trilha)
    trilha = []
    try:
        converter(None, trilha)  # TypeError: defeito do chamador; não esconder
    except TypeError:
        assert trilha == ["finalizado"]
        print("TypeError propagado; finally executado")
    else:
        raise AssertionError("TypeError foi ocultado")
'''}
for id,code in pycode.items():(LAB/f'{id}.py').write_text(code,encoding='utf-8')
write('PY-01','Execute um arquivo Python que cumprimenta Ana e informa três itens. A competência desta aula é salvar código, invocar o interpretador correto e explicar quais linhas pertencem ao bloco condicional.',
'Python lê o arquivo fonte UTF-8 e interpreta as instruções em ordem. `nome` recebe texto; quantidade recebe inteiro. Os dois pontos abrem o bloco do if e os quatro espaços colocam o primeiro print dentro dele. O segundo print está alinhado com if e executa independentemente da condição. Aspas delimitam texto; a f-string avalia os nomes entre chaves.',
'Com quantidade=3, a condição é verdadeira e a saída tem duas linhas: `Olá, Ana: 3 itens` e `Fim`. Com quantidade=0, o primeiro print é pulado e somente `Fim` aparece. Não escreva o marcador `>>>` do console interativo no arquivo.',('python',pycode['PY-01']),
'Preparação: instale Python 3 pelo instalador oficial ou gerenciador de pacotes do sistema. Em Windows, verifique `py -3 --version` e use `py -3 "PY-01.py"`; Linux/macOS usam os comandos abaixo. Parcial: altere somente quantidade para zero e preveja a saída. Independente: adicione uma linha fora do bloco que imprima o nome. Autoexplicação: como a posição do segundo print determina se Fim aparece?',
'Checkpoint 1: a versão deve começar por Python 3. Checkpoint 2: o arquivo executado deve ser PY-01.py, não PY-01.py.txt. Zero imprime somente Fim. A linha `print(nome)` sem recuo imprime Ana nos dois casos. Remover o recuo da primeira linha do bloco causa IndentationError, não uma decisão falsa.',
'Se o comando não existir, revise a instalação/PATH ou o launcher py. Se o arquivo não for localizado, rode no diretório do arquivo ou passe caminho absoluto entre aspas. Não misture tabs e espaços. `python3 -m py_compile "PY-01.py"` detecta erro de sintaxe, mas não prova a saída; execute os casos 3 e 0 após ajustar a indentação.',
[('Qual linha roda quando quantidade=0?',['nenhuma','somente print("Fim")','ambos os prints'],'B','o print sem recuo está fora do if.'),('O que determina o corpo do if?',['nome do arquivo','aspas da mensagem','indentação após dois pontos'],'C','o recuo delimita o bloco.'),('Por que verificar --version?',['para confirmar qual interpretador executará','para compilar o arquivo','para criar a variável nome'],'A','o comando identifica o runtime disponível.')],
[('Script','Arquivo fonte executado pelo interpretador.'),('Indentação','Recuo que define blocos em Python.'),('f-string','Texto que interpola expressões entre chaves.')],['PY-01.py'],'python3 --version\npython3 "PY-01.py"')
write('PY-04','Uma rotina de preço precisa devolver 750 para 250 centavos × 3 itens e recusar True como preço. Escreva e teste um contrato de função, distinguindo nomes locais, argumentos e retorno.',
'`def` cria uma função; sua execução começa quando ela é chamada. preco e quantidade recebem argumentos. `valor` local existe durante a chamada, enquanto o valor=99 do chamador permanece 99. `return` encerra a chamada e entrega o produto. Python trata bool como subtipo de int, por isso `type(x) is int` expressa este contrato mais restrito que `isinstance(x,int)`.',
'Chamada subtotal(250,3): valida tipos → valida sinais → valor local 750 → retorna 750. subtotal(250,0) retorna 0. subtotal(-1,2) interrompe com ValueError antes da multiplicação. O teste consulta resultados; imprimir 750 sozinho não verificaria o retorno.',('python',pycode['PY-04']),
'Parcial: acrescente um teste para subtotal(0,3). Independente: escreva uma função total(preco,quantidade,frete) que use subtotal, valide frete inteiro não negativo e retorne a soma. Autoexplicação: por que valor global continua 99 mesmo havendo uma variável local homônima?',
'Zero × três retorna zero. Uma solução de total valida frete com as mesmas duas verificações e devolve `subtotal(preco,quantidade)+frete`; total(250,3,150)=900. Checkpoint: teste inválido deve falhar se o raise for retirado; a ausência de exceção não pode ser confundida com sucesso.',
'Evite capturar todas as exceções dentro de subtotal e retornar zero: isso tornaria entrada defeituosa indistinguível de compra vazia válida. Reteste bool, negativo, zero e valor normal. Se retorno for None, procure caminho sem return. Se externo mudar, procure global ou mutação de objeto compartilhado.',
[('Qual é o retorno de subtotal(250,0)?',['None','erro de tipo','0'],'C','zero está no domínio aceito.'),('Por que bool é recusado explicitamente?',['bool é subtipo de int','bool é sempre negativo','bool não pode ser multiplicado'],'A','o domínio desejado é mais estrito que a hierarquia de tipos.'),('O valor externo após a chamada é:',['750','99','0'],'B','a atribuição local não muda o nome do chamador.')],
[('def','Define uma função que executa quando chamada.'),('Escopo local','Associações internas não reatribuem nomes externos.'),('Teste de contrato','Verifica resultado válido e rejeição das entradas fora do domínio.')],['PY-04.py'],'python3 "PY-04.py"')
write('PY-06','Um arquivo UTF-8 contém Ana, João e uma linha vazia. Gere um resumo com dois registros, sem destruir o resumo anterior quando o arquivo de origem não existir.',
'Path representa o caminho sem abri-lo. open("r",encoding="utf-8") decodifica bytes em texto; with fecha o handle em saída normal e excepcional. strip remove quebra de linha e espaços nas bordas; a condição descarta linha vazia. O destino só é aberto em modo w depois da leitura: abrir w antes truncaria um resumo válido mesmo se a origem estivesse ausente.',
'Bytes UTF-8 de João são decodificados para quatro caracteres. A coleção passa de [] para [Ana] para [Ana,João]; a linha vazia não entra. O destino recebe `registros=2\n`. Na segunda chamada, FileNotFoundError acontece na abertura da origem; a escrita nunca começa.',('python',pycode['PY-06']),
'Parcial: acrescente uma linha de nome e preveja o novo resumo. Independente: modifique resumir para também retornar a quantidade de linhas vazias, sem criar outro acesso de leitura. Autoexplicação: em que linha o destino seria perdido se sua abertura fosse movida para antes da leitura?',
'Três nomes produzem registros=3. Uma solução independente incrementa vazias quando `not linha.strip()` e mantém nomes em lista separada; o fixture original tem uma linha vazia. Checkpoints: João deve preservar o ã; ausência da origem deve manter o resumo existente byte a byte.',
'Modo w sobrescreve; use apenas o destino de laboratório. Falha durante a escrita ainda pode deixar arquivo parcial: para uma ferramenta real, escreva em temporário no mesmo filesystem e substitua após sucesso. UnicodeDecodeError indica encoding incompatível, não caminho ausente; não o capture como FileNotFoundError. Reteste origem ausente, arquivo vazio e caminho com espaços.',
[('Quando w trunca o arquivo?',['ao fechar','ao abrir','somente depois de write'],'B','a abertura em w já remove o conteúdo anterior.'),('Qual construção fecha o arquivo mesmo com exceção?',['Path sozinho','strip','with'],'C','o gerenciador de contexto executa o fechamento.'),('Por que encoding explícito?',['para decodificar os bytes de modo previsível','para tornar o caminho absoluto','para impedir sobrescrita'],'A','UTF-8 determina a interpretação de João.')],
[('Path','Objeto que representa um caminho e fornece operações de arquivo.'),('with','Gerencia abertura e fechamento mesmo quando o bloco falha.'),('FileNotFoundError','Falha de localização; distinta de erro de encoding ou permissão.')],['PY-06.py'],'python3 "PY-06.py"')
write('PY-07','Ao converter entradas textuais, "x" é um erro de formato previsto; None é um defeito do chamador. Trate a primeira falha sem ocultar a segunda e demonstre que finally executa nos dois caminhos.',
'try contém a operação que pode falhar. except ValueError trata somente a classe prevista. else executa se o try terminou sem exceção. finally executa antes de a função concluir, inclusive quando há return ou propagação. Um return dentro de finally poderia substituir o retorno anterior ou suprimir uma exceção: por isso o bloco somente registra finalização.',
'"12" → int=12 → else registra conversão → finally registra finalizado → retorna 12. "x" → ValueError → except registra formato → finally → retorna None. None → TypeError não capturado → finally → erro chega ao chamador.',('python',pycode['PY-07']),
'Parcial: trace converter("0",trilha), distinguindo zero de None. Independente: teste converter(" 8 ",trilha) e converter("8.5",trilha). Autoexplicação: qual informação seria perdida ao substituir except ValueError por except Exception?',
'"0" retorna 0 e eventos de sucesso; " 8 " retorna 8 porque int aceita espaços; "8.5" retorna None com formato inválido porque não é representação de inteiro. Checkpoint: TypeError deve continuar visível ao chamador e a trilha desse caso deve conter apenas finalizado.',
'Não use `if not resultado` para reconhecer o sentinela: zero também é falso. Use `resultado is None`. Não inclua operações sem relação no try, para não classificar erros de outras funções como formato inválido. Reteste os três caminhos fornecidos depois de alterar o tratamento. finally registra uma tentativa de finalização; para arquivos, prefira with para fechamento efetivo.',
[('converter("0",[]) devolve:',['0','None','ValueError'],'A','zero é inteiro válido.'),('Qual erro atravessa a função?',['ValueError de "x"','nenhum por haver finally','TypeError de None'],'C','except só trata ValueError.'),('Um return em finally pode:',['executar antes de try','ocultar erro pendente','converter TypeError em ValueError automaticamente'],'B','o retorno substitui a propagação.')],
[('except específico','Recupera apenas falhas cujo significado foi previsto.'),('else do try','Executa após try bem-sucedido.'),('finally','Executa na saída normal, com retorno ou com exceção pendente.')],['PY-07.py'],'python3 "PY-07.py"')
# Dependência didática local: wheel completo, sem acesso à rede ou pacote de terceiros.
import zipfile, hashlib, base64, csv, io
wheel_files={
 'medidas_lab/__init__.py':b'__version__ = "1.0.0"\ndef kib(bytes_count):\n    return bytes_count / 1024\n',
 'medidas_lab-1.0.0.dist-info/METADATA':b'Metadata-Version: 2.1\nName: medidas-lab\nVersion: 1.0.0\nSummary: Dependencia local didatica\n',
 'medidas_lab-1.0.0.dist-info/WHEEL':b'Wheel-Version: 1.0\nGenerator: phase16\nRoot-Is-Purelib: true\nTag: py3-none-any\n'}
rec=io.StringIO();cw=csv.writer(rec,lineterminator='\n')
for n,b in wheel_files.items():cw.writerow([n,'sha256='+base64.urlsafe_b64encode(hashlib.sha256(b).digest()).decode().rstrip('='),len(b)])
cw.writerow(['medidas_lab-1.0.0.dist-info/RECORD','',''])
wheel_files['medidas_lab-1.0.0.dist-info/RECORD']=rec.getvalue().encode()
with zipfile.ZipFile(LAB/'medidas_lab-1.0.0-py3-none-any.whl','w') as z:
 for n,b in wheel_files.items():z.writestr(n,b)
(LAB/'requirements-PY-08.txt').write_text('medidas-lab==1.0.0\n')
(LAB/'conversao.py').write_text('from medidas_lab import kib\n\ndef resumo(tamanho):\n    return f"{kib(tamanho):.1f} KiB"\n',encoding='utf-8')
(LAB/'PY-08.py').write_text('import sys\nimport medidas_lab\nfrom conversao import resumo\nassert resumo(2048) == "2.0 KiB"\nprint(resumo(2048))\nprint("versão:", medidas_lab.__version__)\nprint("interpretador:", sys.executable)\nprint("dependência:", medidas_lab.__file__)\n',encoding='utf-8')
write('PY-08','Um script usa um módulo da própria pasta e uma dependência instalada. Precisamos reproduzir o resultado 2.0 KiB em um ambiente separado, sem instalar pacotes globalmente nem depender da internet.',
'Um módulo é um arquivo importável. PY-08 importa conversao da pasta do script; conversao importa medidas_lab de site-packages do ambiente virtual. venv cria um interpretador associado a diretórios próprios de pacotes; não é uma VM nem isola permissões de arquivos ou rede. requirements fixa a versão 1.0.0 da dependência didática fornecida como wheel local completo.',
'Fluxo: PY-08.py → conversao.resumo(2048) → medidas_lab.kib(2048) → 2.0 → "2.0 KiB". `sys.executable` deve apontar para .venv e `medidas_lab.__file__` para site-packages dentro dela. O nome da distribuição usa hífen (medidas-lab); o módulo importado usa underscore (medidas_lab).',
('python',(LAB/'conversao.py').read_text()),
'Baixe todos os cinco arquivos para a mesma pasta. Parcial: mude o argumento para 1024 e preveja o resultado. Independente: execute PY-08.py com o Python fora de .venv e explique o ModuleNotFoundError caso a dependência não esteja instalada ali. Autoexplicação: por que usar o mesmo executável em -m pip e na execução do script?',
'1024 gera 1.0 KiB. Checkpoints: pip informa medidas-lab 1.0.0 instalada; a saída mostra o caminho do interpretador da venv; o módulo conversao vem da pasta local. Windows: `py -3 -m venv .venv`, depois `& ".venv\Scripts\python.exe" -m pip install --no-index --find-links . -r "requirements-PY-08.txt"` e o mesmo executável para PY-08.py.',
'Se venv não estiver disponível em Linux, instale o componente python3-venv pelo gerenciador do sistema. Não nomeie o script medidas_lab.py: isso pode sombrear a dependência. Se pip buscar rede, confira --no-index. Fixar versão torna a resolução previsível, mas não prova a confiança no fornecedor. Reteste após remover somente a venv criada para este lab e recriá-la a partir do wheel.',
[('Qual arquivo resolve conversao neste exercício?',['módulo da pasta do script','biblioteca padrão','arquivo dentro do wheel'],'A','conversao.py foi fornecido ao lado do script.'),('venv separa principalmente:',['kernel','pacotes e interpretador associado','acesso aos arquivos do usuário'],'B','não é um sandbox de segurança.'),('Por que medidas-lab==1.0.0?',['para atualizar automaticamente','para converter hífen em underscore','para fixar a versão instalada'],'C','a versão fica explícita no requisito.')],
[('Módulo','Unidade importável, como conversao.py.'),('Distribuição','Pacote instalável; seu nome pode diferir do import.'),('sys.executable','Caminho do interpretador que realmente executa o programa.')],['PY-08.py','conversao.py','requirements-PY-08.txt','medidas_lab-1.0.0-py3-none-any.whl'],
'python3 -m venv ".venv"\n".venv/bin/python" -m pip install --no-index --find-links . -r "requirements-PY-08.txt"\n".venv/bin/python" "PY-08.py"')

ccode={
'C-01':'''#include <stdio.h>  /* declara printf; não executa uma impressão */
int main(void) {    /* ponto de entrada, sem argumentos usados */
    int caixas = 3;
    int itens = caixas * 4; /* expressão avaliada e armazenada */
    printf("itens=%d\\n", itens); /* %d corresponde a int */
    return 0;      /* status de sucesso para o processo chamador */
}
''',
'C-06':'''#include <assert.h>
#include <stddef.h>
#include <stdio.h>
/* n é quantidade de elementos, não bytes; acesso só ocorre para i < n. */
static int soma(const int *valores, size_t n) {
    int total = 0;
    for (size_t i = 0; i < n; ++i) total += valores[i];
    return total;
}
int main(void) {
    int valores[] = {4, 7, 2};
    size_t n = sizeof valores / sizeof valores[0];
    assert(n == 3 && soma(valores, n) == 13);
    assert(soma(NULL, 0) == 0); /* corpo não acessa NULL */
    printf("n=%zu soma=%d vazio=%d\\n", n, soma(valores,n), soma(NULL,0));
    return 0;
}
''',
'C-07':'''#include <assert.h>
#include <stdio.h>
#include <string.h>
/* Contrato: src é string válida; dst tem cap bytes graváveis. */
static int copiar(char *dst, size_t cap, const char *src) {
    size_t n = strlen(src);
    if (n >= cap) return 0; /* reserva um byte para o terminador NUL */
    memcpy(dst, src, n + 1); /* inclui o terminador; objetos sem sobreposição */
    return 1;
}
int main(void) {
    char destino[5] = "";
    assert(copiar(destino,sizeof destino,"Ana"));
    printf("texto=%s comprimento=%zu capacidade=%zu\\n",destino,strlen(destino),sizeof destino);
    assert(copiar(destino,sizeof destino,"ABCD"));
    assert(!copiar(destino,sizeof destino,"ABCDE"));
    assert(strcmp(destino,"ABCD") == 0); /* recusa preserva destino */
    puts("4 caracteres aceitos; 5 recusados; destino preservado");
    return 0;
}
''',
'C-09':'''#include <assert.h>
#include <stdio.h>
/* Ponteiro emprestado: chamador mantém o objeto vivo durante a chamada. */
static int incrementar(int *p) {
    if (p == NULL) return 0; /* NULL não aponta para um int válido */
    *p += 1;               /* grava no objeto apontado */
    return 1;
}
int main(void) {
    int x = 7;
    int *p = &x;           /* & obtém endereço; ainda não copia x */
    int *alias = p;        /* ambos designam o mesmo x */
    assert(incrementar(p));
    assert(x == 8 && *alias == 8);
    assert(!incrementar(NULL));
    printf("x=%d alias=%d null=recusado\\n",x,*alias);
    return 0;             /* lifetime de x termina na saída de main */
}
''',
'C-12':'''#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
/* O chamador recebe ownership do bloco; precisa free uma vez. */
static int *criar(size_t n, int simular_falha) {
    if (n == 0 || n > SIZE_MAX / sizeof(int)) return NULL;
    /* injeção controlada testa o caminho de falha sem esgotar memória */
    int *p = simular_falha ? NULL : malloc(n * sizeof *p);
    if (p == NULL) return NULL;
    for (size_t i = 0; i < n; ++i) p[i] = (int)i;
    return p; /* o bloco vive além da chamada; o nome local p não */
}
int main(void) {
    int *dados = criar(3, 0);
    if (dados == NULL) { fputs("alocação falhou\\n", stderr); return 1; }
    assert(dados[0] == 0 && dados[2] == 2);
    printf("heap: %d %d %d\\n",dados[0],dados[1],dados[2]);
    free(dados);
    dados = NULL;
    assert(criar(3,1) == NULL && criar(0,0) == NULL);
    puts("falha simulada e tamanho zero tratados");
    return 0;
}
''',
'C-13':'''#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv) {
    (void)argv;
    int *p = malloc(sizeof *p);
    if (p == NULL) return 1;
    *p = 42;
    if (argc > 1) {
        int *alias = p;
        free(p);
        p = NULL; /* NÃO invalida o outro nome alias */
        printf("%d\\n", *alias); /* fixture intencional: ASan deve apontar UAF */
        return 0;
    }
    printf("antes de free=%d\\n", *p);
    free(p);     /* libera exatamente uma vez, depois do último uso */
    p = NULL;
    puts("ownership encerrado; nenhum acesso depois de free");
    return 0;
}
''',
'C-19':'''#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv) {
    if (argc != 2) { fputs("use: asan | ubsan | corrigido\\n",stderr); return 2; }
    if (strcmp(argv[1],"asan") == 0) {
        int *p = malloc(2 * sizeof *p);
        if (!p) return 1;
        volatile int indice = 2; /* índices válidos são 0 e 1 */
        p[indice] = 9;          /* erro intencional: heap-buffer-overflow */
        free(p);
    } else if (strcmp(argv[1],"ubsan") == 0) {
        volatile int maximo = INT_MAX;
        printf("%d\\n", maximo + 1); /* overflow signed: comportamento indefinido */
    } else if (strcmp(argv[1],"corrigido") == 0) {
        int valores[2] = {0,9};
        int maximo = INT_MAX;
        if (maximo == INT_MAX) puts("incremento recusado: limite de int");
        printf("ultimo=%d\\n",valores[1]);
    } else { return 2; }
    return 0;
}
'''}
for id,code in ccode.items():(LAB/f'{id}.c').write_text(code,encoding='utf-8')
def cwrite(id,problem,mechanism,example,exercise,answer,robust,quiz,cards,extra=''):
 cmd=f'cc -std=c11 -Wall -Wextra -Wpedantic -g -O0 "{id}.c" -o "{id}"\n"./{id}"'
 if extra:cmd=extra
 write(id,problem,mechanism,example,('c',ccode[id]),exercise,answer,robust,quiz,cards,[f'{id}.c'],cmd)
cwrite('C-01','Conte os itens de três caixas com quatro unidades e produza um executável C. Você deve distinguir fonte, declaração, expressão, chamada e status do processo.',
'`#include` insere declarações do header durante o pré-processamento. main é a função inicial de um programa hospedado; void informa ausência de parâmetros. O corpo usa chaves; statements terminam com ponto e vírgula. caixas recebe 3, itens recebe o produto 12. printf formata o int com %d e emite uma quebra de linha. return 0 termina main informando sucesso.',
'O compilador traduz o fonte e o ligador resolve a chamada de biblioteca. O arquivo C-01.c é texto; C-01 é o programa gerado. Sua execução imprime exatamente `itens=12`. Alterar o fonte sem recompilar mantém o comportamento do executável antigo.',
'Parcial: altere caixas para 5, recompile e preveja a linha de saída. Independente: introduza uma variável itens_por_caixa em vez do literal 4. Autoexplicação: por que #include não produz saída no terminal?',
'Cinco caixas produzem itens=20. A nova expressão é caixas*itens_por_caixa. Checkpoints: compilação deve terminar sem warnings; execução retorna status 0. No shell, consulte `echo "$?"` imediatamente após executar para observar o status.',
'Se houver erro antes de }, procure ponto e vírgula na linha anterior. Se surgir implicit declaration de printf, revise stdio.h. Use formato compatível com o tipo; warnings não são decoração. Reteste 0 e 5 caixas após recompilar. Valores enormes podem ultrapassar int; esta aula limita as entradas às constantes pequenas fornecidas.',
[('O que return 0 informa aqui?',['quantidade zero','status de sucesso','fim do pré-processamento'],'B','é o resultado do processo para o chamador.'),('O que precisa ocorrer após alterar o fonte?',['apenas reabrir terminal','apenas executar o binário antigo','recompilar e executar o novo binário'],'C','o binário não acompanha a edição automaticamente.'),('Qual formato corresponde a int?',['%d','%s','%p'],'A','printf precisa do formato compatível.')],
[('Header','Fornece declarações usadas pelo compilador.'),('Statement','Instrução no corpo; frequentemente termina com ponto e vírgula.'),('Executável','Resultado compilado e ligado, distinto do arquivo fonte.')])
cwrite('C-06','Some o array {4,7,2} sem acessar posição inexistente. Você deve relacionar capacidade, índice e quantidade percorrida, inclusive a chamada vazia.',
'Um array contém elementos contíguos do mesmo tipo. Para três ints, índices válidos são 0,1,2; índice 3 está fora. sizeof valores mede bytes do array no escopo da declaração; dividir por sizeof valores[0] obtém 3 elementos. Ao passar à função, o parâmetro é ponteiro: a quantidade n precisa viajar separada, pois sizeof do ponteiro não recupera a capacidade.',
'Traço do acumulador: antes do laço total=0; i=0 soma 4 →4; i=1 soma 7 →11; i=2 soma 2 →13; i=3 falha i<n e termina. Em soma(NULL,0), a condição é falsa no primeiro teste e nenhum endereço é acessado.',
'Parcial: mude o último elemento para 5 e atualize o resultado esperado. Independente: acrescente uma função maior que retorna sucesso/falha e usa parâmetro de saída; defina o comportamento para n=0. Autoexplicação: por que usar <= n introduziria acesso indevido?',
'Nova soma 16. Para maior, n=0 pode retornar 0 sem escrever saída; n>0 inicializa máximo com valores[0], compara de i=1 até n-1 e retorna 1. Checkpoint: quantidade zero deve evitar toda dereferência, não apenas devolver zero depois de ler valores[0].',
'Não declare array de tamanho zero como se fosse C padrão. O exemplo vazio é ponteiro NULL com comprimento zero. O chamador deve garantir n dentro da capacidade; a função não pode descobri-la sozinha. Soma pode ultrapassar int para dados arbitrários: o fixture usa totais pequenos. Reteste n=0,1,3 e revise qualquer warning de conversão.',
[('Último índice do array de três elementos?',['3','1','2'],'C','índices começam em zero.'),('Por que n é parâmetro separado?',['ponteiro não carrega capacidade','sizeof sempre retorna elementos','arrays são sempre globais'],'A','na função recebemos endereço e contrato de tamanho.'),('soma(NULL,0) é válida porque:',['NULL aponta para zero','o laço não dereferencia nada','C ignora erros em arrays vazios'],'B','o teste inicial impede acesso.')],
[('Capacidade','Número de elementos que cabem no objeto, diferente de bytes.'),('Índice válido','Entre zero e n−1 para n elementos.'),('Array como parâmetro','É ajustado a ponteiro; tamanho deve ser informado.')])
cwrite('C-07','Copie Ana para um buffer de cinco bytes e recuse ABCDE sem corromper o conteúdo anterior. A decisão depende de comprimento mais terminador, não só do número de letras.',
'String C é uma sequência de bytes terminada por NUL, byte de valor zero. "Ana" ocupa quatro bytes: A,n,a,0; strlen retorna 3 e sizeof destino retorna 5. copiar verifica n<cap e só então copia n+1 bytes, incluindo NUL. O contrato exige src já terminada e destino sem sobreposição; strlen não torna dados arbitrários seguros.',
'Ana: n=3, cap=5 → copia 4 bytes. ABCD: n=4 → copia 5 bytes, limite exato. ABCDE: n=5 → recusa e preserva ABCD. O retorno 1 significa sucesso; 0 significa falta de capacidade. `\0` é terminador; não é o caractere textual "0".',
'Parcial: qual capacidade mínima aceita Ana? Independente: adicione teste de texto vazio e capacidade zero usando buffer real; preveja se alguma escrita ocorre. Autoexplicação: por que comparar n>cap em vez de n>=cap permitiria um byte a mais?',
'Capacidade mínima 4. Texto vazio precisa de um byte para NUL; cap=0 recusa antes de escrever. Checkpoint: recusa deve manter destino ABCD. Não use strlen em um array sem terminador para tentar descobrir quanto ele suporta.',
'Em UTF-8, letras acentuadas podem ocupar vários bytes: o tamanho relevante para este buffer é bytes, não caracteres visuais. Se a saída tiver lixo, procure NUL ausente; se truncar silenciosamente, confira o contrato de recusa. Reteste comprimentos 0,cap−1,cap. Para fontes com tamanho conhecido e sem NUL, desenhe uma API que receba o comprimento explícito.',
[('strlen("Ana") é:',['4','3','5'],'B','não conta o terminador.'),('Um buffer de cinco bytes comporta no máximo:',['5 bytes de texto e NUL','3 bytes de texto','4 bytes de texto e NUL'],'C','um byte precisa ser reservado.'),('Na recusa de ABCDE, destino fica:',['ABCD','ABCDE','vazio'],'A','a função verifica antes da cópia.')],
[('NUL','Byte zero que termina uma string C.'),('Comprimento','Quantidade de bytes antes de NUL, medida por strlen.'),('Capacidade','Bytes disponíveis no destino, incluindo espaço para terminador.')])
cwrite('C-09','Dois ponteiros apontam para x=7. Uma função recebe o endereço e incrementa o objeto; explique por que x e a leitura pelo outro ponteiro passam a 8.',
'`&x` obtém endereço do objeto; `p` armazena esse endereço; `*p` acessa o int ali armazenado. A passagem do ponteiro é por valor: a função recebe uma cópia do endereço, mas a dereferência alcança o mesmo objeto. Copiar p para alias não duplica x. NULL é um valor especial que não designa int acessível e deve ser rejeitado antes da dereferência.',
'Estado inicial x=7, p=&x, alias=&x. incrementar recebe o endereço e executa *p+=1; x=8 e *alias=8. incrementar(NULL) devolve 0 e não toca memória. O objeto x permanece vivo até main terminar; devolver endereço de uma variável automática local de uma função criaria ponteiro inválido após seu retorno.',
'Parcial: faça segunda chamada incrementar(alias) e preveja x. Independente: escreva zerar(int *destino) com o mesmo tratamento de NULL. Autoexplicação: reatribuir o parâmetro p para NULL dentro da função mudaria o p do chamador?',
'Segunda chamada produz x=9. zerar pode testar NULL, escrever *destino=0 e devolver 1. Reatribuir apenas o parâmetro ponteiro não muda o nome no chamador: ele também é passado por valor. Checkpoint: diferencie mudança do endereço armazenado de mudança no objeto apontado.',
'Um ponteiro não nulo ainda pode estar pendente, desalinhado ou fora do objeto; NULL não é validação completa. O contrato de lifetime é responsabilidade conjunta de quem empresta e de quem usa. Não retorne &local. Reteste objeto vivo e NULL; se alias mostrar valor diferente de x, revise se ambos ainda designam o mesmo objeto.',
[('Depois de incrementar(p), *alias vale:',['7','8','endereço de x'],'B','os ponteiros compartilham o objeto.'),('Qual operação lê o objeto apontado?',['&p','p = NULL','*p'],'C','dereferência acessa o destino.'),('NULL aceito sem erro exigiria:',['não dereferenciá-lo','convertê-lo para int','imprimi-lo antes'],'A','não há int acessível por NULL.')],
[('Endereço','Localização de um objeto, obtida com &.'),('Alias','Outro ponteiro que designa o mesmo objeto.'),('Lifetime','Intervalo em que o objeto existe e pode ser acessado legitimamente.')])
cwrite('C-12','Crie uma sequência no heap dentro de uma função e use-a após a função retornar. Quem recebe o bloco passa a ser responsável por sua liberação; uma falha de alocação precisa ser prevista.',
'malloc reserva bytes sem inicializá-los e devolve ponteiro ou NULL. O ponteiro local p termina com criar, mas o bloco alocado continua vivo até free. criar inicializa os três ints como 0,1,2 e transfere ownership ao chamador. A guarda SIZE_MAX/sizeof(int) evita overflow no cálculo de bytes; o exemplo didático usa n=3. Zero é recusado por contrato, sem depender das variações de malloc(0).',
'criar(3,0) → reserva 3*sizeof(int) bytes → inicializa 0,1,2 → retorna endereço → main lê → free encerra o bloco. criar(3,1) injeta NULL para exercitar o ramo de falha de modo determinístico; isso não alega ter provocado falta real de RAM.',
'Parcial: mude n para 4 e identifique a inicialização do último elemento. Independente: desenhe uma função destruir que receba ponteiro e deixe claro se ela altera o nome do chamador. Autoexplicação: por que é válido devolver malloc, mas inválido devolver &variavel_local?',
'Quatro elementos seriam 0,1,2,3. free(dados) invalida o bloco; `dados=NULL` altera só esse nome. Uma função que zere o ponteiro do chamador precisaria receber endereço dele (int **), ou devolver NULL para atribuição. Checkpoints: falha não deve causar leitura; sucesso deve ter exatamente um free.',
'Não tente simular falta de memória pedindo quantidades enormes. A injeção controlada cobre o ramo sem pressionar o host. Para n arbitrário, também limite a conversão de índice size_t para int ou use elementos size_t. Reteste sucesso, falha simulada e zero com sanitizers; nunca leia o bloco depois de free para “confirmar” a liberação.',
[('O bloco alocado termina quando:',['criar retorna','p sai de escopo','free é chamado'],'C','duração do bloco difere da duração do ponteiro local.'),('malloc inicializa ints com zero?',['não','sempre','somente com tamanho três'],'A','o programa precisa inicializar antes de ler.'),('A falha do lab é:',['esgotamento real','injeção controlada de NULL','erro de compilação'],'B','é teste determinístico do caminho de erro.')],
[('Heap','Armazenamento dinâmico cuja duração é gerida por alocação/liberação.'),('Ownership','Responsabilidade por encerrar o bloco exatamente uma vez.'),('Falha de alocação','NULL deve ser tratado antes de qualquer acesso ao bloco.')])
cwrite('C-13','Diagnostique um uso após free numa fixture de um único inteiro. Execute o caminho correto e, separadamente, o caminho intencionalmente defeituoso instrumentado por AddressSanitizer.',
'malloc(sizeof *p) cria um int sem inicializar; *p=42 o inicializa. O caminho correto lê antes de liberar. No caminho defeituoso, alias copia o endereço; free(p) encerra o bloco e p=NULL não altera alias. Ler *alias depois disso é use-after-free: qualquer valor observado é consequência de comportamento indefinido, não resultado que possa ser previsto como 42.',
'O ASan deve apontar heap-use-after-free e apresentar pilhas de acesso, liberação e alocação. A primeira evidência útil é o acesso em printf após free, seguida pela origem do bloco. O caminho normal imprime antes de free=42 e encerra sem diagnóstico.',
'Parcial: indique a última linha segura para ler alias. Independente: corrija o ramo defeituoso para imprimir antes de free e remova qualquer acesso posterior; recompile com as mesmas flags. Autoexplicação: por que limpar somente p não basta quando existe alias?',
'A leitura precisa acontecer antes de free(p). Checkpoints: caminho normal tem exit 0; o defeituoso, execução separada com argumento falha, deve retornar status não zero e diagnóstico heap-use-after-free. A correção deve passar com ASan mantendo a impressão 42 antes da liberação.',
'Use somente o programa descartável fornecido. Não reproduza UAF em processos reais. free(NULL) é permitido, mas free duplicado do mesmo endereço não é. Se não houver diagnóstico, confirme flags tanto na compilação quanto na ligação e execute o ramo com argumento. Reteste normal e corrigido; um teste limpo cobre apenas os caminhos executados.',
[('p=NULL após free torna alias seguro?',['sim','não','só se *alias era 42'],'B','alias mantém endereço de bloco encerrado.'),('Qual ordem é correta?',['malloc,free,ler','ler,malloc,free','malloc,inicializar,ler,free'],'C','uso ocorre enquanto o objeto está vivo.'),('ASan associa o acesso inválido a:',['pilhas de alocação/liberação/acesso','apenas nome do binário','somente valor 42'],'A','a causalidade depende da sequência de operações.')],
[('Use-after-free','Acesso a bloco cujo lifetime foi encerrado por free.'),('Ponteiro pendente','Ponteiro que conserva endereço de objeto já encerrado.'),('Instrumentação','Código adicional que detecta violações nos caminhos executados.')],
'cc -std=c11 -Wall -Wextra -g -O0 -fsanitize=address -fno-omit-frame-pointer "C-13.c" -o "C-13"\n"./C-13"\n# A execução seguinte deve falhar: guarde o diagnóstico.\n"./C-13" falha')
cwrite('C-19','Duas falhas diferentes exigem evidências diferentes: gravar fora do heap e ultrapassar INT_MAX. Compile e ligue com ASan/UBSan, interprete cada diagnóstico e compare ao caminho corrigido.',
'ASan acompanha acessos à memória e regiões inválidas; UBSan instrumenta operações cujo comportamento C é indefinido, como overflow signed. O programa escolhe um modo por argumento para que a primeira falha não esconda a segunda. -g preserva informações de fonte; -O0 facilita relacionar execução e linhas; -fno-omit-frame-pointer ajuda pilhas. -fno-sanitize-recover=all faz UBSan encerrar com status não zero.',
'asan: aloca 2 ints e escreve índice 2 → heap-buffer-overflow. ubsan: INT_MAX+1 → signed integer overflow. corrigido: usa índice 1 e testa o limite antes de incrementar → imprime limite recusado e ultimo=9, com status 0.',
'Parcial: marque quais índices são válidos no modo asan. Independente: crie uma cópia corrigida que receba incremento=0 ou 1 e retorne erro quando não couber em int. Autoexplicação: por que executar somente corrigido não prova que os modos defeituosos são detectados?',
'Índices válidos 0 e 1. Para incremento não negativo, verifique maximo>INT_MAX−incremento antes da soma. Checkpoints: cada modo defeituoso é executado em processo separado, produz o diagnóstico correspondente e sai não zero; corrigido não contém runtime error nem ERROR: AddressSanitizer.',
'Nunca trate overflow signed como wraparound garantido. Flags devem aparecer no comando que liga o binário, não só na produção do objeto. Se houver erro de runtime ASan indisponível, registre a limitação do compilador/ambiente em vez de declarar ausência de bug. Reteste os três modos; instrumentação não prova segurança de caminhos não executados.',
[('Qual ferramenta diagnostica INT_MAX+1?',['UBSan','preprocessador','linker sozinho'],'A','é comportamento indefinido aritmético.'),('Por que separar os modos em processos?',['para obter endereços iguais','para reduzir o fonte','para uma falha não impedir a outra evidência'],'C','ASan pode encerrar imediatamente.'),('Uma execução limpa significa:',['ausência de todos os bugs','nenhuma violação detectada naquele caminho','compilação sem warnings'],'B','a cobertura é limitada ao que foi executado.')],
[('ASan','Detecta violações de memória como acesso fora do heap.'),('UBSan','Detecta classes instrumentadas de comportamento indefinido.'),('Reteste','Repete reproducer defeituoso e o caminho corrigido sob as mesmas flags.')],
'cc -std=c11 -Wall -Wextra -g -O0 -fsanitize=address,undefined -fno-sanitize-recover=all -fno-omit-frame-pointer "C-19.c" -o "C-19"\n"./C-19" corrigido\n# Cada um dos próximos comandos deve falhar em execução separada.\n"./C-19" asan\n"./C-19" ubsan')
write('JS-07','Um cliente recebe cinco respostas diferentes de um serviço local: JSON válido, 404, JSON quebrado, demora e redirecionamento. Classifique cada resultado e depois observe a falha com o servidor desligado.',
'fetch devolve uma Promise que pode resolver mesmo para status 404: o transporte HTTP funcionou, mas o recurso não existe. response.ok cobre 200–299. response.json lê e interpreta o corpo de forma assíncrona e pode falhar depois de fetch ter resolvido. AbortController aplica um prazo que permanece ativo até terminar a leitura do corpo. finally limpa o temporizador. redirect:error recusa redirecionamentos em vez de seguir outro destino automaticamente.',
'| Rota/estado | Situação | Classificação esperada |\n|---|---|---|\n| /ok | 200 e JSON válido | ok |\n| /ausente | 404 | http com status 404 |\n| /quebrado | 200, corpo {invalido | json |\n| /lento | resposta em 250 ms, prazo 20 ms | timeout |\n| /redireciona | 302 recusado | transporte-ou-redirecionamento |\n| listener encerrado | nova conexão recusada | transporte-ou-redirecionamento |',
('javascript','const response = await fetch(url, {signal: controller.signal, redirect: "error"});\nif (!response.ok) return {tipo: "http", status: response.status};\n// A leitura do corpo ainda pode falhar; o arquivo completo trata esse caminho.\nconst dados = await response.json();'),
'Use Node.js 20 ou posterior; não há npm install. Parcial: explique por que /ausente não entra automaticamente no catch externo. Independente: acrescente /sem-conteudo com status 204; decida se o contrato aceita sucesso sem JSON e adapte o cliente com teste próprio. Autoexplicação: em qual etapa pode ocorrer um timeout após receber headers?',
'204 não tem corpo: chamar json gera falha de parsing. Uma adaptação válida retorna {tipo:"vazio"} antes de json para status 204. Checkpoints: seis linhas devem mostrar as categorias da tabela; a mensagem ação local preserva UTF-8. Erro de rede e redirect:error são TypeError nesta API; o exemplo mantém uma categoria conjunta porque a classe isolada não prova a causa.',
'Não interprete TypeError como prova de DNS: no lab também representa política de redirect. Não faça retry infinito nem em qualquer método; operação mutável pode ser duplicada. Se /lento não expirar, confira prazo e timer; se o processo ficar aberto, confirme closeAllConnections e close do servidor. Reteste todas as rotas após modificar a leitura do corpo.',
[('fetch para um 404 normalmente:',['sempre rejeita','resolve com Response','retorna undefined'],'B','o status HTTP precisa ser verificado.'),('Onde JSON inválido costuma falhar?',['no DNS','na criação do servidor','em response.json()'],'C','o corpo é interpretado depois da resposta.'),('Por que o timer dura até ler o corpo?',['headers podem chegar antes de um corpo lento','para converter status em erro','para permitir redirect'],'A','receber headers não conclui o download.')],
[('response.ok','Indica status entre 200 e 299.'),('AbortController','Sinaliza cancelamento inclusive durante leitura do corpo.'),('Erro de parsing','Resposta pode chegar com sucesso HTTP e ainda conter JSON inválido.')],['JS-07.mjs'],'node --version\nnode "JS-07.mjs"')

write('NET-24','Acesse HTTPS em loopback com uma CA local explícita e prove duas rejeições diferentes: CA desconhecida e nome de servidor incorreto. O objetivo é observar autenticação do servidor e confidencialidade do HTTP no transporte.',
'HTTPS encapsula mensagens HTTP em TLS. O cliente abre TCP, negocia TLS e valida a cadeia do certificado, a validade temporal e a identidade esperada. Neste lab a CA assina um certificado com SAN DNS:localhost. Conectar ao IP 127.0.0.1 não altera o nome verificado: server_hostname="localhost" declara a identidade esperada. A confiança é adicionada apenas ao contexto do cliente, não ao armazenamento global do sistema.',
'Caso aceito: CA local carregada + localhost no SAN → handshake → GET /segredo → HTTP 200. Caso CA desconhecida: a validação da cadeia falha antes do GET. Caso outro.local: a CA é confiável, mas a identidade não coincide; falha antes de enviar o HTTP. A resposta tem MARCADOR_TLS_16; os bytes encaminhados pelo proxy TLS não contêm esse texto.',
('python','cliente = ssl.create_default_context(cafile="ca.pem")\n# CA e hostname continuam sendo verificados; não use CERT_NONE.\nwith cliente.wrap_socket(socket_tcp, server_hostname="localhost") as tls:\n    tls.sendall(b"GET /segredo HTTP/1.1\\r\\nHost: localhost\\r\\n\\r\\n")'),
'Baixe tls_local.py; exige Python 3 com ssl e OpenSSL CLI. O programa cria CA/servidor temporários, executa clientes e encerra listeners. Parcial: identifique no resultados.json qual campo prova o status HTTP e qual prova a versão TLS. Independente: explique o resultado de confiar na CA e verificar outro.local. Autoexplicação: por que HTTPS não pode ser demonstrado com curl http://...?',
'Checkpoint: TLS12 e TLS13 têm HTTP=200 e versões TLSv1.2/TLSv1.3; CA-nao-confiavel e hostname-incorreto têm resultado rejeitado. A confiança na CA não corrige o nome errado. resultados-tls contém CA pública, registros e PCAPs reconstruídos; as chaves privadas temporárias da CA/servidor são removidas ao terminar.',
'Não use -k ou desative check_hostname para “corrigir” o negativo. Se o certificado expirar, gere outro executando o lab; os certificados valem um dia. Se OpenSSL não existir, instale-o antes da prática. HTTPS protege o transporte entre os endpoints, não torna o JSON confiável nem substitui autorização. Reteste sucesso e as duas rejeições após mudar qualquer configuração TLS.',
[('CA confiável com hostname errado deve:',['ser aceito porque a assinatura vale','ser aceito se o IP é local','ser rejeitado'],'C','a identidade esperada também precisa coincidir.'),('Qual evidência demonstra HTTP dentro do TLS?',['200 recebido pelo cliente TLS validado','curl em http://','arquivo com extensão .pem'],'A','o HTTP só foi enviado após handshake e validação.'),('Como confiar somente no lab?',['desativando toda verificação','carregando a CA no contexto específico','instalando a chave privada globalmente'],'B','a confiança fica limitada ao cliente criado.')],
[('HTTPS','HTTP transportado numa sessão TLS.'),('SAN','Campo de identidades do certificado usado para verificar o nome.'),('CA local','Âncora de confiança criada para este experimento, sem alterar o sistema.')],['tls_local.py'],'python3 --version\nopenssl version\npython3 "tls_local.py"')
write('NET-25','Compare uma sessão TLS 1.2 e uma TLS 1.3 usando a mesma CA e o mesmo servidor. Identifique versão negociada, cifra e o papel separado da autenticação e das chaves de sessão.',
'O ClientHello oferece versões e parâmetros; o ServerHello escolhe os compatíveis. A autenticação com certificado permite ao cliente verificar a identidade do servidor. Neste experimento, ECDHE em TLS 1.2 e a troca efêmera de TLS 1.3 derivam segredos de sessão; a chave privada RSA do certificado autentica o servidor e não equivale à chave simétrica usada para cada registro. Finished verifica a integridade do transcript do handshake. O servidor pode suportar ambas as versões, mas cada conexão negocia uma só.',
'O cliente define minimum_version=maximum_version para controlar a comparação. TLS12 deve informar TLSv1.2, com uma suíte ECDHE-RSA disponível no OpenSSL; TLS13 informa TLSv1.3, com suíte como TLS_AES_256_GCM_SHA384. A cifra exata pode variar por build. Em TLS 1.3 o nome da suíte descreve cifra AEAD/hash, sem embutir o método de autenticação como em nomes de TLS 1.2.',
('python','cliente.minimum_version = ssl.TLSVersion.TLSv1_3\ncliente.maximum_version = ssl.TLSVersion.TLSv1_3\n# Consulte antes de fechar/consumir o encerramento da sessão.\nprint(tls.version(), tls.cipher())'),
'Parcial: compare os campos versao e cifra dos dois registros sem deduzir a versão só pelo nome da cifra. Independente: limite um cliente a TLS1.3 e um servidor a TLS1.2 em cópia do lab; preveja ausência de versão comum. Autoexplicação: por que possuir o certificado público não permite descriptografar o HTTP capturado?',
'Checkpoint: versões diferem, mas ambos recebem o mesmo HTTP 200 validando localhost. Na variação incompatível, o handshake falha antes do HTTP; não é status HTTP 500. Certificado público identifica a chave pública; os segredos da sessão são derivados na negociação. O lab exporta segredos de sessão didáticos em .keys justamente para uma inspeção autorizada na próxima unidade.',
'Não reutilize as chaves temporárias como infraestrutura. Os arquivos .keys permitem descriptografar estas sessões e devem ser tratados como sensíveis fora de um fixture público. Se TLS1.3 não estiver disponível, registre a versão da biblioteca ssl/OpenSSL e não reduza silenciosamente o objetivo a TLS1.2. Reteste as versões e os negativos de cadeia/nome: negociar cifra não substitui autenticação.',
[('Um erro de versão incompatível ocorre:',['após HTTP 500','antes do HTTP','apenas no parser JSON'],'B','não se estabelece a sessão TLS.'),('A chave privada do certificado é sempre a chave de tráfego?',['sim','sim em TLS1.3','não'],'C','autenticação e segredos de sessão têm papéis diferentes.'),('Qual campo é evidência direta da versão?',['tls.version() durante a sessão','nome do arquivo','status 200'],'A','o runtime informa a versão negociada.')],
[('Handshake','Negociação autenticada de parâmetros e segredos de sessão.'),('Finished','Mensagem que verifica integridade do transcript e posse de segredos.'),('Forward secrecy','Troca efêmera reduz o efeito de comprometimento futuro da chave de autenticação sobre sessões passadas.')],['tls_local.py'],'python3 "tls_local.py"')
write('NET-36','Inspecione duas conversas TLS reais, uma 1.2 e outra 1.3, e explique por que um certificado pode aparecer em uma e estar cifrado na outra. Use a mesma requisição para comparar o que é visível sem e com segredos de sessão.',
'O gerador executa TLS real em sockets locais e registra os bytes por direção num proxy. Os PCAPs fornecidos são RECONSTRUÇÕES: Ethernet/IP/TCP, ACKs e timestamps são sintéticos; os payloads TLS vêm das sessões reais. Eles servem para estudar registros/handshake e descriptografia, nunca para medir RTT, perda ou retransmissão. A captura de interface não foi executada: o contêiner não permite socket raw e não tem tcpdump/tshark.',
'Em TLS1.2 deste lab, ClientHello, ServerHello e Certificate são visíveis antes da cifra. Em TLS1.3, após ServerHello as mensagens de handshake seguintes, inclusive Certificate, ficam cifradas. O campo record version legado pode mostrar 0x0303 até em TLS1.3: procure supported_versions. SNI localhost está no ClientHello deste fixture sem ECH. Não conclua que todo tráfego moderno expõe o nome: ECH pode ocultar o ClientHello interno quando implantado.',
('text','Sem .keys: filtro tls.handshake.type == 1 → ClientHello\nSem .keys: filtro tls.handshake.type == 11 → Certificate visível no TLS12 do lab\nTLS13 sem .keys: Certificate não deve ser legível\nCom .keys: filtro http.request.uri == "/segredo" → GET recuperado\nCom .keys: Follow TLS Stream → corpo com MARCADOR_TLS_16'),
'Execute o gerador e abra TLS12-reconstruido.pcap e TLS13-reconstruido.pcap no Wireshark. Primeiro deixe (Pre)-Master-Secret log filename vazio; depois indique o .keys da mesma sessão em Preferences → Protocols → TLS e recarregue. Parcial: registre frame do ClientHello e do ServerHello. Independente: explique por que trocar TLS13.keys pelo de outra execução impede a descriptografia. Autoexplicação: ausência de Certificate legível prova ausência de certificado?',
'Checkpoint sem keys: ClientHello/ServerHello legíveis; HTTP e MARCADOR_TLS_16 ausentes como texto nos bytes do transporte; certificado de TLS1.3 cifrado. Com keys corretas, o objetivo manual é ler GET /segredo e HTTP 200. A verificação automática executada confirma sessões reais, status e ausência dos marcadores nos payloads cifrados; descriptografia no Wireshark não foi executada neste ambiente. Registre seus números de frames, pois o agrupamento de segmentos pode variar.',
'Para captura real em VM Linux própria: inicie `sudo tcpdump -i lo -s 0 -w "tls-real.pcap" "tcp and host 127.0.0.1"`, execute tls_local.py em outro terminal e pare tcpdump com Ctrl+C. Feche outros serviços locais para reduzir coleta; selecione um fluxo com TLS no Wireshark (o proxy cria dois trechos). Essa etapa requer permissão de captura e permanece manual. Não atribua anomalias de TCP aos PCAPs reconstruídos. Reteste com keys removidas/adicionadas e compare versão 1.2/1.3.',
[('Certificate ausente em claro no TLS1.3 significa:',['servidor sem certificado','handshake falhou','mensagem pode estar cifrada'],'C','o certificado vem após ServerHello protegido.'),('O PCAP reconstruído permite medir RTT real?',['não','sim pelos timestamps','sim pelos ACKs'],'A','headers e tempos são didáticos.'),('Qual segredo possibilita ler estas sessões efêmeras?',['certificado público da CA','key log da sessão correspondente','somente nome localhost'],'B','o key log fornece os segredos usados naquela sessão.')],
[('TLS1.3 no PCAP','Handshake após ServerHello é cifrado.'),('SNI/ECH','SNI é visível neste lab sem ECH; ECH pode proteger o ClientHello interno.'),('Key log','Segredos de sessões específicos, distintos da chave privada do certificado.')],['tls_local.py','resultados-tls/TLS12-reconstruido.pcap','resultados-tls/TLS13-reconstruido.pcap','resultados-tls/TLS12.keys','resultados-tls/TLS13.keys','resultados-tls/LEIA-ME.txt'],'python3 "tls_local.py"')
