> Histórico da revisão inicial: M1–M5 foram corrigidos e retestados; M6 foi corrigido editorialmente na integração. M7 permanece pendente. Estado atual em memory-status.json.

# Fase 16 — revisão independente do lote de memória

Data: 2026-09-02. Escopo: aulas 101, 130, 135, 160, 161, 162, 163, 164, 165 e 173, fontes e evidências existentes em `public/course-labs/phase16-memory`. Revisão read-only com a skill code-verification: nenhum conteúdo, laboratório, fixture ou teste foi alterado. Este relatório não atribui nota A.

**Parecer: parcial.** Os mecanismos principais estão concretos e correspondem aos pequenos programas fornecidos. Há defeitos de compatibilidade/instrução e lacunas de reteste abaixo; os checks verdes não os cobrem. Não encontrei, nestas dez aulas, alegação de exploração nativa, captura Windows ou sessão gdb já realizada. O caráter local/sintético está explicitado de forma adequada.

## Achados priorizados

| ID / severidade / confiança | Local e evidência concreta | Consequência e direção mínima de correção |
|---|---|---|
| M1 — média, alta | README e aulas declaram Python 3.9+. `analyze.py:33` usa `datetime.fromisoformat` diretamente nos timestamps terminados em `Z` gerados por `make_fixtures.py`. Esse formato não é aceito pelo método nas versões 3.9/3.10. | `investigate` e portanto `all` não satisfazem o ambiente mínimo anunciado. Ajustar a versão mínima ou normalizar explicitamente o fuso antes do parse. O runtime antigo **não foi executado** nesta revisão; a incompatibilidade deriva do código e documentação oficial. |
| M2 — média, alta | Aula 160, desafio: mover apenas DNS de 410 para 10:00:30Z. `analyze.py:34` então não acrescenta o PID, mas `:37` exige sempre `hits == [410]`, antes de retornar/imprimir o JSON. | O desafio produz uma falha da expectativa fixa do baseline, em vez de relatório com lista vazia. Separar resultado da correlação de seu gabarito, ou explicar explicitamente qual expectativa precisa mudar para o caso negativo. A regra temporal em si está correta para as fixtures atuais. |
| M3 — média, alta | Aula 163, roteiro opcional: breakpoint na entrada de `parse_record`, um `next`, depois `print n`. Em `parser.c`, há três instruções anteriores à inicialização de `n` na linha 11. | Um único passo não garante que `n` esteja inicializado; o aluno pode inspecionar um valor indeterminado e atribuí-lo à entrada. Posicionar a inspeção depois da atribuição, usando a linha real do build. É revisão estática; gdb está ausente e o texto corretamente declara a sessão não executada. |
| M4 — média, alta | Aula 164; `lab.c:59–62`: `depth-fixed` fixa `requested=100000` e sempre retorna 2 no guarda. `run.py:stack` verifica somente essa rejeição e o crash da variante recursiva. | A defesa observada é a recusa do pedido excessivo. Não há demonstração de execução legítima com profundidade dentro do orçamento nem de sua fronteira. Preservação funcional após a defesa permanece pendente; o teste atual poderia continuar verde se todo pedido fosse rejeitado. |
| M5 — média, alta | Aulas 101/173; `lab.c:signed` e `run.py:types` demonstram `INT_MAX+1` sob UBSan, mas não há variante corrigida para os mesmos operandos. `wide=260` vem de 250+10 sem sinal, outro caso. | A regra de correção ensinada está correta, mas o pacote não prova correção e reteste do mesmo overflow assinado. Registrar esse limite, sem usar o check da soma 260 como evidência equivalente. |
| M6 — baixa, alta | Aula 135 chama a entropia agregada de “média global”. Nas fixtures atuais, H de `mixed.bin` = 4,944496; a média das quatro entropias por janela = 3,908970. | São grandezas diferentes. Preferir “entropia da distribuição global/agregada”; a conclusão sobre perda da localização da fronteira continua válida. |
| M7 — baixa, alta | Todas as dez aulas repetem as mesmas referências GCC/ASan/proc-maps. Em particular, essas fontes não sustentam diretamente Shannon/viés amostral da 135 ou correlação/identidade temporal da 160. | A bibliografia parece específica por estar rotulada “fontes primárias”, mas está desalinhada em parte do lote. Associar fontes diretamente às afirmações relevantes; não é um defeito do cálculo local de entropia. |

Para M1: a [documentação Python 3.10](https://docs.python.org/3.10/library/datetime.html#datetime.datetime.fromisoformat) limita os formatos aos emitidos por `isoformat`, com offset numérico. A [documentação atual](https://docs.python.org/3/library/datetime.html#datetime.datetime.fromisoformat) registra a ampliação na versão 3.11 e exemplifica `Z`. Fontes consultadas em 2026-09-02.

## Parecer por unidade

| Aula | Evidência pedagógica sustentada | Limite que deve permanecer explícito |
|---|---|---|
| 101 | Conversão modular, overflow assinado detectado e capacidade/NUL com positivo e rejeição. | M5: falta reteste do overflow assinado corrigido com os mesmos valores. |
| 130 | Cabeçalhos/mapas, canary e regressão do parser correspondem aos programas. Mapas salvos mostram 5 endereços PIE distintos e 1 EXEC. | Assinatura, obfuscação e licensing são comparação conceitual/propostas, como o próprio texto informa. Flags RELRO não são ensaio de alteração de memória. |
| 135 | Fórmula, limites 0/8, controle uniforme previsível e janelas têm resultados coerentes. | M6/M7. A descompressão recomendada não integra `run.py`; conferência independente read-only confirmou roundtrip dos arquivos atuais. |
| 160 | Fixtures declaradamente sintéticas, hash, correlação por PID/tempo e controle negativo são claros. | M1/M2/M7; não prova atividade real, intenção maliciosa ou robustez com múltiplos hosts/reuso de PID. |
| 161 | Violações espacial e temporal, localização do objeto e limitação do ASan estão bem diferenciadas. | Diagnóstico dos caminhos locais não estabelece explorabilidade nem cobre todo contrato de tipos/alinhamento. |
| 162 | Off-by-one exato, fronteiras n=0/3/7/8 e origem truncada correspondem ao parser/fixtures. | `copy_name` depende também de origem válida e capacidade verdadeira fornecidas pelo chamador; o texto já reconhece isso. |
| 163 | Reconstrução de causa a partir do ASan é concreta; aula separa observado/inferido. | M3; registradores e sessão interativa de debugger ainda não demonstrados. |
| 164 | Exaustão da região versus overflow de objeto são corretamente diferenciados. | M4; número de frames é dependente da plataforma, corretamente não tratado como valor fixo. |
| 165 | Lifetime, alias, UAF e preservação de 42 antes de free têm cadeia causal e reteste específicos. | Ensaio introdutório de ownership; não representa estudo completo dos allocators. Isso não invalida o objetivo local. |
| 173 | ASan/UBSan, linkedição, OOB/UAF e interpretação de ausência de alertas estão bem delimitados. | M5; leaks explicitamente desativados, sem validação de LSan ou de todos os caminhos. |

Os quizzes/flashcards destas unidades estão ligados a estados e mecanismos concretos; não são apenas perguntas genéricas sobre “fazer baseline”. Há repetição de scaffolding editorial, mas ela não deve ser confundida com ausência de conteúdo. Por outro lado, o rótulo CAP e o tempo estimado não demonstram cobertura completa de uma área.

## Evidência examinada e ações realizadas

- Lidos os dez Markdown, todas as fontes próprias C/Python, README/advisory e logs/resultados atuais relevantes. Não foram reconstruídos binários nem reexecutados crashes nesta revisão independente.
- Leitura/contagem dos JSON atuais: `results-build.json` contém 12 checks aprovados; `results-all.json`, 62 execuções aprovadas e **46 tags distintas**. Dezesseis cenários do parser são repetidos dentro de `triage`. Isso é reteste legítimo, mas não equivale a 62 cenários independentes ou 62 objetivos pedagógicos.
- `build/environment.json`: Python 3.12.13, GCC 13.3.0, Linux x86-64; gdb/Clang indisponíveis. Esses são resultados de execução do integrador, inspecionados aqui, não novas execuções desta revisão.
- Comando read-only `python3 -B` sobre bytes atuais: exit 0; recalculou H global/janelas de `mixed.bin`, constatou `text.bin` com 6600 bytes e confirmou `zlib.decompress(compressed.bin) == text.bin`. A frase do README “entradas no máximo 4096 bytes” deve ser entendida como limite do driver/harness C; não é limite de todos os arquivos analisados.

A revisão não requer criar técnicas adicionais. As correções sugeridas são ajustes de contrato, clareza e evidência. Aulas 166–172/174+ e os demais itens ainda intocados não foram reabertos.
