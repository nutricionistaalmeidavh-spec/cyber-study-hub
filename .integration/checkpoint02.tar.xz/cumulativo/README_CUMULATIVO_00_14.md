# Cyber Study Hub — Entrega cumulativa Fases 0–14

Este pacote contém todas as entregas desde a Fase 0. Não aplique ZIPs anteriores.

## Principais marcos

### 0–3
- baseline e guardrails;
- schema V2;
- adapter legado;
- Aula 47 V2;
- QA automático.

### 4–7
- Lesson Viewer V2;
- worked examples/fading;
- código anotado;
- laboratório estruturado.

### 8–11
- progresso granular;
- migração local não destrutiva;
- FSRS;
- mastery por conceito;
- Games alimentando revisão.

### 12–14
- catálogo completo 218 + 325 = 543;
- navegação principal/paralela;
- várias trilhas simultâneas;
- biblioteca de conteúdo lazy;
- viewer seguro para Markdown;
- referências/labs externos controlados;
- arquivos locais do lab 47;
- migração V2 do lote 47–60.

## Aplicação no iSH

Na raiz do checkout atual:

```sh
sh /caminho/CyberStudyHub_Fases_00_14_cumulativo/apply.sh
npm install
npm run verify:curriculum
npm run verify:learning
npm run verify:catalog
npm run build
git diff --check
git status
```

`npm install` continua necessário por causa do `ts-fsrs` adicionado nas Fases 8–11.

## Segurança operacional

O pacote não executa automaticamente:

- commit;
- push;
- deploy;
- Cloudflare;
- laboratórios externos.

## Próxima etapa

Fase 15: auditoria completa no Work.
