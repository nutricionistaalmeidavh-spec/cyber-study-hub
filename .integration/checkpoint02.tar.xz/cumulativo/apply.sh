#!/bin/sh
set -eu

SOURCE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if [ ! -f package.json ] || [ ! -f src/components/Lessons.tsx ] || [ ! -f src/App.tsx ]; then
  echo "ERRO: execute este script na raiz do cyber-study-hub."
  exit 1
fi

echo "Aplicando Cyber Study Hub — Fases 0–14 cumulativas..."

mkdir -p \
  src/content/main/047 \
  src/content/references \
  src/components/lesson-v2 \
  src/components/review \
  src/components/curriculum \
  src/components/references \
  src/curriculum \
  src/lib \
  scripts/lib \
  docs/implementation \
  docs/research \
  public

# Arquivos cumulativos / schema / currículo
cp "$SOURCE_DIR/package.json" package.json
cp "$SOURCE_DIR/src/content/schema.ts" src/content/schema.ts
cp "$SOURCE_DIR/src/content/legacyAdapter.ts" src/content/legacyAdapter.ts
cp "$SOURCE_DIR/src/content/registry.ts" src/content/registry.ts
cp "$SOURCE_DIR/src/content/references/repositories.json" src/content/references/repositories.json
cp "$SOURCE_DIR/src/content/references/integrations.json" src/content/references/integrations.json
cp "$SOURCE_DIR/src/curriculum/catalog.json" src/curriculum/catalog.json
cp "$SOURCE_DIR/src/curriculum/types.ts" src/curriculum/types.ts

# Aulas V2 47–60
for id in 047 048 049 050 051 052 053 054 055 056 057 058 059 060; do
  mkdir -p "src/content/main/$id"
  cp "$SOURCE_DIR/src/content/main/$id/lesson.json" "src/content/main/$id/lesson.json"
done

# Componentes 4–14
cp "$SOURCE_DIR/src/components/lesson-v2/LessonViewerV2.tsx" src/components/lesson-v2/LessonViewerV2.tsx
cp "$SOURCE_DIR/src/components/lesson-v2/LabRunner.tsx" src/components/lesson-v2/LabRunner.tsx
cp "$SOURCE_DIR/src/components/lesson-v2/lesson-v2.css" src/components/lesson-v2/lesson-v2.css
cp "$SOURCE_DIR/src/components/review/LearningInsights.tsx" src/components/review/LearningInsights.tsx
cp "$SOURCE_DIR/src/components/review/learning-insights.css" src/components/review/learning-insights.css
cp "$SOURCE_DIR/src/components/curriculum/CurriculumBrowser.tsx" src/components/curriculum/CurriculumBrowser.tsx
cp "$SOURCE_DIR/src/components/curriculum/CourseDocumentViewer.tsx" src/components/curriculum/CourseDocumentViewer.tsx
cp "$SOURCE_DIR/src/components/curriculum/curriculum.css" src/components/curriculum/curriculum.css
cp "$SOURCE_DIR/src/components/references/ReferencePanel.tsx" src/components/references/ReferencePanel.tsx
cp "$SOURCE_DIR/src/components/references/references.css" src/components/references/references.css

# Bibliotecas locais
cp "$SOURCE_DIR/src/lib/learningProgress.ts" src/lib/learningProgress.ts
cp "$SOURCE_DIR/src/lib/mastery.ts" src/lib/mastery.ts
cp "$SOURCE_DIR/src/lib/reviewEngine.ts" src/lib/reviewEngine.ts
cp "$SOURCE_DIR/src/lib/curriculumState.ts" src/lib/curriculumState.ts

# QA e scripts
cp "$SOURCE_DIR/scripts/check-baseline.mjs" scripts/check-baseline.mjs
cp "$SOURCE_DIR/scripts/lib/curriculum-validator.mjs" scripts/lib/curriculum-validator.mjs
cp "$SOURCE_DIR/scripts/validate-curriculum.mjs" scripts/validate-curriculum.mjs
cp "$SOURCE_DIR/scripts/test-curriculum-validator.mjs" scripts/test-curriculum-validator.mjs
cp "$SOURCE_DIR/scripts/apply-phase-04-07.mjs" scripts/apply-phase-04-07.mjs
cp "$SOURCE_DIR/scripts/verify-phase-04-07.mjs" scripts/verify-phase-04-07.mjs
cp "$SOURCE_DIR/scripts/apply-phase-08-11.mjs" scripts/apply-phase-08-11.mjs
cp "$SOURCE_DIR/scripts/verify-phase-08-11.mjs" scripts/verify-phase-08-11.mjs
cp "$SOURCE_DIR/scripts/apply-phase-12-14.mjs" scripts/apply-phase-12-14.mjs
cp "$SOURCE_DIR/scripts/verify-phase-12-14.mjs" scripts/verify-phase-12-14.mjs

# Documentação
cp "$SOURCE_DIR/docs/implementation/PHASES_00_03_BASELINE.md" docs/implementation/PHASES_00_03_BASELINE.md
cp "$SOURCE_DIR/docs/implementation/PHASES_04_07.md" docs/implementation/PHASES_04_07.md
cp "$SOURCE_DIR/docs/implementation/PHASES_08_11.md" docs/implementation/PHASES_08_11.md
cp "$SOURCE_DIR/docs/implementation/PHASES_12_14.md" docs/implementation/PHASES_12_14.md
cp "$SOURCE_DIR/docs/research/RESEARCH_FINDINGS_2026-09-02.md" docs/research/RESEARCH_FINDINGS_2026-09-02.md

# Conteúdo editorial lazy e arquivos próprios de laboratório
rm -rf public/course-library public/course-labs
cp -R "$SOURCE_DIR/public/course-library" public/course-library
cp -R "$SOURCE_DIR/public/course-labs" public/course-labs

# Patches nos arquivos legados do checkout
node scripts/apply-phase-04-07.mjs
node scripts/apply-phase-08-11.mjs
node scripts/apply-phase-12-14.mjs

# Verificação estrutural local
node scripts/verify-phase-04-07.mjs
node scripts/verify-phase-08-11.mjs
node scripts/verify-phase-12-14.mjs

echo ""
echo "Fases 0–14 aplicadas."
echo "Execute agora:"
echo "  npm install"
echo "  npm run verify:curriculum"
echo "  npm run verify:learning"
echo "  npm run verify:catalog"
echo "  npm run build"
echo "  git diff --check"
echo "  git status"
