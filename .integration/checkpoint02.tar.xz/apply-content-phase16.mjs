import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const source = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2), checkOnly = args.includes('--check');
const target = fs.realpathSync(path.resolve(args.find(x => x !== '--check') || '.'));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
if (!fs.existsSync(path.join(target, 'package.json')) || !fs.existsSync(path.join(target, 'src/App.tsx'))) {
  throw Error('Use a raiz do checkout completo do Cyber Study Hub; este pacote atualiza conteúdo sobre as fases 00–14 ou checkpoint 01.');
}
const manifest = JSON.parse(fs.readFileSync(path.join(source, 'CONTENT_MANIFEST.json'), 'utf8'));
const pending = [];
for (const item of manifest) {
  const allowed = /^public\/(course-library|course-labs)\//.test(item.path) || /^src\/content\/main\/(047|052)\/lesson\.json$/.test(item.path);
  if (!allowed || item.path.split('/').includes('..') || item.path.includes('\\')) throw Error('Caminho inválido: ' + item.path);
  const input = path.join(source, 'cumulativo', item.path), dest = path.join(target, item.path);
  if (sha(fs.readFileSync(input)) !== item.sha256) throw Error('Arquivo do pacote divergente: ' + item.path);
  for (let current = dest; current !== target; current = path.dirname(current)) {
    const stat = fs.lstatSync(current, { throwIfNoEntry: false });
    if (stat?.isSymbolicLink()) throw Error('Symlink no destino; revise antes de aplicar: ' + current);
  }
  if (fs.existsSync(dest)) {
    const actual = sha(fs.readFileSync(dest));
    if (actual === item.sha256) continue;
    if (!item.accepted_previous_sha256.includes(actual)) {
      throw Error('Conteúdo local diferente das bases conhecidas; nada aplicado. Compare: ' + item.path);
    }
  }
  pending.push({ ...item, input, dest, existed: fs.existsSync(dest) });
}
if (!pending.length) { console.log('Checkpoint 02 já aplicado.'); process.exit(0); }
if (checkOnly) { console.log(`Pré-verificação OK: ${pending.length} arquivos de conteúdo; nenhuma gravação.`); process.exit(0); }
const backup = fs.mkdtempSync(path.join(path.dirname(target), 'cyber-study-backup-fase16-02-'));
fs.writeFileSync(path.join(backup, 'manifest.json'), JSON.stringify(pending.map(({ path, existed }) => ({ path, existed })), null, 2));
// Todos os backups são criados antes de alterar qualquer destino.
for (const item of pending) if (item.existed) {
  const saved = path.join(backup, item.path);
  fs.mkdirSync(path.dirname(saved), { recursive: true });
  fs.copyFileSync(item.dest, saved);
}
const touched = [];
try {
  for (const item of pending) {
    fs.mkdirSync(path.dirname(item.dest), { recursive: true });
    touched.push(item);
    fs.copyFileSync(item.input, item.dest);
  }
} catch (error) {
  const rollbackErrors = [];
  for (const item of touched.reverse()) {
    try {
      if (item.existed) fs.copyFileSync(path.join(backup, item.path), item.dest);
      else if (fs.existsSync(item.dest)) fs.unlinkSync(item.dest);
    } catch (restoreError) { rollbackErrors.push(`${item.path}: ${restoreError.message}`); }
  }
  console.error('Aplicação interrompida. Backup:', backup, 'Erros de restauração:', rollbackErrors);
  throw error;
}
console.log(`${pending.length} arquivos de conteúdo aplicados. Backup: ${backup}`);
console.log('Execute npm run build e revise git diff antes do seu fluxo de commit/push/deploy.');
